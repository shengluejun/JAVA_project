package utest.TestDAO;
import static org.junit.jupiter.api.Assertions.*;

import src.Common.DAO.DAOAsset;
import src.Common.DAO.DAOProperty;
import src.Common.DAO.DAOUnit;
import src.Common.Model.Asset;
import src.Common.Model.Property;
import org.junit.jupiter.api.*;
import src.Common.Model.Unit;

import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestDAOProperty {
    DAOProperty daoProperty= new DAOProperty();
    DAOAsset daoAsset= new DAOAsset();
    DAOUnit daoUnit= new DAOUnit();

    final String assetName = "asset A";
    final String unitName = "unit A";
    final int quantity = 1;

    Property A = new Property(1,assetName,quantity,unitName);

    @Test
    @Order(1)
    public void testDeletePropertyList() {
        List<Property> propertyList = daoProperty.getItemList();
        for (Property p:propertyList) {
            daoProperty.deleteItem(String.valueOf(p.getId()));
        }
        int size = daoProperty.getSize();
        assertEquals(size, 0);
    }
    @Test
    @Order(2)
    public void testDeleteAssetList() {
        Set<String> nameList = daoAsset.getNameList();
        for (String name:nameList) {
            daoAsset.deleteItem(name);
        }
        int size = daoAsset.getSize();
        assertEquals(size, 0);
    }

    @Test
    @Order(3)
    public void testDeleteUnitList() {
        Set<String> nameList = daoUnit.getNameList();
        for (String name:nameList) {
            daoUnit.deleteItem(name);
        }
        int size = daoUnit.getSize();
        assertEquals(size, 0);
    }

    @Test
    @Order(4)
    public void addAssetData() {
        Asset a = new Asset();
        a.setAssetName(assetName);
        a.setAssetDescription(assetName + " description");
        assertTrue(daoAsset.addItem(a));
    }
    @Test
    @Order(5)
    public void addUnitData() {
        Unit u = new Unit();
        u.setUnitName(unitName);
        u.setCredits(100);
        assertTrue(daoUnit.addItem(u));
    }
    @Test
    @Order(6)
    public void addData(){
        daoProperty.addItem(A);
        daoProperty.getItem(assetName + "," + unitName);
        daoProperty.getSize();
        assertEquals(1, daoProperty.getSize());
    }

    @Test
    @Order(7)
    public void updateData(){
        A.setQuantity(55);
        daoProperty.updateItem(A);
        daoProperty.getSize();
        Optional<Property> propertyOptional = daoProperty.getItem(assetName + "," + unitName);

        if(propertyOptional.isPresent())
        {
            assertEquals(55,propertyOptional.get().getQuantity());
        }
    }

}
