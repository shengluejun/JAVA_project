package utest.TestDAO;
import src.Common.*;
import src.Common.DAO.DAOAsset;
import src.Common.Model.Asset;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

import java.util.List;
import java.util.Set;
/**
 * This class is used for asset dao class test.
 * It includes delete/add/update/get tests.
 *
 * @author CAB302
 * @version 1.0
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestDAOAsset {

    private DAOAsset daoAsset = new DAOAsset();
    private Asset A = new Asset("asset A","asset A description");
    private Asset B = new Asset("asset B","asset B description");
    private Asset C= new Asset("asset C","asset C description");


    @Test
    @Order(1)
    public void testDeleteAssetList() {
        Set<String> nameList = daoAsset.getNameList();
        for (String name:nameList) {
            daoAsset.deleteItem(name);
        }
        int size = daoAsset.getSize();
        assertEquals(size, 0);
    }

    @Test
    @Order(2)
    public void adddata(){
        daoAsset.addItem(A);
        daoAsset.addItem(B);
        daoAsset.addItem(C);
        daoAsset.getItem(A.getAssetName());
        daoAsset.getItem(B.getAssetName());
        daoAsset.getItem(C.getAssetName());
        daoAsset.getNameList();
        daoAsset.getItemList();
        daoAsset.getSize();
        assertEquals(3,daoAsset.getSize());
    }

    @Test
    @Order(3)
    public void updatedata(){
        A = new Asset("asset A","new asset A description");
        daoAsset.updateItem(A);
        daoAsset.getItem(A.getAssetName());
        daoAsset.getNameList();
        daoAsset.getItemList();
        daoAsset.getSize();
        assertEquals(3,daoAsset.getSize());
        assertEquals("new asset A description",A.getAssetDescription());
    }
    @Test
    @Order(4)
    public void deletedata(){
        daoAsset.getItem(B.getAssetName());
        daoAsset.deleteItem(B.getAssetName());
        daoAsset.getNameList();
        daoAsset.getItemList();
        daoAsset.getSize();
        assertEquals(2,daoAsset.getSize());
    }

}
