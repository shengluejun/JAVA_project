package utest.TestDAO;

import src.Common.DAO.DAOUnit;
import src.Common.Model.Unit;
import org.junit.jupiter.api.*;

import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestDAOUnit {
    DAOUnit daoUnit =new DAOUnit();
    Unit A = new Unit("Unit A",100);
    Unit B = new Unit("Unit B",200);
    Unit C = new Unit("Unit C",300);


    @Test
    @Order(1)
    public void testDeleteUnitList() {
        Set<String> nameList = daoUnit.getNameList();
        for (String name:nameList) {
            daoUnit.deleteItem(name);
        }
        int size = daoUnit.getSize();
        assertEquals(size, 0);
    }
    @Test
    @Order(2)
    public void adddata(){
        daoUnit.addItem(A);
        daoUnit.addItem(B);
        daoUnit.addItem(C);
        daoUnit.getItem(A.getUnitName());
        daoUnit.getItem(B.getUnitName());
        daoUnit.getItem(C.getUnitName());
        daoUnit.getItemList();
        daoUnit.getNameList();
        daoUnit.getSize();
        assertEquals(3,daoUnit.getSize());

    }

    @Test
    @Order(3)
    public void updatedata(){
        A.setCredits(66);
        daoUnit.updateItem(A);
        daoUnit.getNameList();
        daoUnit.getItemList();
        daoUnit.getSize();

        Optional<Unit> unitOptional = daoUnit.getItem(A.getUnitName());

        if(unitOptional.isPresent())
        {
            assertEquals(66,unitOptional.get().getCredits());
        }

    }

}
