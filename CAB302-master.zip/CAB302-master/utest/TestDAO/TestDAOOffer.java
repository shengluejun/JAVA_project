package utest.TestDAO;
import src.Common.DAO.DAOOffer;
import src.Common.ElectronicPlatformException;
import src.Common.Model.Offer;
//import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;
import src.Common.Model.Unit;

import java.util.List;
import java.util.Optional;
import java.util.Set;
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestDAOOffer {
    DAOOffer daoOffer = new DAOOffer();
    Offer buyOfferA;
    Offer sellOfferA;
    public TestDAOOffer() throws ElectronicPlatformException {
        buyOfferA = new Offer(1, "buy offer A","asset A",10,"unit A","Buy",10);
        sellOfferA = new Offer(2,"sell offer A","asset A",10,"unit B","Sell",10);
    }



    @Test
    @Order(1)
    public void testDeleteOfferList() {
        List<Offer> offerList = daoOffer.getItemList();
        for (Offer offer:offerList) {
            daoOffer.deleteItem(String.valueOf(offer.getId()));
        }
        int size = daoOffer.getSize();
        assertEquals(size, 0);
    }

    @Test
    @Order(2)
    public void adddata(){
        daoOffer.addItem(buyOfferA);
        daoOffer.addItem(sellOfferA);
        daoOffer.getNameList();
        daoOffer.getItemList();
        assertEquals(2,daoOffer.getSize());
    }

    @Test
    @Order(3)
    public void updatedata(){
        buyOfferA.setQuantity(20);
        daoOffer.updateItem(buyOfferA);
        daoOffer.getSize();
        Optional<Offer> offerOptional = daoOffer.getItem("1");

        if(offerOptional.isPresent())
        {
            assertEquals(20,offerOptional.get().getQuantity());
        }
    }


    @Test
    @Order(4)
    public void deletedata(){
        daoOffer.deleteItem("1");
        assertEquals(1,daoOffer.getSize());
    }
    /*
     * Test that all expected exceptions are thrown when an invalid
     * Electronic Platform Offer info is constructed
     *
     * NB: There is no separate test for a negative retail price because this
     * possibility is precluded by the requirements that (a) the quantity
     * must be non-negative and (b) the retail price may not be less than zero.
     */
    @Test
    @Order(5)
    public void NegativePrice() throws ElectronicPlatformException {
        assertThrows(ElectronicPlatformException.class, () -> {
            @SuppressWarnings("unused")
            Offer badOffer = new Offer(1, "buy offer AA","asset AA",10,"unit AA","Buy",-10);
        });
    }
    @Test
    @Order(6)
    public void NegativeQuantity() throws ElectronicPlatformException {
        assertThrows(ElectronicPlatformException.class, () -> {
            @SuppressWarnings("unused")
            Offer badOffer = new Offer(1, "buy offer AA","asset AA",-10,"unit AA","Buy",10);
        });
    }

}
