package utest.TestDAO;
import static org.junit.jupiter.api.Assertions.*;

import src.Common.DAO.DAOTradeHistory;
import src.Common.Model.TradeHistory;
import org.junit.jupiter.api.*;

import java.util.List;
import java.util.Set;
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestDAOTradeHistory {
    DAOTradeHistory daoTradeHistory = new DAOTradeHistory();
    TradeHistory A = new TradeHistory(1,"buy offer A","sell offer A","asset A",2,"unit A",
            "unit B",5,"2021-06-05 10:00:00");

    @Test
    @Order(1)
    public void testDeleteTradeHistoryList() {
        List<TradeHistory> tradeHistoryList = daoTradeHistory.getItemList();
        for (TradeHistory tradeHistory:tradeHistoryList) {
            daoTradeHistory.deleteItem(String.valueOf(tradeHistory.getId()));
        }
        int size = daoTradeHistory.getSize();
        assertEquals(size, 0);
    }
    @Test
    @Order(2)
    public void adddata(){
        daoTradeHistory.addItem(A);
        assertEquals(1,daoTradeHistory.getSize());

    }
}
