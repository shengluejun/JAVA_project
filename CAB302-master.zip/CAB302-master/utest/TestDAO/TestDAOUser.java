package utest.TestDAO;
import org.mindrot.jbcrypt.BCrypt;
import src.Common.DAO.DAOUser;
import static org.junit.jupiter.api.Assertions.*;
import src.Common.Model.User;
import org.junit.jupiter.api.*;

import java.util.Optional;
import java.util.Set;
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestDAOUser {
    DAOUser daoUser = new DAOUser();
    User userA = new User(1,"User A","password 1","Unit A","Staff");
    User userB = new User(2,"User B","password 2","Admin");


    @Test
    @Order(1)
    public void testDeleteUserList() {
        Set<String> nameList = daoUser.getNameList();
        for (String name:nameList) {
            daoUser.deleteItem(name);
        }
        int size = daoUser.getSize();
        assertEquals(size, 0);
    }

    @Test
    @Order(2)
    public void adddata() {
        daoUser.addItem(userA);
        daoUser.addItem(userB);
        assertEquals(2, daoUser.getSize());
    }
    @Test
    @Order(3)
    public void updatedata(){
        String strPassword = BCrypt.hashpw("password changed", BCrypt.gensalt());
        userA.setPassword(strPassword);
        daoUser.updateItem(userA);
        Optional<User> userOptional = daoUser.getItem(userA.getUserName());
        if(userOptional.isPresent()){
            assertTrue(BCrypt.checkpw("password changed", userOptional.get().getPassword()));
        }else
        {
            assertFalse(false, "cannot find user.");
        }
    }

}
