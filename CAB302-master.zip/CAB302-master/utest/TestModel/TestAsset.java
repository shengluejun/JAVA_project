package utest.TestModel;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import src.Common.DAO.DAOAsset;
import src.Common.Model.Asset;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

/**
 * This class is used for asset model class test.
 * It includes get/set asset model, create the same asset, & get asset ID tests.
 *
 * @author CAB302
 * @version 1.0
 */
public class TestAsset {
    private Asset asset1;

    @BeforeEach
    /*
     * Create a fresh asset before each test
     */
    public void newAsset() {
        asset1 = new Asset("CPU", "Consuming time");
    }

    /* Typical cases - passed by both versions */
    @Test
    public void testGetAsset() {
        assertEquals(asset1.getAssetName(), "CPU");
        assertEquals(asset1.getAssetDescription(), "Consuming time");
        assertEquals(asset1.toString(), "CPU Consuming time");
    }

    @Test
    public void testSetAsset() {
        asset1.setAssetName("Widget");
        asset1.setAssetDescription("small tools");
        assertEquals(asset1.getAssetDescription(), "small tools");
        assertEquals(asset1.getAssetName(), "Widget");
    }

}
