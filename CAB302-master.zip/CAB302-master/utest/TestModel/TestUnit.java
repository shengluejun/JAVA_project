package utest.TestModel;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import src.Common.Model.Unit;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * This class is used for unit model class test.
 * It includes get/set unit model tests.
 *
 * @author CAB302
 * @version 1.0
 */
public class TestUnit {
    private Unit unit1;

    @BeforeEach
    /*
     * Create a fresh asset before each test
     */
    public void newAsset() {
        unit1 = new Unit(3, "IT", 181);
    }

    /* Typical cases - passed by both versions */
    @Test
    public void testGetunit() {
        assertEquals(unit1.getId(), 3);
        assertEquals(unit1.getUnitName(), "IT");
        assertEquals(unit1.getCredits(), 181);
        assertEquals(unit1.toString(), "IT 181");
    }

    @Test
    public void testSetUnit() {
        unit1.setId(5);
        unit1.setUnitName("PE");
        unit1.setCredits(50);
        assertEquals(unit1.getId(), 5);
        assertEquals(unit1.getUnitName(), "PE");
        assertEquals(unit1.getCredits(), 50);
        assertEquals(unit1.toString(), "PE 50");
    }

}
