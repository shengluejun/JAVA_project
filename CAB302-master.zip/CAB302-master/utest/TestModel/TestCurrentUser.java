package utest.TestModel;

import org.junit.jupiter.api.Test;
import src.Common.Model.CurrentUser;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * This class is used for current user model class test.
 * It includes set current user model tests.
 *
 * @author CAB302
 * @version 1.0
 */
public class TestCurrentUser {

    /* Typical cases - passed by both versions */
    @Test
    public void testSetCurrentUser() {
        CurrentUser.getInstance().setCurrentUserName("Nancy");
        CurrentUser.getInstance().setCurrentUserUnit("IT");
        CurrentUser.getInstance().setCurrentUserType("Staff");
        assertEquals(CurrentUser.getInstance().getCurrentUserType(), "Staff");
        assertEquals(CurrentUser.getInstance().getCurrentUserUnit(), "IT");
        assertEquals(CurrentUser.getInstance().getCurrentUserName(), "Nancy");
    }
}