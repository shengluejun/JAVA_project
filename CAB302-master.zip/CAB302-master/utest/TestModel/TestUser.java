package utest.TestModel;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import src.Common.Model.User;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * This class is used for user model class test.
 * It includes get/set user model tests.
 *
 * @author CAB302
 * @version 1.0
 */
public class TestUser {
    private User user1;

    @BeforeEach
    /*
     * Create a fresh asset before each test
     */
    public void newAsset() {
        user1 = new User("John", "1234", "Admin");
    }

    /* Typical cases - passed by both versions */
    @Test
    public void testGetUser() {
        assertEquals(user1.getUserName(), "John");
        assertEquals(user1.getPassword(), "1234");
        assertEquals(user1.getUserType(), "Admin");
        assertEquals(user1.toString(), "John 1234 null Admin");
    }

    @Test
    public void testSetUser() {
        user1.setUserName("Mike");
        user1.setPassword("4567");
        user1.setUnitName("IT");
        user1.setUserType("Staff");
        assertEquals(user1.getUserName(), "Mike");
        assertEquals(user1.getPassword(), "4567");
        assertEquals(user1.getUnitName(), "IT");
        assertEquals(user1.getUserType(), "Staff");
        assertEquals(user1.toString(), "Mike 4567 IT Staff");
    }
}