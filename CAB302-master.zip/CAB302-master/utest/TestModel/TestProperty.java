package utest.TestModel;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import src.Common.Model.Property;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * This class is used for property model class test.
 * It includes get/set property model, and illegal input tests.
 *
 * @author CAB302
 * @version 1.0
 */
public class TestProperty {
    private Property asset1;

    @BeforeEach
    /*
     * Create a fresh asset before each test
     */
    public void newProperty() {
        asset1 = new Property(1,"Widget", 100, "IT");
    }

    /* Typical cases - passed by both versions */
    @Test
    public void testGetProperty() {
        assertEquals(asset1.getId(), 1);
        assertEquals(asset1.getAssetName(), "Widget");
        assertEquals(asset1.getQuantity(), 100);
        assertEquals(asset1.getUnitName(), "IT");
        assertEquals(asset1.toString(), "Widget");
    }

    @Test
    public void testSetProperty() {
        asset1.setId(3);
        asset1.setAssetName("CPU");
        asset1.setQuantity(500);
        asset1.setUnitName("IT");
        assertEquals(asset1.getUnitName(), "IT");
        assertEquals(asset1.getQuantity(), 500);
        assertEquals(asset1.getAssetName(), "CPU");
        assertEquals(asset1.getId(), 3);
    }
}
