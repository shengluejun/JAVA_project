package utest.TestModel;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import src.Common.Model.TradeHistory;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * This class is used for trade history model class test.
 * It includes get/set trade history model & illegal input tests.
 *
 * @author CAB302
 * @version 1.0
 */
public class TestTradeHistory {
    private TradeHistory trade1;

    @BeforeEach
    /*
     * Create a fresh asset before each test
     */
    public void newTrade() {
        trade1 = new TradeHistory(1, "buy1", "sell1", "CPU", 300, "IT", "PE", 3, "2021-05-29 18:43:52");
    }

    /* Typical cases - passed by both versions */
    @Test
    public void testGetTrade() {
        assertEquals(trade1.getId(), 1);
        assertEquals(trade1.getBuyOfferName(), "buy1");
        assertEquals(trade1.getSellOfferName(), "sell1");
        assertEquals(trade1.getAssetName(), "CPU");
        assertEquals(trade1.getQuantity(), 300);
        assertEquals(trade1.getBuyUnitName(), "IT");
        assertEquals(trade1.getSellUnitName(), "PE");
        assertEquals(trade1.getTransactionPrice(), 3);
        assertEquals(trade1.getTransactionTime(), "2021-05-29 18:43:52");
        assertEquals(trade1.toString(), "buy1 sell1 CPU 300 IT PE 3 2021-05-29 18:43:52");
    }

    @Test
    public void testSetTrade() {
        trade1.setId(3);
        trade1.setBuyOfferName("buy1");
        trade1.setSellOfferName("sell1");
        trade1.setAssetName("Widgets");
        trade1.setQuantity(400);
        trade1.setBuyUnitName("PE");
        trade1.setSellUnitName("IT");
        trade1.setTransactionPrice(2);
        trade1.setTransactionTime("2021-05-29 18:44:13");
        assertEquals(trade1.getTransactionTime(), "2021-05-29 18:44:13");
        assertEquals(trade1.getTransactionPrice(), 2);
        assertEquals(trade1.getSellUnitName(), "IT");
        assertEquals(trade1.getBuyUnitName(), "PE");
        assertEquals(trade1.getQuantity(), 400);
        assertEquals(trade1.getAssetName(), "Widgets");
        assertEquals(trade1.getSellOfferName(), "sell1");
        assertEquals(trade1.getBuyOfferName(), "buy1");
        assertEquals(trade1.getId(), 3);
    }
}
