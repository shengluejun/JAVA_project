package utest.TestModel;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import src.Common.DAO.DAOOffer;
import src.Common.ElectronicPlatformException;
import src.Common.Model.Offer;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * This class is used for offer model class test.
 * It includes get/set offer model, get offer id, & illegal input tests.
 *
 * @author CAB302
 * @version 1.0
 */
public class TestOffer {
    private Offer offer1;
    @BeforeEach
    /*
     * Create a fresh asset before each test
     */
    public void newOffer() throws ElectronicPlatformException { //(int id, String offerName, String assetName, int quantity, String unitName, String offerType, int price)
        offer1 = new Offer (3,"sell2", "CPU", 500, "IT","SELL",3);
    }

    /* Typical cases - passed by both versions */
    @Test
    public void testGetOffer() {
        assertEquals(offer1.getId(), 3);
        assertEquals(offer1.getOfferName(), "sell2");
        assertEquals(offer1.getAssetName(),"CPU");
        assertEquals(offer1.getQuantity(),500);
        assertEquals(offer1.getUnitName(),"IT");
        assertEquals(offer1.getOfferType(),"SELL");
        assertEquals(offer1.getPrice(),3);
        assertEquals(offer1.toString(),"sell2 CPU 500 IT SELL 3");
    }

    @Test
    public void testSetOffer() {
        offer1.setId(12);
        offer1.setOfferName("buy1");
        offer1.setAssetName("Widget");
        offer1.setQuantity(300);
        offer1.setUnitName("PE");
        offer1.setOfferType("BUY");
        offer1.setPrice(10);
        assertEquals(offer1.getPrice(), 10);
        assertEquals(offer1.getOfferType(),"BUY");
        assertEquals(offer1.getUnitName(),"PE");
        assertEquals(offer1.getQuantity(),300);
        assertEquals(offer1.getAssetName(),"Widget");
        assertEquals(offer1.getOfferName(), "buy1");
        assertEquals(offer1.getId(), 12);
    }
}