package utest.TestServer;
import org.junit.jupiter.api.*;
import src.Common.DAO.*;
import src.Common.ElectronicPlatformException;
import src.Common.Model.*;
import src.Server.AssetTrade;

import java.util.List;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

/**
 * This class is used for asset trade class test.
 * It includes process tests.
 *
 * @author CAB302
 * @version 1.0
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestAssetTrade {
    private AssetTrade assetTrade;
    private DAOOffer daoOffer;
    private DAOUnit daoUnit;
    private DAOAsset daoAsset;
    private DAOProperty daoProperty;
    private DAOTradeHistory daoTradeHistory;

    public TestAssetTrade(){
        daoOffer = new DAOOffer();
        daoUnit = new DAOUnit();
        daoAsset = new DAOAsset();
        daoProperty = new DAOProperty();
        daoTradeHistory = new DAOTradeHistory();
        assetTrade = new AssetTrade();
    }

    @Test
    @Order(1)
    public void init() throws ElectronicPlatformException {

        List<Offer> offerList = daoOffer.getItemList();
        for (Offer offer : offerList) {
            daoOffer.deleteItem(String.valueOf(offer.getId()));
        }

        Set<String> unitList = daoUnit.getNameList();
        for (String unit : unitList) {
            daoUnit.deleteItem(unit);
        }

        Set<String> aasetList = daoAsset.getNameList();
        for (String asset : aasetList) {
            daoAsset.deleteItem(asset);
        }

        List<Property> propertyList = daoProperty.getItemList();
        for (Property property : propertyList) {
            daoProperty.deleteItem(String.valueOf(property.getId()));
        }

        List<TradeHistory> itemList = daoTradeHistory.getItemList();
        for (TradeHistory tradeHistory : itemList) {
            daoTradeHistory.deleteItem(String.valueOf(tradeHistory.getId()));
        }

        daoAsset.addItem(new Asset("CPU", "CPU description"));
        daoUnit.addItem(new Unit("IT", 500));
        daoUnit.addItem(new Unit("PE", 500));
        daoProperty.addItem(new Property("CPU", 600, "IT"));
        daoProperty.addItem(new Property("CPU", 100, "PE"));


        Offer offer1 = new Offer(3,"sell2", "CPU", 500, "IT","Sell",1);
        Offer offer2 = new Offer(5,"buy2", "CPU", 150, "PE","Buy",1);
        daoOffer.addItem(offer2);
        daoOffer.addItem(offer1);
    }

    @Test
    @Order(2)
    public void TestProcessTrade() throws InterruptedException {
        assetTrade.processTradeList();
        List<TradeHistory> tradeHistoryList = daoTradeHistory.getItemList();
        assertEquals(tradeHistoryList.size(), 1);
    }
}