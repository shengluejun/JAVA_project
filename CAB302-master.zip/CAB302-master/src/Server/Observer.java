package src.Server;

/**
 * Observer interface as part of the Observer Pattern code
 *
 * @author CAB302
 * @version 1.0
 */
public interface Observer {
    /**
     * Query the subject to determine what was the change of state
     * and respond appropriately based on the subject's new state.
     *
     * @param s The subject that has been updated.
     */
    public void update(Subject s);
}
