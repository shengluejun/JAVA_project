package src.Server;

import javax.swing.*;

/** This class contains offer observer to receive asset trade subject's notification to give user an update.
 * It will pop up a dialogue to remind user that his/her offers have been processed. Refresh offer table UI will get
 * the latest offer lists. Click "trade history" will view all the processed offers' details.
 *
 * @author CAB302
 * @version 1.0
 */
public class OfferObserver implements Observer {
    @Override
    public void update(Subject subject) {
        System.out.println("Your Offer has been processed !");
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                notifyDialogue();
            }
        });
    }

    /**
     * reminder for user offer has been processed
     */
    public void notifyDialogue() {
        JFrame frame = new JFrame();
        frame.setAlwaysOnTop(true);
        JOptionPane.showMessageDialog(frame, "You have Offer processed! Please click refresh to get new offer list.");
    }
}
