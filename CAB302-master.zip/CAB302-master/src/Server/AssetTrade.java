package src.Server;


import src.Common.DAO.DAOProperty;
import src.Common.DAO.DAOTradeHistory;
import src.Common.Model.*;
import src.Common.DAO.DAOUnit;
import src.Common.DAO.DAOOffer;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;

/**
 * This class contains the main program for processing sell offers and buy offers according to the asset's quantity and price.
 * It also includes lots of validation rules before processing.
 *
 * @author CAB302
 * @version 1.0
 */
public class AssetTrade extends Subject {
    private DAOUnit daoUnit;
    private DAOOffer daoOffer;
    private DAOProperty daoProperty;
    private DAOTradeHistory daoTradeHistory;
    //Used for setting interval
    private int processInterval = 1000;
    private TradeHistory trade;
    private Offer offerSell;
    private Offer offerBuy;

    /**
    This AssetTrade is used to finish offer process when users request an offer

     **/
    public AssetTrade() {
        daoUnit = new DAOUnit();
        daoOffer = new DAOOffer();
        daoProperty = new DAOProperty();
        daoTradeHistory = new DAOTradeHistory();
    }

    /**
     * Start process trade.
     * - no param.
     */
    public void start(){
            try {
                Thread.sleep(processInterval);
                processTradeList();
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
    }

    /**
     * Find all buy offers and sell offers, then process them.
     * - no param.
     */
    public void processTradeList() throws InterruptedException {
        List<Offer> offerBuyList = daoOffer.getBuyItemList();
        List<Offer> offerSellList = daoOffer.getSellItemList();
        for (Offer offerBuy : offerBuyList) {

            for (Offer offerSell : offerSellList) {
                if (ComparesOffer(offerBuy, offerSell)) {
                    this.offerBuy = offerBuy;
                    this.offerSell = offerSell;
                    int transactionQuantity = getTransactionQuantity(offerBuy, offerSell);
                    processTrade(offerBuy, offerSell);
                    offerBuy.setQuantity( offerBuy.getQuantity()- transactionQuantity);
                    offerSell.setQuantity( offerSell.getQuantity()-transactionQuantity);
                    this.notifyObservers();

                }
            }

        }
    }

    /**
     * Compare offers to determine whether which can be processed.
     * @param offerBuy buying request from organizational unit user
     * @param offerSell selling request from organizational unit user
     */
    private boolean ComparesOffer(Offer offerBuy, Offer offerSell) {

        boolean result = false;
        //check buyer's price >= seller's price
        if (offerBuy.getAssetName().equals(offerSell.getAssetName()) && offerBuy.getPrice() >= offerSell.getPrice()
                && offerBuy.getOfferType().equals("Buy") && offerSell.getOfferType().equals("Sell")) {

            //check credits for buyers
            int transactionQuantity = getTransactionQuantity(offerBuy, offerSell);
            Optional<Unit> u = daoUnit.getItem(offerBuy.getUnitName());
            if(u.isPresent()){
                result = u.get().getCredits() >= offerSell.getPrice() * transactionQuantity;
            }
            //check quantity for sellers
            if(result){
                Optional<Property> p = daoProperty.getItem(offerSell.getAssetName() + "," + offerSell.getUnitName());
                if(p.isPresent()){
                    result = p.get().getQuantity() >= offerSell.getQuantity();
                }
            }
        }
        return result;
    }

    /**
     * Determine Transaction quantity.
     * @param offerBuy buying request from organizational unit user
     * @param offerSell selling request from organizational unit user
     */
    private int getTransactionQuantity(Offer offerBuy, Offer offerSell){
        if(offerBuy.getQuantity() >=  offerSell.getQuantity())
            return offerSell.getQuantity();
        else
            return offerBuy.getQuantity();
    }

    /**
     * Process buy offers and sell offers and return processing result.
     * @param offerBuy buying request from organizational unit user
     * @param offerSell selling request from organizational unit user
     * @return processing result
     */
    public boolean processTrade(Offer offerBuy, Offer offerSell) {

        boolean processResult = false;

        if (offerBuy.getQuantity() > offerSell.getQuantity()) {
            UpdateCredits(offerBuy, offerSell.getPrice(), offerSell.getQuantity(), "Buy");
            UpdateCredits(offerSell, offerSell.getPrice(), offerSell.getQuantity(), "Sell");

            processProperty(offerBuy, offerSell,offerSell.getQuantity());

            addTradeHistory(offerBuy, offerSell, offerSell.getQuantity());

            UpdateOffer(offerBuy, offerSell.getQuantity());
            DeleteOffer(offerSell);


            processResult = true;

        } else if (offerBuy.getQuantity() == offerSell.getQuantity()) {
            UpdateCredits(offerBuy, offerSell.getPrice(), offerSell.getQuantity(), "Buy");
            UpdateCredits(offerSell, offerSell.getPrice(), offerSell.getQuantity(), "Sell");

            processProperty(offerBuy, offerSell,offerSell.getQuantity());

            addTradeHistory(offerBuy, offerSell, offerSell.getQuantity());

            DeleteOffer(offerBuy);
            DeleteOffer(offerSell);


            processResult = true;

        } else if (offerBuy.getQuantity() < offerSell.getQuantity()) {
            UpdateCredits(offerBuy, offerSell.getPrice(), offerBuy.getQuantity(), "Buy");
            UpdateCredits(offerSell, offerSell.getPrice(), offerBuy.getQuantity(), "Sell");

            processProperty(offerBuy, offerSell,offerBuy.getQuantity());

            addTradeHistory(offerBuy, offerSell, offerBuy.getQuantity());

            DeleteOffer(offerBuy);
            UpdateOffer(offerSell, offerBuy.getQuantity());


            processResult = true;
        }

        return processResult;
    }

    /**
     * Update current credits.
     * @param o use o as offer to get corresponding unit name
     * @param price
     * @param quantity
     * @param offerType
     */
    private void UpdateCredits(Offer o, int price, int quantity, String offerType) {
        Optional<Unit> unit = daoUnit.getItem(o.getUnitName());
        if (unit.isPresent()) {
            Unit u = unit.get();
            if (offerType.equals("Buy"))
                u.setCredits(u.getCredits() - price * quantity);
            else
                u.setCredits(u.getCredits() + price * quantity);
            daoUnit.updateItem(u);
        }
    }

    /**
     * Update current offer.
     * @param o current offer
     * @param quantity $
     */
    private void UpdateOffer(Offer o, int quantity) {
        Optional<Offer> offer = daoOffer.getItem(String.valueOf(o.getId()));
        if (offer.isPresent()) {
            Offer offerUpdate = offer.get();
            offerUpdate.setQuantity(offerUpdate.getQuantity() - quantity);
            daoOffer.updateItem(offerUpdate);
        }
    }

    /**
     * Delete current offer.
     * @param o current offer
     */
    private void DeleteOffer(Offer o) {
        Optional<Offer> offer = daoOffer.getItem(String.valueOf(o.getId()));
        if (offer.isPresent()) {
            Offer offerDelete = offer.get();
            daoOffer.deleteItem(String.valueOf(offerDelete.getId()));
        }
    }

    /**
     * Add new Property.
     * @param property current property
     */
    private void addProperty(Property property) {
        daoProperty.addItem(property);
    }

    private void updateProperty(Property property, String offerType , int quantity) {
        if (offerType.equals("Buy")) {
            property.setQuantity(property.getQuantity() + quantity);
        } else {
            property.setQuantity(property.getQuantity() - quantity);
        }
        daoProperty.updateItem(property);
    }

    /**
     * Process property according to buy offer and sell offer .
     * @param offerBuy buying request from organizational unit user
     * @param offerSell selling request from organizational unit user
     * @param quantity
     */
    private void processProperty(Offer offerBuy, Offer offerSell, int quantity) {
        Optional<Property> propertyBuy = getPropertyFromOffer(offerBuy);
        Optional<Property> propertySell = getPropertyFromOffer(offerSell);

        if (propertyBuy.isPresent()) {
            updateProperty(propertyBuy.get(), "Buy",quantity);
        } else {
            addProperty(propertyBuy.get());
        }

        if (propertySell.isPresent()) {
            updateProperty(propertySell.get(), "Sell",quantity);
        }
    }

    /**
     * get corresponding property according to current offer.
     * @param o offer
     */
    private Optional<Property> getPropertyFromOffer(Offer o){
        return daoProperty.getItem(o.getAssetName() + "," + o.getUnitName());
    }

    private void addTradeHistory(Offer offerBuy, Offer offerSell, int quantity) {
        this.trade = new TradeHistory(offerBuy.getOfferName(), offerSell.getOfferName(),
                offerBuy.getAssetName(), quantity, offerBuy.getUnitName(), offerSell.getUnitName(), offerSell.getPrice(), now());
        daoTradeHistory.addItem(this.trade);
    }

    /**
     * get current time.
     * @return date format
     */
    public String now() {
        String DATE_FORMAT_NOW = "yyyy-MM-dd HH:mm:ss";
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat date = new SimpleDateFormat(DATE_FORMAT_NOW);
        return date.format(calendar.getTime());
    }

}



