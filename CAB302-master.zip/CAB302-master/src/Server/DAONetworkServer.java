package src.Server;

import src.Common.DAO.*;
import src.Common.Model.*;
import src.Common.ServerConnection;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
/**
 * This class contains the main program for getting info from client side and process based on commands and database objects.
 *
 * @author CAB302
 * @version 1.0
 */
public class DAONetworkServer {

    private static final int PORT = ServerConnection.getInstance().getPort();

    /**
     * this is the timeout between accepting clients, not reading from the socket itself.
     */
    private static final int SOCKET_ACCEPT_TIMEOUT = 100;

    /**
     * This timeout is used for the actual clients.
     */
    private static final int SOCKET_READ_TIMEOUT = 5000;

    private AtomicBoolean running = new AtomicBoolean(true);

    /**
     * The connection to the database where everything is stored.
     */
    private IDAOBase database;

    private void initDatabase(Object o){
        switch ((DAOBase.ClientClass)o){
            case ASSET:
                database = new DAOAsset();
                break;
            case UNIT:
                database = new DAOUnit();
                break;
            case USER:
                database = new DAOUser();
                break;
            case OFFER:
                database = new DAOOffer();
                break;
            case PROPERTY:
                database = new DAOProperty();
                break;
            case TRADEHISTORY:
                database = new DAOTradeHistory();
                break;
        }
    }
    private String getItemInfo(IDAOBase database, Object o)
    {
        String itemInfo = "";
        if(database instanceof DAOAsset)
            itemInfo = "Asset";
        else if (database instanceof DAOUnit)
            itemInfo = "Unit";
        else if(database instanceof DAOUser)
            itemInfo =  "User";
        else if (database instanceof DAOOffer)
            itemInfo ="Offer";
        else if (database instanceof DAOProperty)
            itemInfo = "Property";
        else if (database instanceof DAOTradeHistory)
            itemInfo =  "TradeHistory";
        else{}
        return itemInfo;
    }

    /**
     * Handles the connection received from ServerSocket.
     * Does not return until the client disconnects.
     * @param socket The socket used to communicate with the currently connected client
     */
    private void handleConnection(Socket socket) {
        try {
            /**
             * We create the streams once at connection time, and re-use them until the client disconnects.
             * This **must** be in the opposite order to the client, because creating an ObjectInputStream
             * reads data, and an ObjectOutputStream writes data.
             */
            final ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
            final ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());

            /**
             * while(true) here might seem a bit confusing - why do we have an infinite loop?
             * That's because we don't want to exit until the client disconnects, and when they do, readObject()
             * will throw an IOException, which will cause this method to exit. Another option could be to have
             * a "close" message/command sent by the client, but if the client closes improperly, or they lose
             * their network connection, it's not going to get sent anyway.
             */
            while (true) {
                try {
                    /**
                     * Read the command, this tells us what to send the client back.
                     * If the client has disconnected, this will throw an exception.
                     */
                    //Connect to database
                    final DAOBase.ClientClass client = (DAOBase.ClientClass) inputStream.readObject();
                    final DAOBase.Command command = (DAOBase.Command) inputStream.readObject();
                    handleCommand(socket, inputStream, outputStream, client, command);
                } catch (SocketTimeoutException e) {
                    /**
                     * We catch SocketTimeoutExceptions, because that just means the client hasn't sent
                     * any new requests. We don't want to disconnect them otherwise. Another way to
                     * check if they're "still there would be with ping/pong commands.
                     */
                    continue;
                }
            }
        } catch (IOException | ClassCastException | ClassNotFoundException e) {
            System.out.println(String.format("Connection %s closed", socket.toString()));
        }
    }

    /**
     * Handles a request from the client.
     * @param socket socket for the client
     * @param inputStream input stream to read objects from
     * @param outputStream output stream to write objects to
     * @param command command we're handling
     * @throws IOException if the client has disconnected
     * @throws ClassNotFoundException if the client sends an invalid object
     */
    private void handleCommand(Socket socket, ObjectInputStream inputStream, ObjectOutputStream outputStream,
                               DAOBase.ClientClass client, DAOBase.Command command)
            throws IOException, ClassNotFoundException {
        /**
         * Remember this is happening on separate threads for each client. Therefore access to the database
         * must be thread-safe in some way. The easiest way to achieve thread safety is to just put a giant
         * lock around all database operations, in this case with a synchronized block on the database object.
         */
        initDatabase(client);
        switch (command) {
            case ADD_ITEM: {
                // client is sending us a new person
                final Object o = inputStream.readObject();
                synchronized (database) {
                    database.addItem(o);
                }
                System.out.println(String.format("Added %s to database from client %s", getItemInfo(database, o), socket.toString()));
            }
            break;

            case GET_ITEM: {
                // client sends us the name of the person to retrieve
                final String name = (String) inputStream.readObject();
                synchronized (database) {
                    // synchronize both the get as well as the send, that way
                    // we don't send a half updated person
                    final Optional<Object> o = database.getItem(name);

                    // send the client back the person's details, or null
                    if(o.isPresent()) {
                        outputStream.writeObject(o.get());
                        System.out.println(String.format("Sent %s to client %s", getItemInfo(database, o), socket.toString()));
                    }
                }
                outputStream.flush();
            }
            break;
            case UPDATE_ITEM: {
                // client is sending us a new person
                final Object o = inputStream.readObject();
                synchronized (database) {
                    database.updateItem(o);
                }
                System.out.println(String.format("Updated %s to database from client %s", getItemInfo(database, o), socket.toString()));
            }
            break;

            case GET_SIZE: {
                // no parameters sent by client

                // send the client back the size of the database
                synchronized (database) {
                    outputStream.writeInt(database.getSize());
                }
                outputStream.flush();

                System.out.println(String.format("Sent size %d of %s to client %s",
                        database.getSize(), getItemInfo(database, null), socket.toString()));
            }
            break;

            case DELETE_ITEM: {
                // one parameter - the person's name
                final String o = inputStream.readObject().toString();
                synchronized (database) {
                    database.deleteItem(o);
                }

                System.out.println(String.format("Deleted %s on behalf of client %s",
                        getItemInfo(database, o),socket.toString()));
            }
            break;

            case GET_ITEMLIST: {
                // no parameters sent by client

                // send the client back the name set
                synchronized (database) {
                    outputStream.writeObject(database.getItemList());
                }
                outputStream.flush();

                System.out.println(String.format("Sent %s set to client %s", getItemInfo(database, null),
                        socket.toString()));
            }
            break;
            case GET_NAMELIST: {
                // no parameters sent by client

                // send the client back the name set
                synchronized (database) {
                    outputStream.writeObject(database.getNameList());
                }
                outputStream.flush();

                System.out.println(String.format("Sent %s name set to client %s", getItemInfo(database, null),
                        socket.toString()));
            }
            break;
        }
    }

    /**
     * Returns the port the server is configured to use
     *
     * @return The port number
     */
    public static int getPort() {
        return PORT;
    }

    /**
     * Starts the server running on the default port
     */
    public void start() throws IOException {

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            serverSocket.setSoTimeout(SOCKET_ACCEPT_TIMEOUT);
            for (;;) {
                final Thread tradeThread = new Thread(() -> handleTrade());
                tradeThread.start();
                if (!running.get()) {
                    // The server is no longer running
                    break;
                }
                try {
                    final Socket socket = serverSocket.accept();
                    socket.setSoTimeout(SOCKET_READ_TIMEOUT);

                    // We have a new connection from a client. Use a runnable and thread to handle
                    // the client. The lambda here wraps the functional interface (Runnable).
                    final Thread clientThread = new Thread(() -> handleConnection(socket));
                    clientThread.start();
                } catch (SocketTimeoutException ignored) {
                    // Do nothing. A timeout is normal- we just want the socket to
                    // occasionally timeout so we can check if the server is still running
                } catch (Exception e) {
                    // We will report other exceptions by printing the stack trace, but we
                    // will not shut down the server. A exception can happen due to a
                    // client malfunction (or malicious client)
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            // If we get an error starting up, show an error dialog then exit
            e.printStackTrace();
            System.exit(1);
        }

        // Close down the server
        System.exit(0);
    }

    /**
     * process this trade
     */
    public void handleTrade(){
        AssetTrade assetTrade = new AssetTrade();
        OfferObserver offerObserver = new OfferObserver();
        assetTrade.attachObserver(offerObserver);
        assetTrade.start();
    }

    /**
     * Requests the server to shut down
     */
    public void shutdown() {
        // Shut the server down
        running.set(false);
    }
}
