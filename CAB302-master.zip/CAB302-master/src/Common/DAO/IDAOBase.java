package src.Common.DAO;


import java.util.List;
import java.util.Optional;
import java.util.Set;
/**
 * This interface is for all the dao classes which access to database.
 * It contains to add item, delete item, update item, get item, get item list, get name list, get size methods
 * that will require the extended class to overwrite.
 *
 * @author CAB302
 * @version 1.0
 */
public interface IDAOBase<T> {
    /**
     * base add item function
     * @param t the object to add
     * @return boolean value of the result
     */
    boolean addItem(T t);
    /**
     * base delete item function
     *  @param name the string name/object to delete
     *  @return boolean value of the result
     */
    boolean deleteItem(String name);
    /**
     * base update item function
     * @param t the object to update
     * @return boolean value of the result
     */
    boolean updateItem(T t);
    /**
     * base get item function
     *  @param name the object's name to get
     *  @return the value of the returned object
     */
    Optional<T> getItem(String name);
    /**
     * base get item list function
     * @return a list of T object of the items
     */
    List<T> getItemList();
    /**
     * base get name list function
     * @return name set of the items
     */
    Set<String> getNameList();
    /**
     * base get size function
     * @return the size of the current items
     */
    int getSize();

}
