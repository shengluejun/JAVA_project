/**
 * This Current_Trade_database is used to save all current offer trade information, if that trade is done, then it wilkl
 * be deleted from this dabase, and related information will be sent to trade_history database.
 * <p>
 * It has four funcitons: add - add a new row of data in the Asset types database.
 * delete - delete an existing row of data in the Asset types database
 * update - update the whole list in the Asset types database
 * search - search for a particular row of data in the Asset types database
 */

package src.Common.DAO;

import src.Common.ElectronicPlatformException;
import src.Common.Model.Offer;

import java.sql.*;
import java.util.*;

import static java.lang.Integer.parseInt;

/**
 * This class is used to Store all the details for current offer trade.
 *
 * @author CAB302
 * @version 1.0
 */
public class DAOOffer extends DAOBase implements IDAOBase<Offer> {
    /** Create a new table of data in the offer database */
    public static final String CREATE_TABLE =
            "CREATE TABLE IF NOT EXISTS offer ("
                    + "id INTEGER PRIMARY KEY /*!40101 AUTO_INCREMENT */ NOT NULL UNIQUE,"
                    + "offerName VARCHAR(80),"
                    + "assetName VARCHAR(80),"
                    + "quantity INTEGER,"
                    + "unitName VARCHAR(80),"
                    + "offerType String,"
                    + "price int" + ");";
    /** Insert item to database */
    private static final String INSERT_ITEM = "INSERT INTO offer (offerName, assetName, quantity, unitName, offerType, price) VALUES (?, ?, ?, ?, ?, ?);";
    /** Delete item from database */
    private static final String DELETE_ITEM = "DELETE FROM offer WHERE id=?;";
    /** Update item from database */
    private static final String UPDATE_ITEM = "UPDATE offer SET offerName=?, assetName=?, quantity=?, unitName=?, offerType=?, price=? WHERE id=?;";
    /** Get item from database */
    private static final String GET_ITEM = "SELECT id, offerName, assetName, price, quantity, unitName, offerType FROM offer WHERE id=?;";
    /** Get items from database */
    private static final String GET_ITEMS = "SELECT id, offerName, assetName, price, quantity, unitName, offerType FROM offer;";
    /** Get names from database */
    private static final String GET_NAMES = "SELECT offerName FROM offer";
    /** Get the number of rows from database */
    private static final String COUNT_ROWS = "SELECT COUNT(*) FROM offer";

    /** give the value to the variables */
    public DAOOffer() {
        super();
        try {
            st.execute(CREATE_TABLE);
            addItem = connection.prepareStatement(INSERT_ITEM);
            getItemList = connection.prepareStatement(GET_ITEMS);
            getNameList = connection.prepareStatement(GET_NAMES);
            getItem = connection.prepareStatement(GET_ITEM);
            updateItem = connection.prepareStatement(UPDATE_ITEM);
            deleteItem = connection.prepareStatement(DELETE_ITEM);
            rowCount = connection.prepareStatement(COUNT_ROWS);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }


    /** Add a new row of data in the offer database */
    @Override
    public boolean addItem(Offer offer) {
        boolean rowAdded = false;
        try {
            addItem.setString(1, offer.getOfferName());
            addItem.setString(2, offer.getAssetName());
            addItem.setInt(3, offer.getQuantity());
            addItem.setString(4, offer.getUnitName());
            addItem.setString(5, offer.getOfferType());
            addItem.setInt(6, offer.getPrice());
            rowAdded = addItem.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rowAdded;
    }

    /** delete an existing row of data in the offer database
     * @param id used to find the item
     *
     *
     * */
    @Override
    public boolean deleteItem(String id) {
        boolean rowDeleted = false;
        try {
            deleteItem.setInt(1, parseInt(id));
            rowDeleted = deleteItem.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rowDeleted;
    }

    /** update the whole list in the offer database
     * @param offer used to update offer
     * */
    @Override
    public boolean updateItem(Offer offer) {
        boolean rowUpdated = false;
        try {
            updateItem.setString(1, offer.getOfferName());
            updateItem.setString(2, offer.getAssetName());
            updateItem.setInt(3, offer.getQuantity());
            updateItem.setString(4, offer.getUnitName());
            updateItem.setString(5, offer.getOfferType());
            updateItem.setInt(6, offer.getPrice());
            updateItem.setInt(7, offer.getId());
            rowUpdated = updateItem.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rowUpdated;
    }


    /** search for a particular row of data in offer database
     * @param id used to find the item
     * */
    @Override
    public Optional<Offer> getItem(String id) {
        Offer offer = new Offer();
        ResultSet rs = null;
        try {
            getItem.setString(1, id);
            rs = getItem.executeQuery();
            rs.next();
            offer.setId(rs.getInt("Id"));
            offer.setOfferName(rs.getString("offerName"));
            offer.setAssetName(rs.getString("assetName"));
            offer.setQuantity(rs.getInt("quantity"));
            offer.setUnitName(rs.getString("unitName"));
            offer.setOfferType(rs.getString("offerType"));
            offer.setPrice(rs.getInt("price"));
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return Optional.of(offer);
    }


    @Override
    /** get the item list from database **/
    public List<Offer> getItemList() {
        List<Offer> list = new ArrayList();
        ResultSet rs = null;
        try {
            rs = getItemList.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String offerName = rs.getString("offerName");
                String assetName = rs.getString("assetName");
                int quantity = rs.getInt("quantity");
                String unitName = rs.getString("unitName");
                String offerType = rs.getString("offerType");
                int price = rs.getInt("price");
                Offer offer = new Offer(id, offerName, assetName, quantity, unitName, offerType, price);
                list.add(offer);

            }
        } catch (SQLException | ElectronicPlatformException ex) {
            ex.printStackTrace();
        }
        return list;
    }
    /** get buy item list from database
     * @return the list of offer
     * **/
    public List<Offer> getBuyItemList() {
        List<Offer> list = new ArrayList();
        ResultSet rs = null;
        try {
            rs = getItemList.executeQuery();
            while (rs.next()) {
                if (rs.getString("offerType").equals("Buy")) {
                    int id = rs.getInt("id");
                    String offerName = rs.getString("offerName");
                    String assetName = rs.getString("assetName");
                    int quantity = rs.getInt("quantity");
                    String unitName = rs.getString("unitName");
                    String offerType = rs.getString("offerType");
                    int price = rs.getInt("price");
                    Offer offer = new Offer(id, offerName, assetName, quantity, unitName, offerType, price);
                    list.add(offer);
                }
            }
        } catch (SQLException | ElectronicPlatformException ex) {
            ex.printStackTrace();
        }
        return list;
    }

    /** get sell item list from database
     * @return  the list of offer
     * **/
    public List<Offer> getSellItemList() {
        List<Offer> list = new ArrayList();
        ResultSet rs = null;
        try {
            rs = getItemList.executeQuery();
            while (rs.next()) {
                if (rs.getString("offerType").equals("Sell")) {
                    int id = rs.getInt("id");
                    String offerName = rs.getString("offerName");
                    String assetName = rs.getString("assetName");
                    int quantity = rs.getInt("quantity");
                    String unitName = rs.getString("unitName");
                    String offerType = rs.getString("offerType");
                    int price = rs.getInt("price");
                    Offer offer = new Offer(id, offerName, assetName, quantity, unitName, offerType, price);
                    list.add(offer);
                }

            }
        } catch (SQLException | ElectronicPlatformException ex) {
            ex.printStackTrace();
        }
        return list;
    }

    /** get name list from database **/
    public Set<String> getNameList() {
        Set<String> names = new TreeSet<String>();
        ResultSet rs = null;

        try {
            rs = getNameList.executeQuery();
            while (rs.next()) {
                names.add(rs.getString("offerName"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return names;
    }

    @Override
    /** get size of rows from database **/
    public int getSize() {
        ResultSet rs = null;
        int rows = 0;
        try {
            rs = rowCount.executeQuery();
            rs.next();
            rows = rs.getInt(1);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rows;
    }

}
