package src.Common.DAO;

import java.sql.*;
/**
 * This class contains the base dao variables and methods for all extended dao classes.
 *
 * @author CAB302
 * @version 1.0
 */
public class DAOBase {
    /**
     * used for connection.
     */
    protected Connection connection;
    /**
     * used for adding item.
     */
    protected PreparedStatement addItem;
    /**
     * used for getting item list.
     */
    protected PreparedStatement getItemList;
    /**
     * used for getting name list.
     */
    protected PreparedStatement getNameList;
    /**
     * used for getting item.
     */
    protected PreparedStatement getItem;
    /**
     * used for updating item.
     */
    protected PreparedStatement updateItem;
    /**
     * used for deleting item.
     */
    protected PreparedStatement deleteItem;
    /**
     * used for row count.
     */
    protected PreparedStatement rowCount;
    /**
     * used for st.
     */
    protected  Statement st;
    /**
     * These are the client classes which will be sent across the network connection.
     */
    public enum ClientClass {
        /**Asset Class*/
        ASSET,
        /**Unit Class*/
        UNIT,
        /**User Class*/
        USER,
        /**Offer Class*/
        OFFER,
        /**Property Class*/
        PROPERTY,
        /**Trade History Class*/
        TRADEHISTORY
    }

    /**
     * These are the commands which will be sent across the network connection.
     */
    public enum Command {
        /**Add Item Command*/
        ADD_ITEM,
        /**Update Item Command*/
        UPDATE_ITEM,
        /**Delete Item Command*/
        DELETE_ITEM,
        /**Get Item Command*/
        GET_ITEM,
        /**Get Size Command*/
        GET_SIZE,
        /**Get Item List Command*/
        GET_ITEMLIST,
        /**Get Name List Command*/
        GET_NAMELIST
    }
    /**
     * This Function is used for connection.
     */
    public DAOBase(){
        connection = DBConnection.getInstance();
        try {
            st = connection.createStatement();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    /**
     * This Function is used for closing the connection.
     */
    public void close(){
        try {
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
