/**
 This Property_database is used to save all assets information, which includes asset_ID, asset_name, asset_quantity
 and asset_organisational_unit.
 It has four funcitons: add - add a new row of data in the Property types database.
 delete - delete an existing row of data in the Property types database
 update - update the whole list in the Property types database
 search - search for a particular row of data in the Property types database
 */

package src.Common.DAO;
import src.Common.Model.Property;

import java.sql.*;
import java.util.*;

/**
 * This class is used to Store all the details for the asset and unit.
 *
 * @author CAB302
 * @version 1.0
 */
public class DAOProperty extends DAOBase implements IDAOBase<Property>{
    /** Create a new table of data in the property database */
    public static final String CREATE_TABLE =
            "CREATE TABLE IF NOT EXISTS property ("
                    + "id INTEGER PRIMARY KEY /*!40101 AUTO_INCREMENT */ NOT NULL UNIQUE,"
                    + "assetName VARCHAR(80),"
                    + "quantity INTEGER,"
                    + "unitName VARCHAR(80),"
                    + "UNIQUE(assetName, unitName),"
                    + "FOREIGN KEY (assetName) REFERENCES asset (assetName),"
                    + "FOREIGN KEY (unitName) REFERENCES unit (unitName)"
                    + ");";
    /** Insert a new item of data in the property database */
    private static final String INSERT_ITEM = "INSERT INTO property (assetName, quantity, unitName) VALUES (?,?,?);";
    /** Get items from database */
    private static final String GET_ITEMS = "SELECT id, assetName, quantity, unitName FROM property ";
    /** Get names from database */
    private static final String GET_NAMES = "SELECT assetName FROM property ";
    /** Get item from database */
    private static final String GET_ITEM = "SELECT id, assetName,quantity, unitName FROM property WHERE id = ?";
    /** Get another item from database */
    private static final String GET_ITEM2 = "SELECT id, assetName,quantity, unitName FROM property WHERE assetName = ? and unitName = ?";
    /** Update item from database */
    private static final String UPDATE_ITEM ="UPDATE property SET quantity=?, assetName = ?, unitName =? WHERE id = ? ";
    /** Delete item from database */
    private static final String DELETE_ITEM = "DELETE FROM property WHERE id = ?";
    /** Count rows from database */
    private static final String COUNT_ROWS = "SELECT COUNT(*) FROM property";
    /** get another item */
    private PreparedStatement getItem2;

    /** give the value to the variables */
    public DAOProperty(){
      super();
        try{
            st.execute(CREATE_TABLE);
            addItem = connection.prepareStatement(INSERT_ITEM);
            getItemList = connection.prepareStatement(GET_ITEMS);
            getNameList = connection.prepareStatement(GET_NAMES);
            getItem = connection.prepareStatement(GET_ITEM);
            getItem2 = connection.prepareStatement(GET_ITEM2);
            updateItem = connection.prepareStatement(UPDATE_ITEM);
            deleteItem = connection.prepareStatement(DELETE_ITEM);
            rowCount = connection.prepareStatement(COUNT_ROWS);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    @Override
    /** get item from database use id
     * @param id used to find item
     * */
    public Optional<Property> getItem(String id) {
        Property p = new Property();
        ResultSet rs = null;
        try {
            String[] arrSplit = id.split(",");
            if(arrSplit.length > 1){
                getItem2.setString(1, arrSplit[0]);
                getItem2.setString(2, arrSplit[1]);
                rs = getItem2.executeQuery();
            }else{
                getItem.setInt(1, Integer.parseInt(arrSplit[0]));
                rs = getItem.executeQuery();
            }

            rs.next();
            p.setId(rs.getInt("id"));
            p.setAssetName(rs.getString("assetName"));
            p.setUnitName(rs.getString("unitName"));
            p.setQuantity(rs.getInt("quantity"));
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return Optional.of(p);
    }



    @Override
    /** Add item to database
     * @param p an object of Property
     * */
    public boolean addItem(Property p){
        boolean rowAdded = false;
        try {
            addItem.setString(1, p.getAssetName());
            addItem.setInt(2, p.getQuantity());
            addItem.setString(3, p.getUnitName());
            rowAdded = addItem.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rowAdded;
    }

    @Override
    /** Add item list from database
     * */
    public List<Property> getItemList(){
        List<Property> list = new ArrayList();
        ResultSet rs = null;
        try {
            rs = getItemList.executeQuery();
            while(rs.next()){
                int id = rs.getInt("id");
                String assetName = rs.getString("assetName");
                int quantity = rs.getInt("quantity");
                String unitName = rs.getString("unitName");
                Property p = new Property(id, assetName, quantity, unitName);
                list.add(p);

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }
    @Override
    /** Update item from database
     * @param p used for updating item
     * */
    public boolean updateItem(Property p){
        boolean rowUpdated = false;
        try {
            updateItem.setInt(1, p.getQuantity());
            updateItem.setString(2, p.getAssetName());
            updateItem.setString(3, p.getUnitName());
            updateItem.setInt(4, p.getId());
            rowUpdated = updateItem.executeUpdate() > 0;
        }catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rowUpdated;
    }
    @Override
    /** Delete item from database
     * @param id used for finding item
     * */
    public boolean deleteItem(String id){
        boolean rowDeleted = false;
        try {
            deleteItem.setInt(1, Integer.parseInt(id));
            rowDeleted = deleteItem.executeUpdate() > 0;
        }catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rowDeleted;
    }
    @Override
    /** get name item from database
     * */
    public Set<String> getNameList() {
        Set<String> names = new TreeSet<String>();
        ResultSet rs = null;

        try {
            rs = getNameList.executeQuery();
            while (rs.next()) {
                names.add(rs.getString("assetName"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return names;
    }

    @Override
    /** Get size from database
     * */
    public int getSize(){
        ResultSet rs = null;
        int rows = 0;
        try {
            rs = rowCount.executeQuery();
            rs.next();
            rows = rs.getInt(1);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rows;
    }
}
