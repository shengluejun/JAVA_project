/**
 * Organisational_unit_database is used to save information related to organizational units.
 * It has four funcitons: add - add a new row of data in the Asset types database.
 * delete - delete an existing row of data in the Asset types database
 * update - update the whole list in the Asset types database
 * search - search for a particular row of data in the Asset types database
 */
package src.Common.DAO;

import src.Common.Model.Unit;

import java.sql.*;
import java.util.*;

/**
 * This class is used to Store all the details for organisational unit.
 *
 * @author CAB302
 * @version 1.0
 */
public class DAOUnit extends DAOBase implements IDAOBase<Unit> {
    /** Create a new table of data in the property database */
    public static final String CREATE_TABLE =
            "CREATE TABLE IF NOT EXISTS unit ("
                    + "id INTEGER PRIMARY KEY /*!40101 AUTO_INCREMENT */ NOT NULL UNIQUE,"
                    + "unitName VARCHAR(80) UNIQUE,"
                    + "credits INTEGER" + ");";
    /** Insert a item to database */
    private static final String INSERT_ITEM = "INSERT INTO unit (unitName,credits) VALUES (?, ?);";
    /** Delete the item from database */
    private static final String DELETE_ITEM = "DELETE FROM unit WHERE unitName=?;";
    /** Update item from database */
    private static final String UPDATE_ITEM = "UPDATE unit SET unitName=?, credits=? WHERE unitName=?;";
    /** Get item from database */
    private static final String GET_ITEM = "SELECT * FROM unit WHERE unitName=?;";
    /** Get items from database */
    private static final String GET_ITEMS = "SELECT * FROM unit";
    /** Get name list from database */
    private static final String GET_NAMES = "SELECT unitName FROM unit";
    /** Get the number of rows from database */
    private static final String COUNT_ROWS = "SELECT COUNT(*) FROM unit";
    /** give the value to the variables */
    public DAOUnit() {
       super();
       try{
            st.execute(CREATE_TABLE);
            addItem = connection.prepareStatement(INSERT_ITEM);
            getItemList = connection.prepareStatement(GET_ITEMS);
            getNameList = connection.prepareStatement(GET_NAMES);
            getItem = connection.prepareStatement(GET_ITEM);
            updateItem = connection.prepareStatement(UPDATE_ITEM);
            deleteItem = connection.prepareStatement(DELETE_ITEM);
            rowCount = connection.prepareStatement(COUNT_ROWS);
       } catch (SQLException ex) {
            ex.printStackTrace();
       }
    }

    /**
     * Add a new row of data in the Asset types database
     * @param  unit used to add item
     * @return the value of boolean
     */
    @Override
    public boolean addItem(Unit unit) {
        boolean rowAdded = false;
        try {

            addItem.setString(1, unit.getUnitName());
            addItem.setInt(2, unit.getCredits());
            rowAdded = addItem.executeUpdate()>0;

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rowAdded;

    }

    /**
     * Delete an existing row of data in the Asset types database
     * @param name used for deleting item
     * @return the value of boolean
     */
    @Override
    public boolean deleteItem(String name) {
        boolean rowAdded = false;
        try {
            deleteItem.setString(1, name);
            rowAdded = deleteItem.executeUpdate()>0;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rowAdded;
    }

    /**
     * Update the whole list in the Asset types database
     * @param unit used for updating the item
     * @return the value of boolean
     */
    @Override
    public boolean updateItem(Unit unit) {
        boolean rowAdded = false;
        try {
            updateItem.setString(1,unit.getUnitName());
            updateItem.setInt(2,unit.getCredits());
            updateItem.setString(3,unit.getUnitName());
            rowAdded = updateItem.executeUpdate()>0;

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rowAdded;
    }

    /**
     * search for a particular row of data in the Asset types database
     * @param name used to get item
     * @return the object of unit
     */
    @Override
    public Optional<Unit> getItem(String name) {
        Unit u = new Unit();
        ResultSet rs = null;

        try {
            getItem.setString(1, name);
            rs = getItem.executeQuery();
            rs.next();
            u.setUnitName(rs.getString("unitName"));
            u.setCredits(rs.getInt("credits"));
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return Optional.of(u);
    }

    @Override
    /**
     * search for a particular row of data in the Asset types database
     * @return the list of unit
     */
    public List<Unit> getItemList() {
        List<Unit> list = new ArrayList();
        ResultSet rs = null;
        try {
            rs = getItemList.executeQuery();
            while(rs.next()){
                int id = rs.getInt("id");
                String unitName = rs.getString("unitName");
                int credits = rs.getInt("credits");
                Unit u = new Unit(id, unitName, credits);
                list.add(u);

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }
    /**
     * search for a particular row of data in the Asset types database
     * @return the set of string
     */
    public Set<String> getNameList() {
        Set<String> names = new TreeSet<String>();
        ResultSet rs = null;

        try {
            rs = getNameList.executeQuery();
            while (rs.next()) {
                names.add(rs.getString("unitName"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return names;
    }
    @Override
    /**
     * get the size from row count
     * @return the number of size
     */
    public int getSize(){
        ResultSet rs = null;
        int rows = 0;
        try {
            rs = rowCount.executeQuery();
            rs.next();
            rows = rs.getInt(1);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rows;
    }
}
