package src.Common.DAO;

import src.Common.Model.User;

import java.sql.*;
import java.util.*;

/**
 * This class is used to Store all the details for user.
 *
 * @author CAB302
 * @version 1.0
 */
public class DAOUser extends DAOBase implements IDAOBase<User> {
    /** Create a new table of data in the property database */
    public static final String CREATE_TABLE =
            "CREATE TABLE IF NOT EXISTS user ("
                    + "id INTEGER PRIMARY KEY /*!40101 AUTO_INCREMENT */ NOT NULL UNIQUE,"
                    + "userName VARCHAR(80) UNIQUE,"
                    + "password INTEGER,"
                    + "unitName VARCHAR(80),"
                    + "userType VARCHAR(80)"+ ");";
    /** Insert a item to database */
    private static final String INSERT_ITEM = "INSERT INTO user (userName, password, unitName, userType) VALUES (?, ?, ?,?);";
    /** Get items from database */
    private static final String GET_ITEMS = "SELECT id, userName, password, unitName, userType FROM user";
    /** Get a item from database */
    private static final String GET_ITEM = "SELECT userName, password, unitName, userType FROM user WHERE userName=?";
    /** Get names from database */
    private static final String GET_NAMES = "SELECT userName FROM user";
    /** Update items from database */
    private static final String UPDATE_ITEM ="UPDATE user SET userName = ?, password = ?, unitName =?, userType =? WHERE userName = ?";
    /** Delete item from database */
    private static final String DELETE_ITEM = "DELETE FROM user WHERE userName=?";
    /** Count rows from database */
    private static final String COUNT_ROWS = "SELECT COUNT(*) FROM user";

    /** give the value to the variables */
    public DAOUser(){
        super();
        try{
            st.execute(CREATE_TABLE);
            addItem = connection.prepareStatement(INSERT_ITEM);
            getItemList = connection.prepareStatement(GET_ITEMS);
            getNameList = connection.prepareStatement(GET_NAMES);
            getItem = connection.prepareStatement(GET_ITEM);
            updateItem = connection.prepareStatement(UPDATE_ITEM);
            deleteItem = connection.prepareStatement(DELETE_ITEM);
            rowCount = connection.prepareStatement(COUNT_ROWS);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    @Override
    /**
     * get a item from database
     * @param  userName used to get item
     * @return the object of User
     */
    public Optional<User> getItem(String userName) {
        User u = new User();
        ResultSet rs = null;
        try {
            getItem.setString(1, userName);
            rs = getItem.executeQuery();
            rs.next();
            u.setUserName(rs.getString("userName"));
            u.setPassword(rs.getString("password"));
            u.setUnitName(rs.getString("unitName"));
            u.setUserType(rs.getString("userType"));
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return Optional.of(u);
    }



    @Override
    /**
     * add a item to database
     * @param  u used to add item
     * @return the value of boolean
     */
    public boolean addItem(User u){
        boolean rowAdded = false;
        try {
            addItem.setString(1, u.getUserName());
            addItem.setString(2, u.getPassword());
            addItem.setString(3, u.getUnitName());
            addItem.setString(4, u.getUserType());
            rowAdded = addItem.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rowAdded;
    }

    @Override
    /**
     * Get item list from database
     * @return the list of user object
     */
    public List<User> getItemList(){
        List<User> list = new ArrayList();
        ResultSet rs = null;
        try {
            rs = getItemList.executeQuery();
            while(rs.next()){
                int id = rs.getInt("id");
                String userName = rs.getString("userName");
                String password = rs.getString("password");
                String unitName = rs.getString("unitName");
                String userType = rs.getString("userType");
                User u = new User(id, userName, password, unitName, userType);
                list.add(u);

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }

    /**
     * Get name list from database
     * @return string set
     */
    public Set<String> getNameList() {
        Set<String> names = new TreeSet<String>();
        ResultSet rs = null;

        try {
            rs = getNameList.executeQuery();
            while (rs.next()) {
                names.add(rs.getString("userName"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return names;
    }
    @Override
    /**
     * Update item from database
     * @param  u used to add item
     * @return the value of boolean
     */
    public boolean updateItem(User u){
        boolean rowUpdated = false;
        try {
            updateItem.setString(1, u.getUserName());
            updateItem.setString(2, u.getPassword());
            updateItem.setString(3, u.getUnitName());
            updateItem.setString(4, u.getUserType());
            updateItem.setString(5, u.getUserName());
            rowUpdated = updateItem.executeUpdate() > 0;
        }catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rowUpdated;
    }
    @Override
    /**
     * Delete item from database
     * @param  name used to deleting item
     * @return the value of boolean
     */
    public boolean deleteItem(String name){
        ResultSet rs = null;
        boolean rowDeleted = false;
        try {
            deleteItem.setString(1, name);
            rowDeleted = deleteItem.executeUpdate() > 0;
        }catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rowDeleted;
    }
    @Override
    /**
     * Get the size from row count
     * @return the value of number
     */
    public int getSize(){
        ResultSet rs = null;
        int rows = 0;
        try {
            rs = rowCount.executeQuery();
            rs.next();
            rows = rs.getInt(1);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rows;
    }
}
