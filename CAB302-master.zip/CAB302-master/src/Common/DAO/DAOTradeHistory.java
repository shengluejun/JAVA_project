package src.Common.DAO;

import src.Common.Model.TradeHistory;

import java.sql.*;
import java.util.*;
/**
 * This class is used to Store all the details for the trade history.
 *
 * @author CAB302
 * @version 1.0
 */
public class DAOTradeHistory extends DAOBase implements IDAOBase<TradeHistory> {
    /** Create a new table of data in the TradeHistory database */
    public static final String CREATE_TABLE =
            "CREATE TABLE IF NOT EXISTS tradeHistory ("
                    + "id INTEGER PRIMARY KEY /*!40101 AUTO_INCREMENT */ NOT NULL UNIQUE,"
                    + "buyOfferName VARCHAR(200),"
                    + "sellOfferName VARCHAR(200),"
                    + "assetName VARCHAR(200),"
                    + "quantity INTEGER,"
                    + "buyUnitName VARCHAR(80),"
                    + "sellUnitName VARCHAR(80),"
                    + "transactionPrice INTEGER,"
                    + "transactionTime VARCHAR(80)" + ");";

    /** Insert a new item of data in the database */
    private static final String INSERT_ITEM = "INSERT INTO tradeHistory (buyOfferName, sellOfferName, assetName, quantity, buyUnitName, sellUnitName, transactionPrice, transactionTime) VALUES (?, ?, ?,?, ?, ?,?,?);";
    /** Get items of data from the database */
    private static final String GET_ITEMS = "SELECT id, assetName, quantity, transactionPrice, buyOfferName, buyUnitName, sellOfferName,  sellUnitName, transactionTime FROM tradeHistory";
    /** Get a new item of data from the database */
    private static final String GET_ITEM = "SELECT id, buyOfferName, sellOfferName, assetName, quantity, buyUnitName, sellUnitName, transactionPrice, transactionTime FROM tradeHistory WHERE id=?";
    /** Get name list item of data from the database */
    private static final String GET_NAMES = "SELECT sellOfferName FROM tradeHistory";
    /** Update item from the database */
    private static final String UPDATE_ITEM ="UPDATE tradeHistory SET buyOfferName = ?, sellOfferName = ?, assetName =?, quantity =?, buyUnitName =?, sellUnitName =?, transactionPrice=?, transactionTime =?  WHERE id = ?";
    /** Delete item from the database */
    private static final String DELETE_ITEM = "DELETE FROM tradeHistory WHERE id=?";
    /** Count rows from the database */
    private static final String COUNT_ROWS = "SELECT COUNT(*) FROM tradeHistory";

    /** give the value to the variables */
    public DAOTradeHistory(){
        super();
        try{
            st.execute(CREATE_TABLE);
            addItem = connection.prepareStatement(INSERT_ITEM);
            getItemList = connection.prepareStatement(GET_ITEMS);
            getNameList = connection.prepareStatement(GET_NAMES);
            getItem = connection.prepareStatement(GET_ITEM);
            updateItem = connection.prepareStatement(UPDATE_ITEM);
            deleteItem = connection.prepareStatement(DELETE_ITEM);
            rowCount = connection.prepareStatement(COUNT_ROWS);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    @Override
    /** get item from database use id
     * @param id used to find item
     * @return the object of TradeHistory
     * */
    public Optional<TradeHistory> getItem(String id) {
        TradeHistory t = new TradeHistory();
        ResultSet rs = null;
        try {
            getItem.setString(1, id);
            rs = getItem.executeQuery();
            rs.next();
            t.setId(rs.getInt("id"));
            t.setBuyOfferName(rs.getString("buyOfferName"));
            t.setSellOfferName(rs.getString("sellOfferName"));
            t.setAssetName(rs.getString("assetName"));
            t.setQuantity(rs.getInt("quantity"));
            t.setBuyUnitName(rs.getString("buyUnitName"));
            t.setSellUnitName(rs.getString("sellUnitName"));
            t.setTransactionPrice(rs.getInt("transactionPrice"));
            t.setTransactionTime(rs.getString("transactionTime"));
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return Optional.of(t);
    }


    @Override
    /** Add item to database
     * @param t an object of TradeHistory
     * @return boolean value
     * */
    public boolean addItem(TradeHistory t){
        boolean rowAdded = false;
        try {
            addItem.setString(1, t.getBuyOfferName());
            addItem.setString(2, t.getSellOfferName());
            addItem.setString(3, t.getAssetName());
            addItem.setInt(4, t.getQuantity());
            addItem.setString(5, t.getBuyUnitName());
            addItem.setString(6, t.getSellUnitName());
            addItem.setInt(7,t.getTransactionPrice());
            addItem.setString(8, t.getTransactionTime());
            rowAdded = addItem.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rowAdded;
    }

    @Override
    /** Add item list from database
     * @return the list of TradeHistory
     * */
    public List<TradeHistory> getItemList(){
        List<TradeHistory> list = new ArrayList();
        ResultSet rs = null;
        try {
            rs = getItemList.executeQuery();
            while(rs.next()){
                int id = rs.getInt("id");
                String buyOfferName = rs.getString("buyOfferName");
                String sellOfferName = rs.getString("sellOfferName");
                String assetName = rs.getString("assetName");
                int quantity = rs.getInt("quantity");
                String buyUnitName = rs.getString("buyUnitName");
                String sellUnitName = rs.getString("sellUnitName");
                int transactionPrice = rs.getInt("transactionPrice");
                String transactionTime = rs.getString("transactionTime");
                TradeHistory t = new TradeHistory(id, buyOfferName, sellOfferName, assetName, quantity, buyUnitName, sellUnitName, transactionPrice, transactionTime);
                list.add(t);

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }
    @Override
    /** Update item list from database
     * @param t used for updating the item
     * @return the list of TradeHistory
     * */
    public boolean updateItem(TradeHistory t){
        boolean rowUpdated = false;
        try {
            updateItem.setString(1, t.getBuyOfferName());
            updateItem.setString(2, t.getSellOfferName());
            updateItem.setString(3, t.getAssetName());
            updateItem.setInt(4, t.getQuantity());
            updateItem.setString(5, t.getBuyUnitName());
            updateItem.setString(6, t.getSellUnitName());
            updateItem.setInt(7, t.getTransactionPrice());
            updateItem.setString(8, t.getTransactionTime());
            updateItem.setInt(9, t.getId());
            rowUpdated = updateItem.executeUpdate() > 0;
        }catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rowUpdated;
    }
    @Override
    /** Delete item list from database
     * @param id used to find item
     * @return the value of boolean
     * */
    public boolean deleteItem(String id){
        ResultSet rs = null;
        boolean rowDeleted = false;
        try {
            deleteItem.setInt(1, Integer.parseInt(id));
            rowDeleted = deleteItem.executeUpdate() > 0;
        }catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rowDeleted;
    }

    /** get item list from database
     * @return the set of string
     * */
    public Set<String> getNameList() {
        Set<String> names = new TreeSet<String>();
        ResultSet rs = null;

        try {
            rs = getNameList.executeQuery();
            while (rs.next()) {
                names.add(rs.getString("sellOfferName"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return names;
    }
    @Override
    /** get the size from database
     * @return the number of size
     * */
    public int getSize(){
        ResultSet rs = null;
        int rows = 0;
        try {
            rs = rowCount.executeQuery();
            rs.next();
            rows = rs.getInt(1);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rows;
    }
}

