/**
This Asset_database is used to save all assets information, which includes asset_ID, asset_name, asset_quantity
and asset_organisational_unit.
It has four funcitons: add - add a new row of data in the Asset types database.
                        delete - delete an existing row of data in the Asset types database
                        update - update the whole list in the Asset types database
                        search - search for a particular row of data in the Asset types database
 */

package src.Common.DAO;
import src.Common.Model.Asset;

import java.sql.*;
import java.util.*;

/**
 * This class is used to Store all the details for the asset.
 *
 * @author CAB302
 * @version 1.0
 */
public class DAOAsset extends DAOBase implements IDAOBase<Asset> {
    /**
     * create table sql statement
     */
    protected static final String CREATE_TABLE =
            "CREATE TABLE IF NOT EXISTS asset ("
                    + "id INTEGER PRIMARY KEY /*!40101 AUTO_INCREMENT */ NOT NULL UNIQUE,"
                    + "assetName VARCHAR(80) UNIQUE,"
                    + "assetDescription VARCHAR(200)"
                    + ");";
    /**
     * insert item sql statement
     */
    protected static final String INSERT_ITEM = "INSERT INTO asset (assetName, assetDescription) VALUES (?,?);";
    /**
     * get items sql statement
     */
    protected static final String GET_ITEMS = "SELECT id, assetName, assetDescription FROM asset";
    /**
     * get names sql statement
     */
    protected static final String GET_NAMES = "SELECT assetName FROM asset";
    /**
     * get item sql statement
     */
    protected static final String GET_ITEM = "SELECT assetName,assetDescription FROM asset WHERE assetName=?";
    /**
     * update item sql statement
     */
    protected static final String UPDATE_ITEM ="UPDATE asset SET assetName =?, assetDescription=? WHERE assetName = ?";
    /**
     * delete item sql statement
     */
    protected static final String DELETE_ITEM = "DELETE FROM asset WHERE assetName=?";
    /**
     * get count rows sql statement
     */
    protected static final String COUNT_ROWS = "SELECT COUNT(*) FROM asset";


    /**
     * Initialize the database include creating table and sql statement.
     * - no param
     */
    public DAOAsset(){
        super();
        try{
            st.execute(CREATE_TABLE);
            addItem = connection.prepareStatement(INSERT_ITEM);
            getItemList = connection.prepareStatement(GET_ITEMS);
            getNameList = connection.prepareStatement(GET_NAMES);
            getItem = connection.prepareStatement(GET_ITEM);
            updateItem = connection.prepareStatement(UPDATE_ITEM);
            deleteItem = connection.prepareStatement(DELETE_ITEM);
            rowCount = connection.prepareStatement(COUNT_ROWS);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * get an item from database.
     * @param name Use the name to locate the item to be got.
     */
    @Override
    public Optional<Asset> getItem(String name) {
        Asset a = new Asset();
        ResultSet rs = null;
        try {
            getItem.setString(1, name);
            rs = getItem.executeQuery();
            rs.next();
            a.setAssetName(rs.getString("assetName"));
            a.setAssetDescription(rs.getString("assetDescription"));
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return Optional.of(a);
    }


    /**
     * add an item to database.
     * @param a the item to be added.
     */
    @Override
    public boolean addItem(Asset a){
        boolean rowAdded = false;
        try {
            addItem.setString(1, a.getAssetName());
            addItem.setString(2, a.getAssetDescription());
            rowAdded = addItem.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rowAdded;
    }

    /**
     * get item list from database.
     * - no param.
     */
    @Override
    public List<Asset> getItemList(){
        List<Asset> list = new ArrayList();
        ResultSet rs = null;
        try {
            rs = getItemList.executeQuery();
            while(rs.next()){
                int id = rs.getInt("id");
                String name = rs.getString("assetName");
                String description = rs.getString("assetDescription");
                Asset a = new Asset(name, description);
                list.add(a);

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }

    /**
     * update an item from database.
     * @param a the item to be updated.
     */
    @Override
    public boolean updateItem(Asset a){
        boolean rowUpdated = false;
        try {
            updateItem.setString(1, a.getAssetName());
            updateItem.setString(2, a.getAssetDescription());
            updateItem.setString(3, a.getAssetName());
            rowUpdated = updateItem.executeUpdate() > 0;
        }catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rowUpdated;
    }

    /**
     * Delete an item from database.
     * @param name use the name to locate the item.
     */
    @Override
    public boolean deleteItem(String name){
        boolean rowDeleted = false;
        try {
            deleteItem.setString(1, name);
            rowDeleted = deleteItem.executeUpdate() > 0;
        }catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rowDeleted;
    }

    /**
     * Get item list from database.
     * - no param.
     */
    @Override
    public Set<String> getNameList() {
        Set<String> names = new TreeSet<String>();
        ResultSet rs = null;

        try {
            rs = getNameList.executeQuery();
            while (rs.next()) {
                names.add(rs.getString("assetName"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return names;
    }

    /**
     * Count row number from database.
     * - no param.
     */
    @Override
    public int getSize(){
        ResultSet rs = null;
        int rows = 0;
        try {
            rs = rowCount.executeQuery();
            rs.next();
            rows = rs.getInt(1);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rows;
    }
}
