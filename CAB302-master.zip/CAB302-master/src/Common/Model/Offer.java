package src.Common.Model;

import src.Common.ElectronicPlatformException;

import java.io.Serializable;
/**
 * This Class is for offer details.
 * @author CAB302
 * @version 1.0
 */
public class Offer implements Serializable {

    private static final long serialVersionUID = -7092701502990374424L;
    private int id;
    private String offerName;
    private String assetName;
    private int quantity;
    private String unitName;
    private String offerType;
    private int price;

    /**
     * Initialize
     */
    public Offer(){}
    /**
     * Initialize all the value
     * @param offerName the offer Name
     * @param assetName the assetName
     * @param quantity  the quantity
     * @param unitName  the unit Name
     * @param offerType the offer Type
     * @param price the price
     * @throws  ElectronicPlatformException Electronic Platform Exception
     */
    public Offer(String offerName, String assetName, int quantity, String unitName, String offerType, int price)
            throws ElectronicPlatformException {
        // Sanity checks on parameters (NB: The checks imply
        // that the quantity and retail price must be non-negative, so we don't need to
        // check this explicitly)
        if (quantity < 0) {
            throw new ElectronicPlatformException("Quantity cannot be negative");
        };
        if (price < 0) {
            throw new ElectronicPlatformException("Price cannot be negative");
        };
        this.offerName = offerName;
        this.assetName = assetName;
        this.quantity = quantity;
        this.unitName = unitName;
        this.offerType = offerType;
        this.price = price;
    }
    /**
     * Initialize all the value
     * @param id the id
     * @param offerName the offer Name
     * @param assetName the assetName
     * @param quantity  the quantity
     * @param unitName  the unit Name
     * @param offerType the offer Type
     * @param price the price
     * @throws  ElectronicPlatformException Electronic Platform Exception
     *
     */
    public Offer(int id, String offerName, String assetName, int quantity, String unitName, String offerType, int price)
            throws ElectronicPlatformException {
        // Sanity checks on parameters (NB: The checks imply
        // that the quantity and retail price must be non-negative, so we don't need to
        // check this explicitly)
        if (quantity < 0) {
            throw new ElectronicPlatformException("Quantity cannot be negative");
        };
        if (price < 0) {
            throw new ElectronicPlatformException("Price cannot be negative");
        };
        this.id = id;
        this.offerName = offerName;
        this.assetName = assetName;
        this.quantity = quantity;
        this.unitName = unitName;
        this.offerType = offerType;
        this.price = price;
    }
    /**
     * Get id
     * @return id
     */
    public int getId() {
        return id;
    }
    /**
     * Set id
     * @param  id the id
     */
    public void setId(int id) {
        this.id = id;
    }
    /**
     * Get offer name
     * @return  the string of get offer name
     */
    public String getOfferName() {
        return offerName;
    }
    /**
     * Set offer name
     * @param  offerName string of get offer name
     */
    public void setOfferName(String offerName) {
        this.offerName = offerName;
    }
    /**
     * Get asset name
     * @return the string of asset name
     */
    public String getAssetName() {
        return assetName;
    }
    /**
     * Set asset name
     * @param  assetName the string of asset name
     */
    public void setAssetName(String assetName) {
        this.assetName = assetName;
    }
    /**
     * Get quantity
     * @return  the quantity of item
     */
    public int getQuantity() {
        return quantity;
    }
    /**
     * Set quantity
     * @param quantity quantity of item
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     * Get Unit Name
     * @return  the unit name
     */
    public String getUnitName() {
        return unitName;
    }
    /**
     * Set Unit Name
     * @param  unitName the unit name
     */
    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }
    /**
     * Get Offer Type
     * @return  the string of Offer Type
     */
    public String getOfferType() {
        return offerType;
    }
    /**
     * Set Offer Type
     * @param offerType the Offer Type
     */
    public void setOfferType(String offerType) {
        this.offerType = offerType;
    }
    /**
     * Get the price
     * @return  the value of price
     */
    public int getPrice() {
        return price;
    }
    /**
     * Set the price
     * @param price the price value
     */
    public void setPrice(int price) {
        this.price = price;
    }
    /**
     * Get the string
     * @return  the string
     */
    public String toString() {
        return offerName + " " + assetName + " " + quantity + " " + unitName + " " + offerType + " " + price;
    }
}

