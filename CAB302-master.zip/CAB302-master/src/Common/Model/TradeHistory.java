package src.Common.Model;

import java.io.Serializable;

/**
 * This Class is for trade history details.
 * @author CAB302
 * @version 1.0
 */
public class TradeHistory implements Serializable {

    private static final long serialVersionUID = -7092701502990374424L;
    private int id;
    private String buyOfferName;
    private String sellOfferName;
    private String assetName;
    private int quantity;
    private String buyUnitName;
    private String sellUnitName;
    private int transactionPrice;
    private String transactionTime;
    /**
     * Initialize
     */
    public TradeHistory(){}
    /**
     * Initialize all the value
     * @param buyOfferName the buy Offer Name
     * @param sellOfferName the sell Offer Name
     * @param assetName  the asset Name
     * @param quantity  the quantity
     * @param buyUnitName  the buy Unit Name
     * @param sellUnitName  the sell Unit Name
     * @param transactionPrice  the tran sanction Price
     */
    public TradeHistory(String buyOfferName, String sellOfferName, String assetName, int quantity, String buyUnitName, String sellUnitName, int transactionPrice) {

        this.buyOfferName = buyOfferName;
        this.sellOfferName = sellOfferName;
        this.assetName = assetName;
        this.quantity = quantity;
        this.buyUnitName = buyUnitName;
        this.sellUnitName = sellUnitName;
        this.transactionPrice = transactionPrice;
    }
    /**
     * Initialize all the value
     * @param buyOfferName the buy Offer Name
     * @param sellOfferName the sell Offer Name
     * @param assetName  the asset Name
     * @param quantity  the quantity
     * @param buyUnitName  the buy Unit Name
     * @param sellUnitName  the sell Unit Name
     * @param transactionPrice  the tran sanction Price
     * @param transactionTime the transactionTime
     */
    public TradeHistory(String buyOfferName, String sellOfferName, String assetName, int quantity, String buyUnitName, String sellUnitName, int transactionPrice, String transactionTime)
    {
        this (buyOfferName, sellOfferName, assetName, quantity, buyUnitName, sellUnitName, transactionPrice);
        this.transactionTime = transactionTime;
    }
    /**
     * Initialize all the value
     * @param id the id
     * @param buyOfferName the buy Offer Name
     * @param sellOfferName the sell Offer Name
     * @param assetName  the asset Name
     * @param quantity  the quantity
     * @param buyUnitName  the buy Unit Name
     * @param sellUnitName  the sell Unit Name
     * @param transactionPrice  the tran sanction Price
     * @param transactionTime the transactionTime
     */
    public TradeHistory(int id, String buyOfferName, String sellOfferName, String assetName, int quantity, String buyUnitName, String sellUnitName, int transactionPrice, String transactionTime) {

        this (buyOfferName, sellOfferName, assetName, quantity, buyUnitName, sellUnitName, transactionPrice);
        this.id = id;
        this.transactionTime = transactionTime;
    }

    /**
     * Get id
     * @return  the id
     */
    public int getId() {
        return id;
    }
    /**
     * Set id
     * @param id the id
     */
    public void setId(int id) {
        this.id = id;
    }
    /**
     * Get get Buy Offer Name
     * @return  the get Buy Offer Name
     */
    public String getBuyOfferName() {
        return buyOfferName;
    }
    /**
     * Set Buy Offer Name
     * @param buyOfferName the buy Offer Name
     */
    public void setBuyOfferName(String buyOfferName) {
        this.buyOfferName = buyOfferName;
    }
    /**
     * Get get Sell Offer Name
     * @return  the Sell Offer Name
     */
    public String getSellOfferName() {
        return sellOfferName;
    }
    /**
     * Set sell Offer Name
     * @param sellOfferName the sell Offer Name
     */
    public void setSellOfferName(String sellOfferName) {
        this.sellOfferName = sellOfferName;
    }

    /**
     * Get get Asset Name
     * @return  the Asset Name
     */
    public String getAssetName() {
        return assetName;
    }
    /**
     * Set asset Name
     * @param assetName the asset Name
     */
    public void setAssetName(String assetName) {
        this.assetName = assetName;
    }
    /**
     * Get get Quantity
     * @return  the Quantity
     */
    public int getQuantity() {
        return quantity;
    }
    /**
     * Set Quantity
     * @param quantity the quantity
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    /**
     * Get get Buy Unit Name
     * @return  the Buy Unit Name
     */
    public String getBuyUnitName() {
        return buyUnitName;
    }
    /**
     * Set buy Unit Name
     * @param buyUnitName the buy Unit Name
     */
    public void setBuyUnitName(String buyUnitName) {
        this.buyUnitName = buyUnitName;
    }
    /**
     * Get Sell Unit Name
     * @return  the Sell Unit Name
     */
    public String getSellUnitName() {
        return sellUnitName;
    }
    /**
     * Set sellUnitName
     * @param sellUnitName the sell Unit Name
     */
    public void setSellUnitName(String sellUnitName) {
        this.sellUnitName = sellUnitName;
    }

    /**
     * Get Transaction Price
     * @return  the value of TransactionPrice
     */
    public int getTransactionPrice() {
        return transactionPrice;
    }
    /**
     * Set Transaction Price
     * @param transactionPrice the value of transactionPrice
     */
    public void setTransactionPrice(int transactionPrice) {
        this.transactionPrice = transactionPrice;
    }
    /**
     * Get Transaction Time
     * @return  the string of Transaction Time
     */
    public String getTransactionTime() {
        return transactionTime;
    }
    /**
     * Set transactionTime
     * @param transactionTime the string of transactionTime
     */
    public void setTransactionTime(String transactionTime) {
        this.transactionTime = transactionTime;
    }
    /**
     * Get the string
     * @return  the string of Transaction Time
     */
    public String toString() {
        return buyOfferName + " " + sellOfferName + " " + assetName + " " + quantity + " " + buyUnitName + " " + sellUnitName + " " + transactionPrice + " " + transactionTime;
    }
}
