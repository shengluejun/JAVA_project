package src.Common.Model;

import java.io.Serializable;

/**
 * This Class is for asset details.
 * @author CAB302
 * @version 1.0
 */
public class Asset implements Serializable {

    private static final long serialVersionUID = -7092701502990374424L;
    private int id;
    private String assetName;
    private String assetDescription;
    /**
     * give the value initially
     */
    public Asset(){
    }
    /**
     * give the value initially
     * @param assetName the asset Name
     */
    public Asset(String assetName) {
        this.assetName = assetName;
    }
    /**
     * give the value initially
     * @param assetName the asset Name
     * @param assetDescription the asset Description
     */
    public Asset(String assetName, String assetDescription) {
        this.assetName = assetName;
        this.assetDescription = assetDescription;
    }
    /**
     * get the id value
     * @return the id value
     */
    public int getId() { return id;}
    /**
     * get the asset name
     * @return asset name
     */
    public String getAssetName() {
        return assetName;
    }
    /**
     * set the asset name
     * @param assetName the asset Name
     */
    public void setAssetName(String assetName) {
        this.assetName = assetName;
    }
    /**
     * get Asset Description
     * @return Asset Description
     */
    public String getAssetDescription() {
        return assetDescription;
    }
    /**
     * set Asset Description
     * @param assetDescription the asset Description
     */
    public void setAssetDescription(String assetDescription) {
        this.assetDescription = assetDescription;
    }
    /**
     * get the string
     * @return string
     */
    public String toString() {
        return assetName + " " + assetDescription;
    }

}
