package src.Common.Model;

import java.io.Serializable;

/**
 * This Class is for unit details.
 * @author CAB302
 * @version 1.0
 */
public class Unit implements Serializable {

    private static final long serialVersionUID = -7092701502990374424L;
    private int id;
    private String unitName;
    private int credits;
    /**
     * Initialize
     */
    public Unit() {
    }
    /**
     * Initialize all the value
     * @param unitName the unit Name
     * @param credits the credits
     */
    public Unit( String unitName, int credits) {
        this.unitName = unitName;
        this.credits = credits;
    }
    /**
     * Initialize all the value
     * @param id the id
     * @param unitName the unit Name
     * @param credits the credits
     */
    public Unit(int id, String unitName, int credits) {
        this.id = id;
        this.unitName = unitName;
        this.credits = credits;
    }
    /**
     * Get get id
     * @return  the id
     */
    public int getId() {
        return id;
    }
    /**
     * Set id
     * @param id the id
     */
    public void setId(int id) {
        this.id = id;
    }
    /**
     * Get get Unit Name
     * @return the Unit Name
     */
    public String getUnitName() {
        return unitName;
    }
    /**
     * Set Unit Name
     * @param unitName the unit Name
     */
    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }
    /**
     * Get get Credits
     * @return the Credits
     */
    public int getCredits() {
        return credits;
    }
    /**
     * Set Credits
     * @param credits the Credits
     */
    public void setCredits(int credits) {
        this.credits = credits;
    }
    /**
     * Get the string
     * @return the string
     */
    public String toString() {
        return unitName + " " + credits;
    }

}
