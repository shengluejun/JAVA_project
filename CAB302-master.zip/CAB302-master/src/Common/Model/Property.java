package src.Common.Model;

import java.io.Serializable;
/**
 * This Class is for property details.
 * @author CAB302
 * @version 1.0
 */
public class Property implements Serializable {
    private static final long serialVersionUID = -7092701502990374424L;
    private int id;
    private String assetName;
    private int quantity;
    private String unitName;
    /**
     * Initialize
     */
    public Property(){
    }
    /**
     * Initialize all the value
     * @param assetName the offer Name
     * @param quantity the assetName
     * @param unitName  the quantity
     *
     */
    public Property(String assetName, int quantity, String unitName) {
        this.assetName = assetName;
        this.quantity = quantity;
        this.unitName = unitName;
    }
    /**
     * Initialize all the value
     *
     * @param id the id
     * @param assetName the offer Name
     * @param quantity the assetName
     * @param unitName  the quantity
     *
     */
    public Property(int id, String assetName, int quantity, String unitName) {
        this.id = id;
        this.assetName = assetName;
        this.quantity = quantity;
        this.unitName = unitName;
    }
    /**
     * Get id
     * @return id
     */
    public int getId() { return id;}
    /**
     * Set id
     * @param  id the id
     */
    public void setId(int id) { this.id = id; }
    /**
     * Get Asset Name
     * @return the Asset Name
     */
    public String getAssetName() {
        return assetName;
    }
    /**
     * Set Asset Name
     * @param  assetName the asset Name
     */
    public void setAssetName(String assetName) {
        this.assetName = assetName;
    }
    /**
     * Get Quantity
     * @return the value of quantity
     */
    public int getQuantity() {
        return quantity;
    }
    /**
     * Set quantity
     * @param  quantity the quantity
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    /**
     * Get Unit Name
     * @return the string of Unit Name
     */
    public String getUnitName() {
        return unitName;
    }
    /**
     * Set Unit Name
     * @param  unitName the unit Name
     */
    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }
    /**
     * Get the string
     * @return the string of asset Name
     */
    public String toString() {
        return assetName;
    }
}
