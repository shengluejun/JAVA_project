package src.Common.Model;

import java.io.Serializable;



/**
 * This Class can realise many functionality including login, logout, changePassword and so on.
 * @author CAB302
 * @version 1.0
 */
public class User implements Serializable {

    private static final long serialVersionUID = -7092701502990374424L;
    private int id;
    private String userName;
    /** user's account name */
    private String password;
    /** user's account password */

    private String unitName;
    /** user belongs to which organisational unit */
    private String userType;
    /** verify user's permission */
    /**
     * Initialize
     */
    public User(){}
    /**
     * Initialize all the value
     * @param userName the unit Name
     * @param password the password
     */
    public User(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }
    /**
     * Initialize all the value
     * @param userName the unit Name
     * @param password the password
     * @param userType the userType
     */
    public User(String userName, String password, String userType) {
        this.userName = userName;
        this.password = password;
        this.userType = userType;
    }
    /**
     * Initialize all the value
     * @param userName the unit Name
     * @param password the password
     * @param userType the userType
     * @param unitName the unitNam
     */
    public User(String userName, String password, String unitName, String userType) {
        this.userName = userName;
        this.password = password;
        this.unitName = unitName;
        this.userType = userType;
    }
    /**
     * Initialize all the value
     * @param id the id
     * @param userName the unit Name
     * @param password the password
     * @param userType the userType
     * @param unitName the unitNam
     */
    public User(int id, String userName, String password, String unitName, String userType) {
        this.id = id;
        this.userName = userName;
        this.password = password;
        this.unitName = unitName;
        this.userType = userType;
    }
        /**
     * Initialize all the value
     * @param id the id
     * @param userName the unit Name
     * @param password the password
     * @param userType the userType
     */
    public User(int id, String userName, String password, String userType) {
        this.id = id;
        this.userName = userName;
        this.password = password;
        this.userType = userType;
    }

    /**
     * Get get id
     * @return  the id
     */
    public int getId() {
        return id;
    }
    /**
     * Set id
     * @param id the id
     */
    public void setId(int id) {
        this.id = id;
    }
    /**
     * Get get User Name
     * @return  the User Name
     */
    public String getUserName() {
        return userName;
    }
    /**
     * Set user Name
     * @param userName the user Name
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }
    /**
     * Get get Password
     * @return  the Password
     */
    public String getPassword() {
        return password;
    }
    /**
     * Set Password
     * @param password the Password
     */
    public void setPassword(String password) {
        this.password = password;
    }
    /**
     * Get get Unit Name
     * @return  the Unit Name
     */
    public String getUnitName() {
        return unitName;
    }
    /**
     * Set unit Name
     * @param unitName the unit Name
     */
    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }
    /**
     * Get user Type
     * @return  userType Type the user Type
     */
    public String getUserType() {
        return userType;
    }
    /**
     * Set User Type
     * @param userType the User Type
     */
    public void setUserType(String userType) {
        this.userType = userType;
    }
    /**
     * Get the string of the class object
     * @return  the string
     */
    public String toString() {
        return userName + " " + password + " " + unitName + " " + userType;
    }

}
