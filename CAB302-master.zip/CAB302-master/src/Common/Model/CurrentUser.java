package src.Common.Model;
/**
 * This Class is for storing logged in user name, user unit name, user type.
 * @author CAB302
 * @version 1.0
 */
public class CurrentUser{
    private static final CurrentUser instance = new CurrentUser();
    private CurrentUser(){}
    /**
     * get the instance
     * @return the static CurrentUser
     */
    public static CurrentUser getInstance() {
        return instance;
    }
    private String currentUserName;
    private String currentUserUnit;
    private String currentUserType;
    private int currentPort;
    /**
     * Get Current User Name
     * @return the current User Name
     */
    public String getCurrentUserName(){ return currentUserName;}
    /**
     * Set Current User Name
     * @param userName User Name
     */
    public void setCurrentUserName(String userName){this.currentUserName = userName;}
    /**
     * Get Current User Unit
     * @return the string of Current User Unit
     */
    public String getCurrentUserUnit(){return currentUserUnit;}
    /**
     * Set Current User Unit
     * @param userUnit the user Unit
     */
    public void setCurrentUserUnit(String userUnit){this.currentUserUnit = userUnit;}
    /**
     * Get Current User Type
     * @return the string of user type
     */
    public String getCurrentUserType(){ return currentUserType;}
    /**
     * Get Current User Type
     * @param UserType string of user type
     */
    public void setCurrentUserType(String UserType){this.currentUserType = UserType;}
}
