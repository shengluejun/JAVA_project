package src.Common;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
/**
 * This class is used to read all the details to get host name and port no for both client side and server side.
 * It contains to read host name and port attributes from server.props.
 * And then store them into ServerInfo class object for client and server to read.
 *
 * @author CAB302
 * @version 1.0
 */
public class ServerConnection {

    /**
     * The singleton instance of the server connection.
     */
    private static ServerInfo instance = null;


    /**
     * Constructor intializes the server connection.
     */
    private ServerConnection() {
        Properties props = new Properties();
        FileInputStream in = null;
        try {
            in = new FileInputStream("src/Common/server.props");
            props.load(in);
            in.close();

            // specify ip address, port
            String ipAddress = props.getProperty("hostName");
            String port = props.getProperty("port");

            // get a server connection instance
            instance = new ServerInfo(ipAddress, Integer.valueOf(port));
        } catch (FileNotFoundException fnfe) {
            System.err.println(fnfe);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Provides global access to the singleton instance of the UrlSet.
     *
     * @return a handle to the singleton instance of the UrlSet.
     */
    public static ServerInfo getInstance() {
        if (instance == null) {
            new ServerConnection();
        }
        return instance;
    }

    /**
     * It's used to store server host name and port number.
     */
    public class ServerInfo{
        private String hostName;
        private int port;
        /**
         * It's used to give the value to port.
         * @param hostName used as name
         * @param port used number as port
         */
        public ServerInfo(String hostName, int port){
            this.hostName = hostName;
            this.port = port;
        }
        /**
         * just return value
         * @return port number
         */
        public String getHostName(){
            return this.hostName;
        }
        /**
         * just return value
         * @return  the host name
         */
        public int getPort(){
            return this.port;
        }
    }
}
