package src.Client.UI;

import src.Client.Data.PropertyData;
import src.Client.Data.TradeHistoryData;
import src.Common.Model.*;
import src.Client.DAONetworkClient;
import src.Client.Data.OfferData;
import src.Client.Data.UserData;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.*;
/**
 * This class contains the main UI for a offer management.
 * It includes view current sell offers, buy offers, add/update/delete/view my sell offers, my buy offers.
 * It also allows user to access to the current property list of the user's unit.
 * And the user also can view the recent trade history by clicking "trade history" button right on top right corner of the frame.
 * The server will do the scheduled job to match sell offers and buy offers. When matches, will pop up a dialogue to user to
 * remind user that his/her offer was processed. Click "Refresh" button will get the latest unprocessed offers on this frame.
 * Click "trade history" can view all the trade history list.
 * The user can sort trade history by clicking transaction time header to get the latest trade list.
 * User is also able to filter out the trade history list by put some text on filter text field.
 * On Offer Table UI, user can also filter current buy offer list/sell offer list/my buy offer list/my sell offer list
 * by put unit name, asset name and filter text.
 *
 * @author CAB302
 * @version 1.0
 */
public class OfferTableUI extends JFrame {

    private static final long serialVersionUID = -5050538890770582361L;

    private JLabel profileLabel;
    private JButton refreshButton;
    private JButton tradeHistoryButton;
    private JButton myPropertyButton;

    private JTable currentBuyTable;
    private JTable currentSellTable;
    private JTable myBuyTable;
    private JTable mySellTable;

    private JTextField id;
    private JTextField offerName;
    private JComboBox assetName;
    private JTextField quantity;
    private JTextField unitName;
    private JComboBox offerType;
    private JTextField price;
    private JButton newButton;
    private JButton resetButton;
    private JButton saveButton;
    private JButton deleteButton;

    private JComboBox assetFilter;
    private JComboBox unitFilter;

    private JTextField filterText;
    private JButton queryButton;
    private JButton clearButton;
    private JButton exitButton;

    private DefaultTableModel currentBuyTableModel;
    private DefaultTableModel currentSellTableModel;
    private DefaultTableModel myBuyTableModel;
    private DefaultTableModel mySellTableModel;
    /**
     * create an OfferData object
     */

    OfferData data;

    private JFrame frame;
    private Container contentPane;
    final static String CURRENTBUYPANEL = "Current Buy Offers";
    final static String CURRENTSELLPANEL = "Current Sell Offers";
    final static String MYBUYPANEL = "My Buy Offers";
    final static String MYSELLPANEL = "My Sell Offers";

    final static int extraWindowWidth = 100;

    private String currentUnit;
    private String currentUser;
    private String availableCredits;
    private String strProfile;
    private int assetQuantity;
    /**
     * Create Offer table UI
     */

    public OfferTableUI() {
    }

    /**
     * Constructor sets up user interface, adds listeners and displays.
     *
     * @param data The underlying data/model class the UI needs.
     */
    public OfferTableUI(OfferData data) {
        this.data = data;
        currentUnit = CurrentUser.getInstance().getCurrentUserUnit() == null ? "" : CurrentUser.getInstance().getCurrentUserUnit();
        currentUser = CurrentUser.getInstance().getCurrentUserName() == null ? "" : CurrentUser.getInstance().getCurrentUserName();
        availableCredits = this.data.GetAvailableCredits();
        strProfile = currentUnit + " " + currentUser + " Your available credits: " + availableCredits;

        currentBuyTableModel = data.getCurrentBuyTableModel();
        currentSellTableModel = data.getCurrentSellTableModel();
        myBuyTableModel = data.getMyBuyTableModel();
        mySellTableModel = data.getMySellTableModel();

        initUI();

        // add listeners to interactive components
        addTableSelectListeners(new OfferTableUI.TableListListener());
        addButtonListeners(new OfferTableUI.ButtonListener());
        addAssetNameListener(new OfferTableUI.ItemChangeListener());
        addClosingListener(new OfferTableUI.ClosingListener());

        // decorate the frame and make it visible
        setTitle("Electronic Asset Trading Platform");
        setMinimumSize(new Dimension(1000, 760));
        pack();
        setVisible(true);
    }

    /**
     * Places the detail panel and the button panel in a box layout with vertical
     * alignment and puts a 20 pixel gap between the components and the top and
     * bottom edges of the frame.
     */
    private void initUI() {
        frame = this.frame;
        contentPane = this.getContentPane();
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
        contentPane.add(Box.createVerticalStrut(20));
        contentPane.add(makeHeaderPanel());
        contentPane.add(Box.createVerticalStrut(20));
        contentPane.add(makeTablesPanel());
        contentPane.add(Box.createVerticalStrut(20));
        contentPane.add(makeEditPanel());
        contentPane.add(Box.createVerticalStrut(20));
        contentPane.add(makeButtonsPanel());
        contentPane.add(Box.createVerticalStrut(20));
    }

    private JPanel makeHeaderPanel() {
        JPanel headerPanel = new JPanel();

        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.X_AXIS));
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        profileLabel = new JLabel("Welcome! " + strProfile);

        tradeHistoryButton = new JButton("Trade History");
        myPropertyButton = new JButton("My Property");
        refreshButton = new JButton("Refresh");

        panel.add(profileLabel, BorderLayout.LINE_START);

        panel.add(myPropertyButton, BorderLayout.LINE_END);

        headerPanel.add(Box.createHorizontalStrut(20));
        headerPanel.add(panel);
        headerPanel.add(Box.createHorizontalStrut(20));
        headerPanel.add(tradeHistoryButton);
        headerPanel.add(Box.createHorizontalStrut(20));
        headerPanel.add(refreshButton);
        headerPanel.add(Box.createHorizontalStrut(20));


        return headerPanel;
    }

    /**
     * Makes a panel.
     * @return the detail panel.
     */
    private JTabbedPane makeTablesPanel() {
        JTabbedPane tabbedPane = new JTabbedPane(
                JTabbedPane.SCROLL_TAB_LAYOUT);


        /**
         * Makes a Table to display the main transaction window.
         * @return the detail table.
         */
        currentBuyTable = new JTable(this.currentBuyTableModel) {
            public boolean isCellEditable(int nRow, int nCol) {
                if (nCol == 0)
                    return false;
                return true;
            }
        };
        currentBuyTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane1 = new JScrollPane(currentBuyTable);
        currentBuyTable.setFillsViewportHeight(true);
        currentBuyTable.setAutoCreateRowSorter(true);
        HideIdColumn(currentBuyTable);
        SetColumnWidth(currentBuyTable);
        scrollPane1
                .setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane1
                .setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        currentSellTable = new JTable(this.currentSellTableModel);
        JScrollPane scrollPane2 = new JScrollPane(currentSellTable);
        currentSellTable.setFillsViewportHeight(true);
        currentSellTable.setAutoCreateRowSorter(true);
        HideIdColumn(currentSellTable);
        SetColumnWidth(currentSellTable);
        scrollPane2
                .setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane2
                .setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        myBuyTable = new JTable(this.myBuyTableModel);
        JScrollPane scrollPane3 = new JScrollPane(myBuyTable);
        myBuyTable.setFillsViewportHeight(true);
        myBuyTable.setAutoCreateRowSorter(true);

        HideIdColumn(myBuyTable);
        SetColumnWidth(myBuyTable);

        scrollPane3
                .setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane3
                .setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        mySellTable = new JTable(this.mySellTableModel);
        JScrollPane scrollPane4 = new JScrollPane(mySellTable);
        mySellTable.setFillsViewportHeight(true);
        mySellTable.setAutoCreateRowSorter(true);

        HideIdColumn(mySellTable);
        SetColumnWidth(mySellTable);
        scrollPane4
                .setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane4
                .setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane1.setPreferredSize(new Dimension(980, 400));
        scrollPane2.setPreferredSize(new Dimension(980, 400));
        scrollPane3.setPreferredSize(new Dimension(980, 400));
        scrollPane4.setPreferredSize(new Dimension(980, 400));


        //Create the "cards".
        JPanel currentBuyCard = new JPanel();
        currentBuyCard.add(scrollPane1);

        JPanel currentSellCard = new JPanel();
        currentSellCard.add(scrollPane2);

        JPanel myBuyCard = new JPanel();
        myBuyCard.add(scrollPane3);

        JPanel mySellCard = new JPanel();
        mySellCard.add(scrollPane4);

        tabbedPane.addTab(CURRENTBUYPANEL, currentBuyCard);
        tabbedPane.addTab(CURRENTSELLPANEL, currentSellCard);
        tabbedPane.addTab(MYBUYPANEL, myBuyCard);
        tabbedPane.addTab(MYSELLPANEL, mySellCard);

        return tabbedPane;
    }

    private void HideIdColumn(JTable table) {
        TableColumnModel tcm = table.getColumnModel();
        tcm.removeColumn(tcm.getColumn(0));
    }

    private void SetColumnWidth(JTable table) {
        TableColumn column = null;
        for (int i = 0; i < table.getColumnCount(); i++) {
            column = table.getColumnModel().getColumn(i);
            column.setCellRenderer(new LineWrapCellRenderer());
            if (i == 0 || i == 1) {
                column.setPreferredWidth(280);
            } else {
                column.setPreferredWidth(80);
            }
        }
    }

    private JPanel makeEditPanel() {
        JPanel editPanel = new JPanel();
        editPanel.setBorder(BorderFactory.createTitledBorder("Edit"));
        editPanel.setLayout(new BoxLayout(editPanel, BoxLayout.Y_AXIS));

        editPanel.add(Box.createVerticalStrut(20));

        JPanel editFieldsPanel = new JPanel();
        GroupLayout layout = new GroupLayout(editFieldsPanel);
        editFieldsPanel.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);
        JLabel offerNameLabel = new JLabel("Offer Name");
        JLabel assetNameLabel = new JLabel("Asset Name");
        JLabel priceLabel = new JLabel("Price");
        JLabel quantityLabel = new JLabel("Quantity");
        JLabel unitNameLabel = new JLabel("Unit Name");
        JLabel offerTypeLabel = new JLabel("Offer Type");

        offerName = new JTextField(20);
        assetName = new JComboBox(data.getAssetList());
        assetName.setSelectedIndex(-1);
        quantity = new JTextField(20);
        unitName = new JTextField(20);
        offerType = new JComboBox(data.getOfferTypeList());
        offerType.setSelectedIndex(-1);
        price = new JTextField(20);
        id = new JTextField(0);
        id.setVisible(false);
        unitName.setText(currentUnit);
        unitName.setEditable(false);


        GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();
        hGroup.addGroup(layout.createParallelGroup().addComponent(offerNameLabel).addComponent(quantityLabel));
        hGroup.addGroup(layout.createParallelGroup().addComponent(offerName).addComponent(quantity));
        hGroup.addGroup(layout.createParallelGroup().addComponent(assetNameLabel).addComponent(unitNameLabel));
        hGroup.addGroup(layout.createParallelGroup().addComponent(assetName).addComponent(unitName));
        hGroup.addGroup(layout.createParallelGroup().addComponent(priceLabel).addComponent(offerTypeLabel));
        hGroup.addGroup(layout.createParallelGroup().addComponent(price).addComponent(offerType));

        layout.setHorizontalGroup(hGroup);

        GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();
        vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(offerNameLabel).addComponent(offerName).addComponent(assetNameLabel).addComponent(assetName).addComponent(priceLabel).addComponent(price));
        vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(quantityLabel).addComponent(quantity).addComponent(unitNameLabel).addComponent(unitName).addComponent(offerTypeLabel).addComponent(offerType));
        layout.setVerticalGroup(vGroup);

        editPanel.add(editFieldsPanel);
        editPanel.add(id);
        editPanel.add(Box.createVerticalStrut(20));

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        newButton = new JButton("New");
        resetButton = new JButton("Reset");
        saveButton = new JButton("Save");
        saveButton.setEnabled(false);
        deleteButton = new JButton("Delete");
        deleteButton.setEnabled(false);
        exitButton = new JButton("Back");
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(newButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(resetButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(saveButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(deleteButton);
        buttonPanel.add(Box.createHorizontalStrut(50));

        editPanel.add(buttonPanel);
        editPanel.add(Box.createVerticalStrut(20));

        return editPanel;
    }

    /**
     * Adds the New, Save and Delete buttons to a panel
     */
    private JPanel makeButtonsPanel() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));

        JLabel assetFilterLabel = new JLabel("Asset");
        assetFilter = new JComboBox(data.getAssetList());
        assetFilter.setSelectedIndex(-1);
        assetFilter.setPreferredSize(new Dimension(150, 25));

        JLabel unitFilterLabel = new JLabel("Unit");
        unitFilter = new JComboBox(data.getUnitList());
        unitFilter.setSelectedIndex(-1);
        unitFilter.setPreferredSize(new Dimension(150, 25));

        JLabel filterLabel = new JLabel("Offer Filter");
        filterText = new JTextField(20);


        queryButton = new JButton("Query");
        clearButton = new JButton("Clear");
        exitButton = new JButton("Exit");

        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(assetFilterLabel);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(assetFilter);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(unitFilterLabel);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(unitFilter);

        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(filterLabel);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(filterText);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(queryButton);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(clearButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(exitButton);
        buttonPanel.add(Box.createHorizontalStrut(20));

        return buttonPanel;
    }

    private void newFilter(JTable table) {
        RowFilter<DefaultTableModel, Object> compoundRowFilter = null;
        RowFilter<DefaultTableModel, Object> assetRowFilter = null;
        RowFilter<DefaultTableModel, Object> unitRowFilter = null;
        RowFilter<DefaultTableModel, Object> textRowFilter = null;
        //If current expression doesn't parse, don't update.
        try {
            if (assetFilter.getSelectedIndex() > -1)
                assetRowFilter = RowFilter.regexFilter(assetFilter.getSelectedItem().toString(), 2);
            if (unitFilter.getSelectedIndex() > -1)
                unitRowFilter = RowFilter.regexFilter(unitFilter.getSelectedItem().toString(), 5);
            textRowFilter = RowFilter.regexFilter(filterText.getText(), 1);

            final List<RowFilter<DefaultTableModel, Object>> filters = new ArrayList<RowFilter<DefaultTableModel, Object>>();
            if (assetRowFilter != null)
                filters.add(assetRowFilter);
            if (unitRowFilter != null)
                filters.add(unitRowFilter);
            filters.add(textRowFilter);
            /* The row must match every filters */
            compoundRowFilter = RowFilter.andFilter(filters);

        } catch (java.util.regex.PatternSyntaxException e) {
            return;
        }
        RowSorter sorter = table.getRowSorter();
        ((DefaultRowSorter) sorter).setRowFilter(compoundRowFilter);
    }

    private void addButtonListeners(ActionListener listener) {
        newButton.addActionListener(listener);
        resetButton.addActionListener(listener);
        saveButton.addActionListener(listener);
        deleteButton.addActionListener(listener);
        queryButton.addActionListener(listener);
        clearButton.addActionListener(listener);
        exitButton.addActionListener(listener);
        tradeHistoryButton.addActionListener(listener);
        myPropertyButton.addActionListener(listener);
        refreshButton.addActionListener(listener);
    }

    private void addAssetNameListener(ItemListener listener) {
        assetName.addItemListener(listener);
    }

    private void addTableSelectListeners(ListSelectionListener listener) {
        myBuyTable.getSelectionModel().addListSelectionListener(listener);
        mySellTable.getSelectionModel().addListSelectionListener(listener);
    }

    private class TableListListener implements ListSelectionListener {
        public void valueChanged(ListSelectionEvent e) {
            ListSelectionModel source = (ListSelectionModel) e.getSource();
            if (source == myBuyTable.getSelectionModel()) {
                if (myBuyTable.getSelectedRow() != -1) {
                    int row = myBuyTable.getSelectedRow();
                    display(myBuyTable, row);
                }
            } else if (source == mySellTable.getSelectionModel()) {
                if (mySellTable.getSelectedRow() != -1) {
                    int row = mySellTable.getSelectedRow();
                    display(mySellTable, row);
                }
            }
        }
    }

    private class ItemChangeListener implements ItemListener {
        @Override
        public void itemStateChanged(ItemEvent event) {
            if (event.getStateChange() == ItemEvent.SELECTED) {
                Object item = event.getItem();
                if (event.getSource() == assetName) {
                    assetQuantity = data.GetAssetQuantity(assetName.getSelectedItem().toString());
                    quantity.setText(String.valueOf(assetQuantity));
                }
            }
        }
    }

    private void clearFields() {
        offerName.setText("");
        assetName.setSelectedIndex(-1);
        quantity.setText("");
        offerType.setSelectedIndex(-1);
        price.setText("");
        newButton.setEnabled(true);
        saveButton.setEnabled(false);
        deleteButton.setEnabled(false);
    }

    private void setFieldsEditable(boolean editable) {
        offerName.setEditable(editable);
        quantity.setEditable(editable);
        price.setEditable(editable);
    }

    private void display(JTable table, int row) {
        if (row > -1) {
            setFieldsEditable(true);
            saveButton.setEnabled(true);
            deleteButton.setEnabled(true);
            newButton.setEnabled(false);
            DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
            id.setText(tableModel.getValueAt(row, 0).toString());
            offerName.setText(tableModel.getValueAt(row, 1).toString());
            assetName.setSelectedItem(tableModel.getValueAt(row, 2).toString());
            price.setText(String.valueOf(tableModel.getValueAt(row, 3)));
            quantity.setText(tableModel.getValueAt(row, 4).toString());
            unitName.setText(tableModel.getValueAt(row, 5).toString());
            offerType.setSelectedItem(tableModel.getValueAt(row, 6).toString());

        }
    }

    /**
     * Adds a listener to the JFrame
     */
    private void addClosingListener(WindowListener listener) {
        addWindowListener(listener);
    }

    private class ButtonListener implements ActionListener {

        /**
         * @see ActionListener#actionPerformed(ActionEvent)
         */
        public void actionPerformed(ActionEvent e) {
            int size = data.getSize();

            JButton source = (JButton) e.getSource();
            if (source == newButton) {
                newPressed();
            } else if (source == resetButton) {
                clearFields();
            } else if (source == saveButton) {
                savePressed();
            } else if (source == deleteButton) {
                deletePressed();
            } else if (source == queryButton) {
                queryPressed();
            } else if (source == clearButton) {
                clearPressed();
            } else if (source == tradeHistoryButton) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        dispose();
                        createAndShowTradeHistoryUI();
                    }
                });
            } else if (source == exitButton) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        dispose();
                        createAndShowUserLoginUI();
                    }
                });
            } else if (source == myPropertyButton) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        dispose();
                        createAndShowPropertyGUI();
                    }
                });
            } else if (source == refreshButton) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        dispose();
                        createAndShowOfferTableGUI();
                    }
                });
            }
        }

        private void newPressed() {
            try {
                if (offerName.getText() != null && !offerName.getText().equals("") && assetName.getSelectedItem() != null && !assetName.getSelectedItem().equals("")
                        && price.getText() != null && !price.getText().equals("")
                        && quantity.getText() != null && !quantity.getText().equals("")
                        && offerType.getSelectedItem() != null && !offerType.getSelectedItem().equals("")) {
                    Offer o = new Offer(offerName.getText(), (String) assetName.getSelectedItem(), Integer.valueOf(quantity.getText()),
                            currentUnit, (String) offerType.getSelectedItem(), Integer.valueOf(price.getText()));
                    //verify your credits if you buy
                    if (offerType.getSelectedItem().equals("Buy") && Integer.valueOf(availableCredits) < Integer.valueOf(quantity.getText()) * Integer.valueOf(price.getText())) {
                        JOptionPane.showMessageDialog(null, "Your Credits are not enough !");
                        //verify your quantity if you sell
                    } else if (offerType.getSelectedItem().equals("Sell") && assetQuantity < Integer.valueOf(quantity.getText())) {
                        JOptionPane.showMessageDialog(null, "Your Assets are not enough !");
                    } else {
                        data.add(o);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Inputting information is incomplete !");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }


            OnTableDataChanged();
            clearFields();
            setFieldsEditable(true);
            newButton.setEnabled(true);
            saveButton.setEnabled(false);
            deleteButton.setEnabled(false);
        }

        private void OnTableDataChanged() {
            currentBuyTableModel.setRowCount(0);
            data.SetCurrentBuyTableModel();
            currentBuyTableModel = data.getCurrentBuyTableModel();
            currentBuyTable.setModel(currentBuyTableModel);
            HideIdColumn(currentBuyTable);
            SetColumnWidth(currentBuyTable);
            currentBuyTableModel.fireTableDataChanged();

            currentSellTableModel.setRowCount(0);
            data.SetCurrentSellTableModel();
            currentSellTableModel = data.getCurrentSellTableModel();
            currentSellTable.setModel(currentSellTableModel);
            HideIdColumn(currentSellTable);
            SetColumnWidth(currentSellTable);
            currentSellTableModel.fireTableDataChanged();

            myBuyTableModel.setRowCount(0);
            data.SetMyBuyTableModel();
            myBuyTableModel = data.getMyBuyTableModel();
            myBuyTable.setModel(myBuyTableModel);
            HideIdColumn(myBuyTable);
            SetColumnWidth(myBuyTable);
            myBuyTableModel.fireTableDataChanged();

            mySellTableModel.setRowCount(0);
            data.SetMySellTableModel();
            mySellTableModel = data.getMySellTableModel();
            mySellTable.setModel(mySellTableModel);
            HideIdColumn(mySellTable);
            SetColumnWidth(mySellTable);
            mySellTableModel.fireTableDataChanged();

        }

        private void savePressed() {
            try {
                if (offerName.getText() != null && !offerName.getText().equals("") && assetName.getSelectedItem() != null && !assetName.getSelectedItem().equals("")
                        && price.getText() != null && !price.getText().equals("")
                        && quantity.getText() != null && !quantity.getText().equals("")
                        && offerType.getSelectedItem() != null && !offerType.getSelectedItem().equals("")) {
                    Offer o = new Offer(Integer.parseInt(id.getText()), offerName.getText(), (String) assetName.getSelectedItem(), Integer.valueOf(quantity.getText()),
                            currentUnit, (String) offerType.getSelectedItem(), Integer.valueOf(price.getText()));
                    data.update(o);
                } else {
                    JOptionPane.showMessageDialog(null, "Inputting information is incomplete !");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            OnTableDataChanged();
            setFieldsEditable(true);
            clearFields();
            saveButton.setEnabled(false);
            deleteButton.setEnabled(false);
            newButton.setEnabled(true);
        }

        private void deletePressed() {
            if (id.getText() != null && !id.getText().equals("")) {
                data.remove(id.getText());
            }


            OnTableDataChanged();
            clearFields();
            setFieldsEditable(true);
            saveButton.setEnabled(false);
            deleteButton.setEnabled(false);
            newButton.setEnabled(true);
        }

        private void queryPressed() {
            newFilter(currentBuyTable);
            newFilter(currentSellTable);
            newFilter(myBuyTable);
            newFilter(mySellTable);
        }

        private void clearPressed() {
            filterText.setText("");
            assetFilter.setSelectedIndex(-1);
            unitFilter.setSelectedIndex(-1);

        }
    }


    private class ClosingListener extends WindowAdapter {

        /**
         * @see WindowAdapter#windowClosing(WindowEvent)
         */
        public void windowClosing(WindowEvent e) {
            data.persist();
            System.exit(0);
        }
    }

    private static void createAndShowUserLoginUI() {
        new UserLoginUI(new UserData(new DAONetworkClient(new User())));
    }

    private static void createAndShowPropertyGUI() {
        new PropertyUI(
                new PropertyData(
                        new DAONetworkClient(new Property())
                )
        );
    }
    private static void createAndShowOfferTableGUI() {
        new OfferTableUI(
                new OfferData(
                        new DAONetworkClient(new Offer())
                )
        );
    }

    private static void createAndShowTradeHistoryUI() {
        new TradeHistoryUI(
                new TradeHistoryData(
                        new DAONetworkClient(new TradeHistory())
                )
        );
    }
    /**
     * render table style
     */
    public class LineWrapCellRenderer extends JTextArea implements TableCellRenderer {

        LineWrapCellRenderer() {
            setLineWrap(true);
            setWrapStyleWord(true);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,

                                                       int row, int column) {
            this.setText(value.toString());
            int fontHeight = this.getFontMetrics(this.getFont()).getHeight();
            int textLength = this.getText().length();
            int lines = textLength / this.getColumnWidth();
            if (lines == 0) {
                lines = 1;
            }
            if (!isSelected) {
                this.setBackground(row % 2 == 0 ? Color.WHITE : Color.getHSBColor(193, 100, 82));
            } else {
                this.setBackground(Color.getHSBColor(193, 100, 73));
            }

            int height = fontHeight * lines;
            table.setRowHeight(row, height);

            return this;
        }

    }
}
