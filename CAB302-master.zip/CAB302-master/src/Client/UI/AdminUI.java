package src.Client.UI;

import src.Client.Data.PropertyData;
import src.Client.Data.UserData;
import src.Common.Model.Asset;
import src.Common.Model.Property;
import src.Common.Model.Unit;
import src.Client.DAONetworkClient;
import src.Client.Data.AssetData;
import src.Client.Data.UnitData;
import src.Common.Model.User;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.*;


/**
 * This class contains the main UI for a Admin management.
 *
 * @author CAB302
 * @version 1.0
 */
public class AdminUI extends JFrame {

    private JButton unitButton;
    private JButton assetButton;
    private JButton propertyButton;
    private JButton usersButton;
    private JButton registerButton;

    private JButton exitButton;

    /**
     * Create Admin UI
     */
    public AdminUI() {

        initUI();

        // add listeners to interactive components
        addButtonListeners(new ButtonListener());

        //addNameListListener(new AssetUI.NameListListener());
        addClosingListener(new ClosingListener());

        // decorate the frame and make it visible
        setTitle("Electronic Asset Trading Platform");
        setMinimumSize(new Dimension(600, 500));
        pack();
        setVisible(true);

    }

    private void initUI() {
        Container contentPane = this.getContentPane();
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));

        contentPane.add(Box.createVerticalStrut(20));
        contentPane.add(makeButtonsPanel());
        contentPane.add(Box.createVerticalStrut(50));


    }

    private JPanel makeButtonsPanel() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        unitButton = new JButton("Unit");
        assetButton = new JButton("Asset");
        propertyButton = new JButton("Property");
        usersButton = new JButton("Users");
        registerButton = new JButton("Register");
        exitButton = new JButton("Back");
        exitButton.setVisible(false);

        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(unitButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(assetButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(propertyButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(usersButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(registerButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(exitButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        return buttonPanel;
    }


    /**
     * Adds a listener to the new, save and delete buttons
     */
    private void addButtonListeners(ActionListener listener) {
        unitButton.addActionListener(listener);
        assetButton.addActionListener(listener);
        propertyButton.addActionListener(listener);
        usersButton.addActionListener(listener);
        registerButton.addActionListener(listener);
        exitButton.addActionListener(listener);
    }

    /**
     * Handles events for the three buttons on the UI.
     */
    private class ButtonListener implements ActionListener {

        /**
         * @see ActionListener#actionPerformed(ActionEvent)
         */
        public void actionPerformed(ActionEvent e) {
            JButton source = (JButton) e.getSource();
            createAndShowUI(source);
        }
    }


    /**
     * Adds a listener to the JFrame
     */
    private void addClosingListener(WindowListener listener) {
        addWindowListener(listener);
    }


    /**
     * Implements the windowClosing method from WindowAdapter.
     */
    private class ClosingListener extends WindowAdapter {

        /**
         * @see WindowAdapter#windowClosing(WindowEvent)
         */
        public void windowClosing(WindowEvent e) {
            System.exit(0);
        }
    }

    private void createAndShowUI(JButton source) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                dispose();
                if (source == unitButton)
                    new UnitUI(
                            new UnitData(
                                    new DAONetworkClient(new Unit())
                            )
                    );
                else if (source == assetButton)
                    new AssetUI(
                            new AssetData(
                                    new DAONetworkClient(new Asset())
                            )
                    );
                else if (source == propertyButton) {
                    new PropertyUI(
                            new PropertyData(
                                    new DAONetworkClient(new Property())
                            )
                    );
                } else if (source == exitButton) {
                    //Schedule a job for the event-dispatching thread:
                    //creating and showing this application's GUI.
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            dispose();
                            createAndShowUserLoginUI();
                        }
                    });
                } else if (source == usersButton) {
                    new UserUI(
                            new UserData(
                                    new DAONetworkClient(new User())
                            ));
                }else if (source == registerButton) {
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            dispose();
                            createAndShowUserLoginUI();
                        }
                    });
                }
            }
        });

    }

    private static void createAndShowUserLoginUI() {
        new UserLoginUI(new UserData(new DAONetworkClient(new User())));
    }
}