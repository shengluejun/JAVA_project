package src.Client.UI;

import src.Common.Model.Unit;
import src.Client.Data.UnitData;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.*;
import javax.swing.GroupLayout.Alignment;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * This class contains the main UI for a unit management.
 *
 * @author CAB302
 * @version 1.0
 */
public class UnitUI extends JFrame {

    private static final long serialVersionUID = -5050538890770582361L;

    private JList nameList;


    private JTextField unitName;
    private JTextField credits;

    private JButton newButton;
    private JButton saveButton;
    private JButton deleteButton;
    private JButton resetButton;
    private JButton backButton;

    private String previousUnitName;
    private String previousCredits;

    private UnitData data;

    /**
     * Constructor sets up user interface, adds listeners and displays.
     *
     * @param data The underlying data/model class the UI needs.
     */
    public UnitUI(UnitData data) {
        this.data = data;
        initUI();
        checkListSize();

        // add listeners to interactive components
        addButtonListeners(new ButtonListener());
        addNameListListener(new NameListListener());
        addClosingListener(new ClosingListener());

        // decorate the frame and make it visible
        setTitle("Electronic Asset Trading Platform");
        setMinimumSize(new Dimension(600, 500));
        pack();
        setVisible(true);

    }

    /**
     * Places the detail panel and the button panel in a box layout with vertical
     * alignment and puts a 20 pixel gap between the components and the top and
     * bottom edges of the frame.
     */
    private void initUI() {
        Container contentPane = this.getContentPane();
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));

        contentPane.add(Box.createVerticalStrut(20));
        contentPane.add(makeDetailsPanel());
        contentPane.add(Box.createVerticalStrut(20));
        contentPane.add(makeButtonsPanel());
        contentPane.add(Box.createVerticalStrut(20));
    }

    /**
     * Makes a JPanel consisiting of (1) the list of names and (2) the address
     * fields in a box layout with horizontal alignment and puts a 20 pixel gap
     * between the components and the left and right edges of the panel.
     *
     * @return the detail panel.
     */
    private JPanel makeDetailsPanel() {
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.X_AXIS));
        detailsPanel.add(Box.createHorizontalStrut(20));
        detailsPanel.add(makeNameListPane());
        detailsPanel.add(Box.createHorizontalStrut(20));
        detailsPanel.add(makeUnitFieldsPanel());
        detailsPanel.add(Box.createHorizontalStrut(20));
        return detailsPanel;
    }

    /**
     * Makes a JScrollPane that holds a JList for the list of names in the
     * address book.
     *
     * @return the scrolling name list panel
     */
    private JScrollPane makeNameListPane() {
        nameList = new JList(data.getModel());
        nameList.setFixedCellWidth(200);

        JScrollPane scroller = new JScrollPane(nameList);
        scroller.setViewportView(nameList);
        scroller
                .setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroller
                .setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroller.setMinimumSize(new Dimension(200, 150));
        scroller.setPreferredSize(new Dimension(250, 150));
        scroller.setMaximumSize(new Dimension(250, 200));

        return scroller;
    }

    /**
     * Makes a JPanel containing labels and textfields for each of the pieces of
     * data that are to be recorded for each address. The labels and fields are
     * layed out using a GroupLayout, with the labels vertically grouped, the
     * fields vertically grouped and each label/group pair horizontally grouped.
     *
     * @return a panel containing the address fields
     */
    private JPanel makeUnitFieldsPanel() {
        JPanel unitPanel = new JPanel();
        GroupLayout layout = new GroupLayout(unitPanel);
        unitPanel.setLayout(layout);

        // Turn on automatically adding gaps between components
        layout.setAutoCreateGaps(true);

        // Turn on automatically creating gaps between components that touch
        // the edge of the container and the container.
        layout.setAutoCreateContainerGaps(true);

        JLabel unitNameLabel = new JLabel("Unit Name");
        JLabel creditsLabel = new JLabel("Credits");


        unitName = new JTextField(20);
        credits = new JTextField(20);
        setFieldsEditable(true);

        // Create a sequential group for the horizontal axis.
        GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();

        // The sequential group in turn contains two parallel groups.
        // One parallel group contains the labels, the other the text fields.
        hGroup.addGroup(layout.createParallelGroup().addComponent(unitNameLabel).addComponent(creditsLabel));
        hGroup.addGroup(layout.createParallelGroup().addComponent(unitName).addComponent(credits));
        layout.setHorizontalGroup(hGroup);

        // Create a sequential group for the vertical axis.
        GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();


        vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE)
                .addComponent(unitNameLabel).addComponent(unitName));
        vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE)
                .addComponent(creditsLabel).addComponent(credits));

        layout.setVerticalGroup(vGroup);

        return unitPanel;
    }

    /**
     * Adds the New, Save and Delete buttons to a panel
     */
    private JPanel makeButtonsPanel() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        newButton = new JButton("New");
        saveButton = new JButton("Save");
        resetButton = new JButton("Reset");
        deleteButton = new JButton("Delete");
        backButton = new JButton("Back");

        newButton.setEnabled(true);
        saveButton.setEnabled(false);
        deleteButton.setEnabled(false);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(newButton);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(resetButton);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(saveButton);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(deleteButton);
        buttonPanel.add(Box.createHorizontalStrut(100));
        buttonPanel.add(backButton);
        buttonPanel.add(Box.createHorizontalStrut(20));
        return buttonPanel;
    }

    /**
     * Adds a listener to the new, save and delete buttons
     */
    private void addButtonListeners(ActionListener listener) {
        newButton.addActionListener(listener);
        saveButton.addActionListener(listener);
        deleteButton.addActionListener(listener);
        resetButton.addActionListener(listener);
        backButton.addActionListener(listener);
    }

    /**
     * Adds a listener to the name list
     */
    private void addNameListListener(ListSelectionListener listener) {
        nameList.removeListSelectionListener(listener);
        nameList.addListSelectionListener(listener);
    }

    /**
     * Adds a listener to the JFrame
     */
    private void addClosingListener(WindowListener listener) {
        addWindowListener(listener);
    }

    /**
     * Sets the text in the address text fields to the empty string.
     */
    private void clearFields() {
        unitName.setText("");
        credits.setText("");
    }

    /**
     * Sets whether or not the address fields are editable.
     */
    private void setFieldsEditable(boolean editable) {
        unitName.setEditable(editable);
        credits.setEditable(editable);
    }

    /**
     * Determine what to display according whether a is null.
     * @param a
     */
    private void display(Unit a) {
        if (a != null) {
            setFieldsEditable(true);
            saveButton.setEnabled(true);
            newButton.setEnabled(false);
            deleteButton.setEnabled(true);
            unitName.setText(a.getUnitName());
            credits.setText(String.valueOf(a.getCredits()));
        }
    }

    /**
     * Checks size of data/model and enables/disables the delete button
     */
    private void checkListSize() {
        if (deleteButton.isEnabled())
            deleteButton.setEnabled(data.getSize() != 0);
    }

    /**
     * Handles events for the three buttons on the UI.
     */
    private class ButtonListener implements ActionListener {

        /**
         * @see ActionListener#actionPerformed(ActionEvent)
         */
        public void actionPerformed(ActionEvent e) {
            int size = data.getSize();

            JButton source = (JButton) e.getSource();
            if (source == newButton) {
                newPressed();
            } else if (source == saveButton) {
                savePressed();
            } else if (source == deleteButton) {
                deletePressed();
            } else if (source == resetButton) {
                resetPressed();
            } else if (source == backButton) {
                //Schedule a job for the event-dispatching thread:
                //creating and showing this application's GUI.
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        dispose();
                        createAndShowAdminUI();
                    }
                });
            }
        }

        /**
         * When the new button is pressed, clear the field display, make them
         * editable and enable the save button.
         */
        private void newPressed() {
            if (unitName.getText() == null && !unitName.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Unit Name required.");
                return;
            }
            if (unitName.getText() != null && !unitName.getText().equals("") && !unitName.getText().equals(previousUnitName)) {
                Unit a = new Unit(unitName.getText(), Integer.valueOf(credits.getText()));
                data.add(a);
            }
            setFields(true);//back to inital state
        }

        /**
         * When the save button is pressed, check that the name field contains
         * something. If it does, create a new Person object and attempt to add it
         * to the data model. Change the fields back to not editable and make the
         * save button inactive.
         * <p>
         * Check the list size to see if the delete button should be enabled.
         */
        private void savePressed() {
            if (unitName.getText() == null && !unitName.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Unit Name required.");
                return;
            }
            else if (unitName.getText() != null && !unitName.getText().equals("") && !(unitName.getText().equals(previousUnitName) && credits.getText().equals(previousCredits))) {
                Unit a = new Unit(unitName.getText(), Integer.valueOf(credits.getText()));
                data.update(a);
            }

            setFields(true);//back to inital state
        }

        /**
         * When the delete button is pressed remove the selected name from the
         * data model.
         * <p>
         * Clear the fields that were displayed and check to see if the delete
         * button should be displayed.
         * <p>
         * The index here handles cases where the first element of the list is
         * deleted.
         */
        private void deletePressed() {
            int index = nameList.getSelectedIndex();
            data.remove(nameList.getSelectedValue());
            clearFields();
            index--;
            if (index == -1) {
                if (data.getSize() != 0) {
                    index = 0;
                }
            }
            nameList.setSelectedIndex(index);
            setFields(true);//back to inital state
        }

        private void resetPressed() {
            nameList.setSelectedIndex(-1);
            setFields(true);//back to inital state
        }

        private void setFields(boolean enableNew) {
            clearFields();
            setFieldsEditable(enableNew);
            saveButton.setEnabled(!enableNew);
            deleteButton.setEnabled(!enableNew);
            newButton.setEnabled(enableNew);
            checkListSize();
        }

    }

    /**
     * Implements a ListSelectionListener for making the UI respond when a
     * different name is selected from the list.
     */
    private class NameListListener implements ListSelectionListener {

        /**
         * @see ListSelectionListener#valueChanged(ListSelectionEvent)
         */
        public void valueChanged(ListSelectionEvent e) {
            if (nameList.getSelectedValue() != null
                    && !nameList.getSelectedValue().equals("")) {
                data.get(nameList.getSelectedValue()).ifPresent(a -> display((Unit) a));
                previousUnitName = unitName.getText();
                previousCredits = credits.getText();

                unitName.setEditable(false);
                newButton.setEnabled(false);
                saveButton.setEnabled(true);
                deleteButton.setEnabled(true);
            }
        }
    }

    /**
     * Implements the windowClosing method from WindowAdapter/WindowListener to
     * persist the contents of the data/model.
     */
    private class ClosingListener extends WindowAdapter {

        /**
         * @see WindowAdapter#windowClosing(WindowEvent)
         */
        public void windowClosing(WindowEvent e) {
            data.persist();
            System.exit(0);
        }
    }


    private static void createAndShowAdminUI() {
        new AdminUI();
    }
}

