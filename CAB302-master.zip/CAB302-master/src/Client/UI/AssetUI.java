package src.Client.UI;

import src.Common.Model.Asset;
import src.Client.Data.AssetData;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.*;
import javax.swing.GroupLayout.Alignment;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
/**
 * This class contains the main UI for a Asset management.
 *
 * @author CAB302
 * @version 1.0
 */
public class AssetUI extends JFrame {

    private static final long serialVersionUID = -5050538890770582361L;

    private JList nameList;

    private JTextField assetName;
    private JTextArea assetDescription;

    private JButton newButton;
    private JButton saveButton;
    private JButton resetButton;
    private JButton deleteButton;
    private JButton backButton;

    /**
     * Create previousAssetName
     */
    String previousAssetName;
    /**
     * Create previousDescription
     */
    String previousDescription;
    /**
     * create an AssetData object
     */
    AssetData data;

    /**
     * Constructor sets up user interface, adds listeners and displays.
     *
     * @param data The underlying data/model class the UI needs.
     */
    public AssetUI(AssetData data) {
        this.data = data;
        initUI();
        checkListSize();

        // add listeners to interactive components
        addButtonListeners(new ButtonListener());
        addNameListListener(new NameListListener());
        addClosingListener(new ClosingListener());

        // decorate the frame and make it visible
        setTitle("Electronic Asset Trading Platform");
        setMinimumSize(new Dimension(600, 500));
        pack();
        setVisible(true);
    }

    /**
     * Places the detail panel and the button panel in a box layout with vertical
     * alignment and puts a 20 pixel gap between the components and the top and
     * bottom edges of the frame.
     */
    private void initUI() {
        Container contentPane = this.getContentPane();
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));

        contentPane.add(Box.createVerticalStrut(20));
        contentPane.add(makeDetailsPanel());
        contentPane.add(Box.createVerticalStrut(20));
        contentPane.add(makeButtonsPanel());
        contentPane.add(Box.createVerticalStrut(20));
    }

    /**
     * Makes a JPanel consisiting of (1) the list of names and (2) the address
     * fields in a box layout with horizontal alignment and puts a 20 pixel gap
     * between the components and the left and right edges of the panel.
     *
     * @return the detail panel.
     */
    private JPanel makeDetailsPanel() {
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.X_AXIS));
        detailsPanel.add(Box.createHorizontalStrut(20));
        detailsPanel.add(makeNameListPane());
        detailsPanel.add(Box.createHorizontalStrut(20));
        detailsPanel.add(makeAssetFieldsPanel());
        detailsPanel.add(Box.createHorizontalStrut(20));
        return detailsPanel;
    }

    /**
     * Makes a JScrollPane that holds a JList for the list of names in the
     * address book.
     *
     * @return the scrolling name list panel
     */
    private JScrollPane makeNameListPane() {
        nameList = new JList(data.getModel());
        nameList.setFixedCellWidth(200);

        JScrollPane scroller = new JScrollPane(nameList);
        scroller.setViewportView(nameList);
        scroller
                .setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroller
                .setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroller.setMinimumSize(new Dimension(200, 250));
        scroller.setPreferredSize(new Dimension(250, 350));
        scroller.setMaximumSize(new Dimension(250, 350));

        return scroller;
    }

    /**
     * Makes a JPanel containing labels and textfields for each of the pieces of
     * data that are to be recorded for each address. The labels and fields are
     * layed out using a GroupLayout, with the labels vertically grouped, the
     * fields vertically grouped and each label/group pair horizontally grouped.
     *
     * @return a panel containing the address fields
     */
    private JPanel makeAssetFieldsPanel() {
        JPanel assetPanel = new JPanel();
        GroupLayout layout = new GroupLayout(assetPanel);
        assetPanel.setLayout(layout);

        // Turn on automatically adding gaps between components
        layout.setAutoCreateGaps(true);

        // Turn on automatically creating gaps between components that touch
        // the edge of the container and the container.
        layout.setAutoCreateContainerGaps(true);

        JLabel assetNameLabel = new JLabel("Asset Name");
        JLabel assetDescriptionLabel = new JLabel("Asset Description");

        assetName = new JTextField(20);
        assetDescription = new JTextArea(5, 1);
        setFieldsEditable(true);

        // Create a sequential group for the horizontal axis.
        GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();

        // The sequential group in turn contains two parallel groups.
        // One parallel group contains the labels, the other the text fields.
        hGroup.addGroup(layout.createParallelGroup().addComponent(assetNameLabel).addComponent(assetDescriptionLabel));
        hGroup.addGroup(layout.createParallelGroup().addComponent(assetName).addComponent(assetDescription));
        layout.setHorizontalGroup(hGroup);

        // Create a sequential group for the vertical axis.
        GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();

        // The sequential group contains five parallel groups that align
        // the contents along the baseline. The first parallel group contains
        // the first label and text field, and the second parallel group contains
        // the second label and text field etc. By using a sequential group
        // the labels and text fields are positioned vertically after one another.
        vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE)
                .addComponent(assetNameLabel).addComponent(assetName));
        vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE)
                .addComponent(assetDescriptionLabel).addComponent(assetDescription));

        layout.setVerticalGroup(vGroup);

        return assetPanel;
    }

    /**
     * Adds the New, Save and Delete buttons to a panel
     */
    private JPanel makeButtonsPanel() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        newButton = new JButton("New");
        saveButton = new JButton("Save");
        resetButton = new JButton("Reset");
        deleteButton = new JButton("Delete");
        backButton = new JButton("Back");
        saveButton.setEnabled(false);
        deleteButton.setEnabled(false);

        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(newButton);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(resetButton);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(saveButton);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(deleteButton);
        buttonPanel.add(Box.createHorizontalStrut(100));
        buttonPanel.add(backButton);
        buttonPanel.add(Box.createHorizontalStrut(20));

        return buttonPanel;
    }

    /**
     * Adds a listener to the new, save and delete buttons
     */
    private void addButtonListeners(ActionListener listener) {
        newButton.addActionListener(listener);
        saveButton.addActionListener(listener);
        resetButton.addActionListener(listener);
        deleteButton.addActionListener(listener);
        backButton.addActionListener(listener);
    }

    /**
     * Adds a listener to the name list
     */
    private void addNameListListener(ListSelectionListener listener) {
        nameList.addListSelectionListener(listener);
    }

    /**
     * Adds a listener to the JFrame
     */
    private void addClosingListener(WindowListener listener) {
        addWindowListener(listener);
    }

    /**
     * Sets the text in the address text fields to the empty string.
     */
    private void clearFields() {
        assetName.setText("");
        assetDescription.setText("");

    }

    /**
     * Sets whether or not the address fields are editable.
     */
    private void setFieldsEditable(boolean editable) {
        assetName.setEditable(editable);
        assetDescription.setEditable(editable);

    }


    private void display(Asset a) {
        if (a != null) {
            setFieldsEditable(true);
            saveButton.setEnabled(true);
            assetName.setText(a.getAssetName());
            assetDescription.setText(a.getAssetDescription());
        }
    }

    /**
     * Checks size of data/model and enables/disables the delete button
     */
    private void checkListSize() {
        if(deleteButton.isEnabled()) deleteButton.setEnabled(data.getSize() != 0);
    }

    private class ButtonListener implements ActionListener {

        /**
         * @see ActionListener#actionPerformed(ActionEvent)
         */
        public void actionPerformed(ActionEvent e) {
            int size = data.getSize();

            JButton source = (JButton) e.getSource();
            if (source == newButton) {
                newPressed();
            } else if (source == saveButton) {
                savePressed();
            } else if (source == deleteButton) {
                deletePressed();
            } else if (source == resetButton){
                cancelPressed();
            } else if (source == backButton) {
                //Schedule a job for the event-dispatching thread:
                //creating and showing this application's GUI.
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        dispose();
                        createAndShowAdminUI();
                    }
                });
            }
        }

        /**
         * When the new button is pressed, clear the field display, make them
         * editable and enable the save button.
         */
        private void newPressed() {
            if(assetName.getText() == null && !assetName.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Asset Name required.");
                return;
            }
            if (assetName.getText() != null && !assetName.getText().equals("") && !assetName.getText().equals(previousAssetName)) {
                Asset a = new Asset(assetName.getText(), assetDescription.getText());
                data.add(a);
            }
            setFields(true);
        }

        /**
         * When the save button is pressed, check that the name field contains
         * something. If it does, create a new Person object and attempt to add it
         * to the data model. Change the fields back to not editable and make the
         * save button inactive.
         * <p>
         * Check the list size to see if the delete button should be enabled.
         */
        private void savePressed() {
            if(assetName.getText() == null && !assetName.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Asset Name required.");
                return;
            }
            if (assetName.getText() != null && !assetName.getText().equals("") && !assetName.getText().equals(previousAssetName)) {
                Asset a = new Asset(assetName.getText(), assetDescription.getText());
                data.add(a);
            }

            else if (assetName.getText() != null && !assetName.getText().equals("") && !assetDescription.getText().equals(previousDescription)) {
                Asset a = new Asset(assetName.getText(), assetDescription.getText());
                data.update(a);
            }

            setFields(true);
        }

        /**
         * When the delete button is pressed remove the selected name from the
         * data model.
         * <p>
         * Clear the fields that were displayed and check to see if the delete
         * button should be displayed.
         * <p>
         * The index here handles cases where the first element of the list is
         * deleted.
         */
        private void deletePressed() {
            int index = nameList.getSelectedIndex();
            data.remove(nameList.getSelectedValue());
            clearFields();
            index--;
            if (index == -1) {
                if (data.getSize() != 0) {
                    index = 0;
                }
            }
            nameList.setSelectedIndex(index);
            checkListSize();
            setFields(true);
        }
        private void cancelPressed() {
            nameList.setSelectedIndex(-1);
            setFields(true);
        }
        private void setFields(boolean enableNew){
            clearFields();
            setFieldsEditable(enableNew);
            saveButton.setEnabled(!enableNew);
            deleteButton.setEnabled(!enableNew);
            newButton.setEnabled(enableNew);
            checkListSize();
        }
    }

    /**
     * Implements a ListSelectionListener for making the UI respond when a
     * different name is selected from the list.
     */
    private class NameListListener implements ListSelectionListener {

        /**
         * @see ListSelectionListener#valueChanged(ListSelectionEvent)
         */
        public void valueChanged(ListSelectionEvent e) {
            if (nameList.getSelectedValue() != null
                    && !nameList.getSelectedValue().equals("")) {
                data.get(nameList.getSelectedValue()).ifPresent(a -> display((Asset)a));
                previousAssetName = assetName.getText();
                previousDescription = assetDescription.getText();
                assetName.setEditable(false);
                saveButton.setEnabled(true);
                deleteButton.setEnabled(true);
                newButton.setEnabled(false);
            }
        }
    }

    /**
     * Implements the windowClosing method from WindowAdapter/WindowListener to
     * persist the contents of the data/model.
     */
    private class ClosingListener extends WindowAdapter {

        /**
         * @see WindowAdapter#windowClosing(WindowEvent)
         */
        public void windowClosing(WindowEvent e) {
            data.persist();
            System.exit(0);
        }
    }

    private static void createAndShowAdminUI() {
        new AdminUI();
    }
}

