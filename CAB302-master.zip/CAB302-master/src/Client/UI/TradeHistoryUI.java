package src.Client.UI;
import src.Client.DAONetworkClient;
import src.Client.Data.OfferData;
import src.Client.Data.TradeHistoryData;
import src.Common.Model.Offer;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

/**
 * This class contains the main program for a trade history management.
 * User can view all the trade history list.
 * User can sort trade history by clicking transaction time header to get the latest trade list.
 *
 * @author CAB302
 * @version 1.0
 */
public class TradeHistoryUI  extends JFrame {

    private static final long serialVersionUID = -5050538890770582361L;

    private JTable table;
    private JTextField filterText;
    private JButton queryButton;
    private JButton exitButton;

    private DefaultTableModel tableModel;
    private TradeHistoryData data;


    /**
     * Constructor sets up user interface, adds listeners and displays.
     *
     * @param data The underlying data/model class the UI needs.
     */
    public TradeHistoryUI(TradeHistoryData data) {
        this.data = data;
        tableModel = data.getModel();
        initUI();

        // add listeners to interactive components
        addButtonListeners(new TradeHistoryUI.ButtonListener());
        addClosingListener(new TradeHistoryUI.ClosingListener());

        // decorate the frame and make it visible
        setTitle("Electronic Asset Trading Platform");
        setMinimumSize(new Dimension(1000, 550));
        pack();
        setVisible(true);
    }

    /**
     * Places the detail panel and the button panel in a box layout with vertical
     * alignment and puts a 20 pixel gap between the components and the top and
     * bottom edges of the frame.
     */
    private void initUI() {
        Container contentPane = this.getContentPane();
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));

        contentPane.add(Box.createVerticalStrut(20));
        contentPane.add(makeTablesPanel());
        contentPane.add(Box.createVerticalStrut(20));
        contentPane.add(makeButtonsPanel());
        contentPane.add(Box.createVerticalStrut(20));


    }

    /**
     * Makes a JPanel consisiting of (1) the list of names and (2) the address
     * fields in a box layout with horizontal alignment and puts a 20 pixel gap
     * between the components and the left and right edges of the panel.
     *
     * @return the detail panel.
     */
    private JScrollPane makeTablesPanel() {
        table = new JTable(this.tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        table.setFillsViewportHeight(true);
        table.setAutoCreateRowSorter(true);
        scrollPane.setPreferredSize(new Dimension(980, 450));
        TableColumn column = null;
        for (int i = 0; i < 8; i++) {
            column = table.getColumnModel().getColumn(i);
            column = table.getColumnModel().getColumn(i);
            column.setCellRenderer(new TradeHistoryUI.LineWrapCellRenderer());
            if (i == 1 || i == 2) {
                column.setPreferredWidth(30);
            }else if (i == 4 || i == 6){
                column.setPreferredWidth(70);
            }
            else {
                column.setPreferredWidth(100);
            }
        }
        scrollPane
                .setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane
                .setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        return scrollPane;
    }
    /**
     * Adds the New, Save and Delete buttons to a panel
     */
    private JPanel makeButtonsPanel() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        JLabel filterLabel = new JLabel("Filter");
        filterText = new JTextField(20);
        queryButton = new JButton("Query");
        exitButton = new JButton("Back");
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(filterLabel);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(filterText);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(queryButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(exitButton);
        buttonPanel.add(Box.createHorizontalStrut(20));

        return buttonPanel;
    }
    private void newFilter() {
        RowFilter<DefaultTableModel, Object> rf = null;
        //If current expression doesn't parse, don't update.
        try {
            rf = RowFilter.regexFilter(filterText.getText(), 0);
        } catch (java.util.regex.PatternSyntaxException e) {
            return;
        }
        RowSorter sorter = this.table.getRowSorter();
        ((DefaultRowSorter)sorter).setRowFilter(rf);
    }

    private void addButtonListeners(ActionListener listener) {
        queryButton.addActionListener(listener);
        exitButton.addActionListener(listener);
    }

    /**
     * Adds a listener to the JFrame
     */
    private void addClosingListener(WindowListener listener) {
        addWindowListener(listener);
    }


    private class ButtonListener implements ActionListener {

        /**
         * @see ActionListener#actionPerformed(ActionEvent)
         */
        public void actionPerformed(ActionEvent e) {
            int size = data.getSize();

            JButton source = (JButton) e.getSource();
            if(source == queryButton){
                queryPressed();
            }
            else if (source == exitButton) {
                //Schedule a job for the event-dispatching thread:
                //creating and showing this application's GUI.
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        dispose();
                        createAndShowOfferTableUI();
                    }
                });
            }
        }

        private void queryPressed(){
            newFilter();
        }
    }

    /**
     * Implements the windowClosing method from WindowAdapter/WindowListener to
     * persist the contents of the data/model.
     */
    private class ClosingListener extends WindowAdapter {

        /**
         * @see WindowAdapter#windowClosing(WindowEvent)
         */
        public void windowClosing(WindowEvent e) {
            data.persist();
            System.exit(0);
        }
    }

    private static void createAndShowOfferTableUI() {
        new OfferTableUI(
                new OfferData(
                        new DAONetworkClient(new Offer())
                )
        );
    }
    /**
     * render table style
     */
    public class LineWrapCellRenderer extends JTextArea implements TableCellRenderer {

        LineWrapCellRenderer() {
            setLineWrap(true);
            setWrapStyleWord(true);
        }
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,

                                                       int row, int column) {
            this.setText(value.toString());
            int fontHeight = this.getFontMetrics(this.getFont()).getHeight();
            int textLength = this.getText().length();
            int lines = textLength / this.getColumnWidth();
            if (lines == 0) {
                lines = 1;
            }
            if (!isSelected) {
                this.setBackground(row % 2 == 0 ? Color.WHITE : Color.getHSBColor(193,100,82));
            }else{
                this.setBackground(Color.getHSBColor(193,100,73));
            }

            int height = fontHeight * lines;
            table.setRowHeight(row, height);

            return this;
        }

    }
}

