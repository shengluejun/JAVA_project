package src.Client.UI;

import src.Client.DAONetworkClient;
import src.Client.Data.OfferData;
import src.Common.Model.CurrentUser;
import src.Common.Model.Offer;
import src.Common.Model.Property;
import src.Client.Data.PropertyData;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.GroupLayout.Alignment;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * This class contains the main UI for a property management.
 * This class allows user to assign assets to units.
 * @author CAB302
 * @version 1.0
 */
public class PropertyUI extends JFrame {

    private static final long serialVersionUID = -5050538890770582361L;

    private JComboBox unitNameList;
    private JList nameList;

    private JComboBox assetName;
    private JTextField quantity;
    private JTextField id;

    private JButton newButton;
    private JButton resetButton;
    private JButton saveButton;
    private JButton deleteButton;
    private JButton exitButton;

    private PropertyData data;
    private String unitName;
    private String currentUnit;
    private String currentUserType;
    /**
     * Constructor sets up user interface, adds listeners and displays.
     *
     * @param data The underlying data/model class the UI needs.
     */
    public PropertyUI(PropertyData data) {
        this.data = data;
        currentUserType = CurrentUser.getInstance().getCurrentUserType();
        currentUnit = CurrentUser.getInstance().getCurrentUserUnit();

        initUI();
        checkListSize();

        // add listeners to interactive components
        addButtonListeners(new ButtonListener());
        addUnitNameListListener(new ItemChangeListener());
        addNameListListener(new NameListListener());
        addClosingListener(new ClosingListener());


        // decorate the frame and make it visible
        setTitle("Electronic Asset Trading Platform");
        setMinimumSize(new Dimension(600, 500));
        pack();
        setVisible(true);

    }

    /**
     * Places the detail panel and the button panel in a box layout with vertical
     * alignment and puts a 20 pixel gap between the components and the top and
     * bottom edges of the frame.
     */
    private void initUI() {
        Container contentPane = this.getContentPane();
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));

        contentPane.add(Box.createVerticalStrut(20));
        contentPane.add(makeUnitFieldPanel());
        contentPane.add(Box.createVerticalStrut(20));
        contentPane.add(makeDetailsPanel());
        contentPane.add(Box.createVerticalStrut(20));
        contentPane.add(makeButtonsPanel());
        contentPane.add(Box.createVerticalStrut(20));
    }

    /**
     * Makes a JPanel.
     * @return the detail panel.
     */
    private JPanel makeUnitFieldPanel() {
        JPanel unitPanel = new JPanel();
        JLabel unitNameListLabel = new JLabel("Unit Name");
        unitNameList = new JComboBox(data.getUnitList());
        unitNameList.setSelectedIndex(-1);

        if(currentUserType.equals("Staff"))
        {
            if(currentUnit!= null && currentUnit != "")
                unitNameList.setSelectedItem(currentUnit);
            unitNameList.setEnabled(false);
        }else{
            unitNameList.setEnabled(true);
        }


        unitPanel.setLayout(new BoxLayout(unitPanel, BoxLayout.X_AXIS));
        unitNameList.setMinimumSize(new Dimension(80, 25));
        unitPanel.add(Box.createHorizontalStrut(20));
        unitPanel.add(unitNameListLabel);
        unitPanel.add(Box.createHorizontalStrut(20));
        unitPanel.add(unitNameList);
        unitPanel.add(Box.createHorizontalStrut(20));
        return unitPanel;
    }
    /**
     * Makes a JPanel.
     * @return the detail panel.
     */
    private JPanel makeDetailsPanel() {
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.X_AXIS));
        detailsPanel.add(Box.createHorizontalStrut(20));
        detailsPanel.add(makeNameListPane());
        detailsPanel.add(Box.createHorizontalStrut(20));
        detailsPanel.add(makeAssetFieldsPanel());
        detailsPanel.add(Box.createHorizontalStrut(20));
        return detailsPanel;
    }

    /**
     * Makes a JScrollPane that holds a JList for the list of names in the
     * address book.
     *
     * @return the scrolling name list panel
     */
    private JScrollPane makeNameListPane() {
        data.setupModel(currentUnit);
        nameList = new JList(data.getModel());
        nameList.setFixedCellWidth(200);

        JScrollPane scroller = new JScrollPane(nameList);
        scroller.setViewportView(nameList);
        scroller
                .setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroller
                .setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroller.setMinimumSize(new Dimension(200, 250));
        scroller.setPreferredSize(new Dimension(250, 350));
        scroller.setMaximumSize(new Dimension(250, 300));

        return scroller;
    }

    /**
     * Makes a JPanel
     * @return a panel containing the address fields
     */
    private JPanel makeAssetFieldsPanel() {
        JPanel unitPanel = new JPanel();
        GroupLayout layout = new GroupLayout(unitPanel);
        unitPanel.setLayout(layout);

        // Turn on automatically adding gaps between components
        layout.setAutoCreateGaps(true);

        // Turn on automatically creating gaps between components that touch
        // the edge of the container and the container.
        layout.setAutoCreateContainerGaps(true);

        JLabel assetNameLabel = new JLabel("Asset Name");
        JLabel quantityLabel = new JLabel("Quantity");

        assetName = new JComboBox(data.getAssetList());
        assetName.setSelectedIndex(-1);
        quantity = new JTextField(20);
        id = new JTextField();
        id.setVisible(false);
        setFieldsEditable(true);

        // Create a sequential group for the horizontal axis.
        GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();

        // The sequential group in turn contains two parallel groups.
        // One parallel group contains the labels, the other the text fields.
        hGroup.addGroup(layout.createParallelGroup().addComponent(assetNameLabel).addComponent(quantityLabel));
        hGroup.addGroup(layout.createParallelGroup().addComponent(assetName).addComponent(quantity));
        layout.setHorizontalGroup(hGroup);

        // Create a sequential group for the vertical axis.
        GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();

        vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE)
                .addComponent(assetNameLabel).addComponent(assetName));
        vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE)
                .addComponent(quantityLabel).addComponent(quantity));

        layout.setVerticalGroup(vGroup);

        return unitPanel;
    }

    /**
     * Adds the New, Save and Delete buttons to a panel
     */
    private JPanel makeButtonsPanel() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        newButton = new JButton("New");
        resetButton = new JButton("Reset");
        saveButton = new JButton("Save");
        deleteButton = new JButton("Delete");
        exitButton = new JButton("Back");
        newButton.setEnabled(true);
        saveButton.setEnabled(false);
        deleteButton.setEnabled(false);
        setButtons();
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(newButton);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(resetButton);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(saveButton);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(deleteButton);
        buttonPanel.add(Box.createHorizontalStrut(100));
        buttonPanel.add(exitButton);
        buttonPanel.add(Box.createHorizontalStrut(20));
        return buttonPanel;
    }
    private void setButtons(){
        if(currentUserType.equals("Staff"))
        {
            newButton.setVisible(false);
            saveButton.setVisible(false);
            deleteButton.setVisible(false);
            resetButton.setVisible(false);

        }else
        {
            newButton.setVisible(true);
            saveButton.setVisible(true);
            deleteButton.setVisible(true);
            resetButton.setVisible(true);
        }
    }

    /**
     * Adds a listener to the new, save and delete buttons
     */
    private void addButtonListeners(ActionListener listener) {
        newButton.addActionListener(listener);
        saveButton.addActionListener(listener);
        deleteButton.addActionListener(listener);
        resetButton.addActionListener(listener);
        exitButton.addActionListener(listener);
    }

    /**
     * Adds a listener to the name list
     */
    private void addNameListListener(ListSelectionListener listener) {
        nameList.addListSelectionListener(listener);
    }
    private void addUnitNameListListener(ItemListener listener){
        unitNameList.addItemListener(listener);
    }

    /**
     * Adds a listener to the JFrame
     */
    private void addClosingListener(WindowListener listener) {
        addWindowListener(listener);
    }

    /**
     * Sets the text in the address text fields to the empty string.
     */
    private void clearFields() {
        assetName.setSelectedIndex(-1);
        //assetName.setSelectedItem(null);
        quantity.setText("");
    }

    /**
     * Sets whether or not the address fields are editable.
     */
    private void setFieldsEditable(boolean editable) {
        if(unitNameList.getSelectedIndex() > -1)
        {
            boolean enableAsset = newButton != null ? newButton.isEnabled(): true;
            assetName.setEnabled(enableAsset);
            quantity.setEditable(editable);
        }else{
            assetName.setEnabled(false);
            quantity.setEditable(false);
        }

    }


    private void display(Property p) {
        if (p != null) {
            id.setText(String.valueOf(p.getId()));
            assetName.setSelectedItem(p.getAssetName());
            quantity.setText(String.valueOf(p.getQuantity()));
        }
    }
    private void displayAssets(String unitName) {
        if (unitName != null) {
            this.unitName = unitName;
            clearFields();
            data.setupModel(this.unitName);
            nameList.setModel(data.getModel());
        }
    }

    /**
     * Checks size of data/model and enables/disables the delete button
     *
     */
    private void checkListSize() {
        if(deleteButton.isEnabled()) deleteButton.setEnabled(data.getSize() != 0);
    }

    /**
     * Handles events for the three buttons on the UI.
     */
    private class ButtonListener implements ActionListener {

        /**
         * @see ActionListener#actionPerformed(ActionEvent)
         */
        public void actionPerformed(ActionEvent e) {
            //int size = data.getSize();

            JButton source = (JButton) e.getSource();
            if (source == newButton) {
                newPressed();
            } else if (source == saveButton) {
                savePressed();
            } else if (source == deleteButton) {
                deletePressed();
            } else if (source == resetButton) {
                resetPressed();
            }else if (source == exitButton) {
                //Schedule a job for the event-dispatching thread:
                //creating and showing this application's GUI.
                if(currentUserType.equals("Admin")){
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            dispose();
                            createAndShowAdminUI();
                        }
                    });
                }else {
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            dispose();
                            createAndShowOfferTableUI();
                        }
                    });
                }
            }
        }


        private void createAndShowOfferTableUI() {
            new OfferTableUI(
                    new OfferData(
                            new DAONetworkClient(new Offer())
                    )
            );
        }


        /**
         * When the new button is pressed, clear the field display, make them
         * editable and enable the save button.
         */
        private void newPressed() {
            if (assetName.getSelectedIndex() > -1) {
                if(assetName.getSelectedItem() == null || (quantity.getText().equals(""))) {
                    JOptionPane.showMessageDialog(null, "Both Asset Name and Quantity required.");
                    return;
                }

                Property p = new Property((String)assetName.getSelectedItem(), Integer.valueOf(quantity.getText()), unitName);
                data.add(p);
            }
            setFields(true);
        }

        /**
         * When the save button is pressed, check that the name field contains
         * something. If it does, create a new Person object and attempt to add it
         * to the data model. Change the fields back to not editable and make the
         * save button inactive.
         *
         * Check the list size to see if the delete button should be enabled.
         */
        private void savePressed() {
            if (assetName.getSelectedIndex() > -1) {
                if(assetName.getSelectedItem() == null || (quantity.getText().equals(""))) {
                    JOptionPane.showMessageDialog(null, "Both Asset Name and Quantity required.");
                }
                else {
                    Property p = new Property(Integer.valueOf(id.getText()), (String) assetName.getSelectedItem(), Integer.valueOf(quantity.getText()), unitName);
                    data.update(p);
                }
            }
            setFields(true);
        }

        /**
         * When the delete button is pressed remove the selected name from the
         * data model.
         *
         * Clear the fields that were displayed and check to see if the delete
         * button should be displayed.
         *
         * The index here handles cases where the first element of the list is
         * deleted.
         */
        private void deletePressed() {
            int index = nameList.getSelectedIndex();
            data.remove(nameList.getSelectedValue());
            clearFields();
            index--;
            if (index == -1) {
                if (data.getSize() != 0) {
                    index = 0;
                }
            }
            nameList.setSelectedIndex(index);
            checkListSize();
        }
        private void resetPressed() {
            nameList.setSelectedIndex(-1);
            setFields(true);//back to inital state
        }
        private void setFields(boolean enableNew){
            clearFields();
            saveButton.setEnabled(!enableNew);
            deleteButton.setEnabled(!enableNew);
            newButton.setEnabled(enableNew);
            setFieldsEditable(enableNew);
            checkListSize();
        }
    }
    private class ItemChangeListener implements ItemListener{
        @Override
        public void itemStateChanged(ItemEvent event) {
            if (event.getStateChange() == ItemEvent.SELECTED) {
                Object item = event.getItem();
                if(event.getSource() == unitNameList) {
                    displayAssets((String) item);
                    ButtonListener buttonListener = new ButtonListener();
                    buttonListener.setFields(true);
                }
            }
        }
    }

    /**
     * Implements a ListSelectionListener for making the UI respond when a
     * different name is selected from the list.
     */
    private class NameListListener implements ListSelectionListener {

        /**
         * @see ListSelectionListener#valueChanged(ListSelectionEvent)
         */
        public void valueChanged(ListSelectionEvent e) {
            if (nameList.getSelectedValue() != null
                    && !nameList.getSelectedValue().equals("")) {
                data.get(((Property)nameList.getSelectedValue()).getId()).ifPresent(p-> display((Property) p));
                setFieldsEditable(true);
                newButton.setEnabled(false);
                saveButton.setEnabled(true);
                deleteButton.setEnabled(true);
            }
        }
    }

    /**
     * Implements the windowClosing method from WindowAdapter/WindowListener to
     * persist the contents of the data/model.
     */
    private class ClosingListener extends WindowAdapter {

        /**
         * @see WindowAdapter#windowClosing(WindowEvent)
         */
        public void windowClosing(WindowEvent e) {
            data.persist();
            System.exit(0);
        }
    }
    private static void createAndShowAdminUI() {
        new AdminUI();
    }
}

