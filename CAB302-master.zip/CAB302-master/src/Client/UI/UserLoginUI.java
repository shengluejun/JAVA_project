package src.Client.UI;

import src.Common.Model.CurrentUser;
import src.Common.Model.Offer;
import src.Common.Model.User;
import src.Client.DAONetworkClient;
import src.Client.Data.OfferData;
import src.Client.Data.UserData;
import org.mindrot.jbcrypt.BCrypt;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;
import java.util.Optional;

/**
 * This class contains the main UI for a user register, login and change password.
 * @author CAB302
 * @version 1.0
 */
public class UserLoginUI extends JFrame {

    private static final long serialVersionUID = -5050538890770582361L;
    private String currentUser;


    private JTextField userName;
    private JPasswordField password;
    private JLabel statusLabel;

    private JLabel confirmPasswordLabel;
    private JLabel unitNameLabel;
    private JLabel userTypeLabel;
    private JPasswordField confirmPassword;
    private JComboBox unitName;
    private JComboBox userType;

    private JLabel oldPasswordLabel;
    private JPasswordField oldPassword;

    private JButton loginButton;
    private JButton changePasswordButton;
    private JButton resetButton;

    private JButton registerButton;
    private JButton backButton;
    private JButton backToAdminButton;

    private UserData data;

    /**
     * Constructor sets up user interface, adds listeners and displays.
     *
     * @param data The underlying data/model class the UI needs.
     */
    public UserLoginUI(UserData data) {
        currentUser = CurrentUser.getInstance().getCurrentUserName() == null ? "" : CurrentUser.getInstance().getCurrentUserName();
        this.data = data;
        initUI();

        // add listeners to interactive components
        addButtonListeners(new UserLoginUI.ButtonListener());
        addUserTypeListener(new UserLoginUI.ItemChangeListener());
        addClosingListener(new UserLoginUI.ClosingListener());

        // decorate the frame and make it visible
        setTitle("Electronic Asset Trading Platform User Login");
        setMinimumSize(new Dimension(600, 500));
        pack();
        setVisible(true);
    }

    /**
     * Places the detail panel and the button panel in a box layout with vertical
     * alignment and puts a 20 pixel gap between the components and the top and
     * bottom edges of the frame.
     */
    private void initUI() {
        Container contentPane = this.getContentPane();
        //contentPane.setFont(new Font("Calibra", Font.PLAIN, 180));
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));

        contentPane.add(Box.createVerticalStrut(50));
        contentPane.add(makeDetailsPanel());
        contentPane.add(Box.createVerticalStrut(50));
        contentPane.add(makeStatusPanel());
        contentPane.add(Box.createVerticalStrut(50));
        contentPane.add(makeButtonsPanel());
        contentPane.add(Box.createVerticalStrut(50));
    }

    /**
     * Makes a JPanel consisiting of (1) the list of names and (2) the address
     * fields in a box layout with horizontal alignment and puts a 20 pixel gap
     * between the components and the left and right edges of the panel.
     *
     * @return the detail panel.
     */
    private JPanel makeDetailsPanel() {
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.X_AXIS));
        detailsPanel.add(Box.createHorizontalStrut(120));
        detailsPanel.add(makeUserFieldsPanel());
        detailsPanel.add(Box.createHorizontalStrut(120));
        return detailsPanel;
    }
    private JPanel makeStatusPanel(){
        JPanel statusPanel = new JPanel();
        statusPanel.setLayout(new BoxLayout(statusPanel, BoxLayout.X_AXIS));
        statusPanel.add(Box.createHorizontalStrut(120));
        statusLabel = new JLabel();
        statusLabel.setForeground(Color.red);
        statusLabel.setVisible(false);
        statusPanel.add(statusLabel);
        statusPanel.add(Box.createHorizontalStrut(120));
        return statusPanel;
    }

    /**
     * Makes a JPanel containing labels and textfields for each of the pieces of
     * data that are to be recorded for each address. The labels and fields are
     * layed out using a GroupLayout, with the labels vertically grouped, the
     * fields vertically grouped and each label/group pair horizontally grouped.
     *
     * @return a panel containing the address fields
     */
    private JPanel makeUserFieldsPanel() {
        JPanel loginPanel = new JPanel();
        GroupLayout layout = new GroupLayout(loginPanel);
        loginPanel.setLayout(layout);

        // Turn on automatically adding gaps between components
        layout.setAutoCreateGaps(true);

        // Turn on automatically creating gaps between components that touch
        // the edge of the container and the container.
        layout.setAutoCreateContainerGaps(true);

        JLabel userNameLabel = new JLabel("User Name");
        JLabel passwordLabel = new JLabel("Password");
        confirmPasswordLabel = new JLabel("Confirm Password");
        unitNameLabel = new JLabel("Unit Name");
        userTypeLabel = new JLabel("User Type");

        oldPasswordLabel = new JLabel("Old Password");

        userName = new JTextField(20);
        password = new JPasswordField(20);
        confirmPassword = new JPasswordField(20);
        unitName = new JComboBox(data.getUnitList());
        userType = new JComboBox(data.getUserTypeList());
        oldPassword = new JPasswordField(20);

        confirmPasswordLabel.setVisible(false);
        unitNameLabel.setVisible(false);
        userTypeLabel.setVisible(false);
        oldPasswordLabel.setVisible(false);

        confirmPassword.setVisible(false);
        unitName.setVisible(false);
        userType.setVisible(false);
        oldPassword.setVisible(false);



        // Create a sequential group for the horizontal axis.
        GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();

        // The sequential group in turn contains two parallel groups.
        // One parallel group contains the labels, the other the text fields.
        hGroup.addGroup(layout.createParallelGroup().addComponent(userNameLabel).addComponent(oldPasswordLabel).addComponent(passwordLabel).addComponent(confirmPasswordLabel).addComponent(unitNameLabel).addComponent(userTypeLabel));
        hGroup.addGroup(layout.createParallelGroup().addComponent(userName).addComponent(oldPassword).addComponent(password).addComponent(confirmPassword).addComponent(unitName).addComponent(userType));

        layout.setHorizontalGroup(hGroup);

        // Create a sequential group for the vertical axis.
        GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();

        // The sequential group contains five parallel groups that align
        // the contents along the baseline. The first parallel group contains
        // the first label and text field, and the second parallel group contains
        // the second label and text field etc. By using a sequential group
        // the labels and text fields are positioned vertically after one another.
        vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(userNameLabel).addComponent(userName));
        vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(oldPasswordLabel).addComponent(oldPassword));
        vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(passwordLabel).addComponent(password));
        vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(confirmPasswordLabel).addComponent(confirmPassword));
        vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(unitNameLabel).addComponent(unitName));
        vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(userTypeLabel).addComponent(userType));

        layout.setVerticalGroup(vGroup);

        return loginPanel;
    }

    /**
     * Adds the New, Save and Delete buttons to a panel
     */
    private JPanel makeButtonsPanel() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        registerButton = new JButton("Register");
        loginButton = new JButton("Login");
        changePasswordButton = new JButton("Change Password");
        resetButton = new JButton("Reset");
        backButton = new JButton("Back");
        backToAdminButton =new JButton("BackToAdmin");

        backButton.setVisible(false);
        registerButton.setVisible(false);

        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(registerButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        registerButton.setVisible(true);
       if(CurrentUser.getInstance().getCurrentUserName()!=null) {
           registerButton.setVisible(true);
       }

        buttonPanel.add(loginButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(changePasswordButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(resetButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(backButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        if(CurrentUser.getInstance().getCurrentUserName()!=null) {
            buttonPanel.add(backToAdminButton);
            buttonPanel.add(Box.createHorizontalStrut(50));
        }
        return buttonPanel;
    }

    /**
     * Adds a listener to the new, save and delete buttons
     */
    private void addButtonListeners(ActionListener listener) {
        loginButton.addActionListener(listener);
        changePasswordButton.addActionListener(listener);
        resetButton.addActionListener(listener);
        registerButton.addActionListener(listener);
        backButton.addActionListener(listener);
        backToAdminButton.addActionListener(listener);
    }
    private void addUserTypeListener(ItemListener listener){
        userType.addItemListener(listener);
    }

    /**
     * Adds a listener to the JFrame
     */
    private void addClosingListener(WindowListener listener) {
        addWindowListener(listener);
    }

    /**
     * Sets the text in the address text fields to the empty string.
     */
    private void clearFields() {
        userName.setText("");
        password.setText("");
        confirmPassword.setText("");
        unitName.setSelectedIndex(-1);
        userType.setSelectedIndex(-1);
        oldPassword.setText("");
    }

    private class ButtonListener implements ActionListener {

        /**
         * @see ActionListener#actionPerformed(ActionEvent)
         */
        public void actionPerformed(ActionEvent e) {
            int size = data.getSize();

            JButton source = (JButton) e.getSource();
            if (source == loginButton) {
                loginPressed();
            } else if (source == changePasswordButton) {
                changePasswordPressed();
            } else if (source == resetButton) {
                cancelPressed();
            }else if (source == registerButton) {
                registerPressed();
            }else if (source == backButton) {
                backPressed();
            }else if (source == backToAdminButton) {
                backToAdminPressed();
            }
        }

        private void backToAdminPressed() {
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    dispose();
                    createAndShowAdminUI();
                }
            });
        }



        /**
         * When the new button is pressed, clear the field display, make them
         * editable and enable the save button.
         */
        private void loginPressed() {
            String strUserName = userName.getText();
            String strPassword = password.getPassword().toString();

            if(!strUserName.equals("") && !strPassword.equals("")) {
                Optional<Object> user = data.get(strUserName);
                if (user.isPresent() && ((User) (user.get())).getUserName() != null) {
                    User u = (User) (user.get());
                    if (u.getUserName().equals(strUserName) && BCrypt.checkpw(new String(password.getPassword()), u.getPassword())) {
                        CurrentUser.getInstance().setCurrentUserName(u.getUserName());
                        CurrentUser.getInstance().setCurrentUserUnit(u.getUnitName());
                        CurrentUser.getInstance().setCurrentUserType(u.getUserType());
                        String userType = u.getUserType();
                        if(userType.equals("Admin"))
                        {
                            SwingUtilities.invokeLater(new Runnable() {
                                public void run() {
                                    dispose();
                                    new AdminUI();
                                }
                            });
                        }else{
                            SwingUtilities.invokeLater(new Runnable() {
                                public void run() {
                                    dispose();
                                    new OfferTableUI(new OfferData(new DAONetworkClient(new Offer())));
                                }
                            });
                        }

                    } else {
                        clearFields();
                        JOptionPane.showMessageDialog(null, "The user name or password is not correct. Please try again!");
                        return;


                    }
                }else{
                    JOptionPane.showMessageDialog(null, "User not exist. Please register first.");
                    return;
                }

            }else{
                JOptionPane.showMessageDialog(null, "Please enter your user name and password.");
                return;
            }
        }

        /**
         * Used to create register UI
         */
        private void registerPressed() {
            //if click register from login frame
            if(loginButton.isVisible()) {
                clearFields();
                loginButton.setVisible(false);
                setFieldsForRegister(true);
            }else{// if click register from register frame

                if(!Arrays.equals(password.getPassword(), confirmPassword.getPassword())){
                    JOptionPane.showMessageDialog(null, "The password does not match! Please try again!");
                    return;
                }else{
                    String strPassword = BCrypt.hashpw(new String(password.getPassword()), BCrypt.gensalt());

                    if(!userName.getText().equals("") && userType.getSelectedItem()!= null) {
                        if (userType.getSelectedItem().equals("Staff")) {
                            if (unitName.getSelectedItem() == null) {
                                JOptionPane.showMessageDialog(null, "User Name, Password, Unit Name and User Type are required.");
                                return;
                            }
                            data.add(new User(userName.getText(), strPassword, unitName.getSelectedItem().toString(), userType.getSelectedItem().toString()));
                        }
                        else
                            data.add(new User(userName.getText(), strPassword, userType.getSelectedItem().toString()));

                        clearFields();
                        JOptionPane.showMessageDialog(null, "The new user registered successfully!");
                        return;
                    }else{
                        JOptionPane.showMessageDialog(null, "User Name, Password and User Type are required.");
                        return;
                    }

                }
            }
        }

        /**
         * Used to change password
         */
        private void changePasswordPressed() {
            if(loginButton.isVisible() )
            {
                clearFields();
                setFieldsForChangePassword(true);
            }else {
                String strUserName = userName.getText();
                if (strUserName.equals("") || new String(oldPassword.getPassword()).equals("")|| new String(password.getPassword()) .equals("")|| new String(confirmPassword.getPassword()) .equals(""))
                {
                    JOptionPane.showMessageDialog(null, "User Name, Old Password, New Password and Confirm Password are required.");
                    return;
                }
                if(!Arrays.equals(password.getPassword(), confirmPassword.getPassword())) {
                    JOptionPane.showMessageDialog(null, "The password does not match! Please try again!");
                    return;
                }
                String strPassword = BCrypt.hashpw(new String(password.getPassword()), BCrypt.gensalt());
                Optional<Object> user = data.get(strUserName);
                if (user != null && user.isPresent()) {
                    User u =(User) (user.get());
                    if (u.getUserName()!=null && !u.getUserName().equals(strUserName) || !BCrypt.checkpw(new String(oldPassword.getPassword()), u.getPassword())) {
                        clearFields();
                        JOptionPane.showMessageDialog(null, "The user name or old password is not correct. Please try again!");
                        return;

                    }

                    u.setPassword(strPassword);
                    data.update(u);
                    JOptionPane.showMessageDialog(null, "Congratulations! Your password is changed successfully.");
                    backPressed();
                }

            }

        }
        /**
         * Used to cancel pressed button
         */
        private void cancelPressed() {
            clearFields();
        }

        /**
         * Used to back pressed button
         */
        private void backPressed() {
            clearFields();
            setFieldsForRegister(false);
            loginButton.setVisible(true);
            changePasswordButton.setVisible(true);
//            registerButton.setVisible(true);
        }

        /**
         * Used to control what should be displayed.
         * @param isVisible used to control whether to display
         */
        private void setFieldsForRegister(boolean isVisible){
            confirmPasswordLabel.setVisible(isVisible);
            unitNameLabel.setVisible(isVisible);
            userTypeLabel.setVisible(isVisible);

            oldPasswordLabel.setVisible(false);

            confirmPassword.setVisible(isVisible);
            unitName.setVisible(isVisible);
            userType.setVisible(isVisible);
            oldPassword.setVisible(false);


            changePasswordButton.setVisible(!isVisible);
            loginButton.setVisible(!isVisible);
            backButton.setVisible(isVisible);
        }

        /**
         * Used to create change password UI.
         * @param isVisible used to control whether to display
         */
        private void setFieldsForChangePassword(boolean isVisible)
        {
            oldPasswordLabel.setVisible(isVisible);
            confirmPasswordLabel.setVisible(isVisible);
            unitNameLabel.setVisible(!isVisible);
            userTypeLabel.setVisible(!isVisible);

            oldPassword.setVisible(isVisible);
            confirmPassword.setVisible(isVisible);
            unitName.setVisible(!isVisible);
            userType.setVisible(!isVisible);

            registerButton.setVisible(!isVisible);
            loginButton.setVisible(!isVisible);
            backButton.setVisible(isVisible);

        }
    }

    /**
     * Used to control what to display when item change
     */
    private class ItemChangeListener implements ItemListener{
        @Override
        public void itemStateChanged(ItemEvent event) {
            if (event.getStateChange() == ItemEvent.SELECTED) {
                Object item = event.getItem();
                if(event.getSource() == userType) {
                    if(userType.getSelectedItem().equals("Admin")){
                        unitName.setSelectedIndex(-1);
                        unitName.setEnabled(false);
                    }else{
                        unitName.setEnabled(true);

                    }
                }
            }
        }
    }

    /**
     * Implements the windowClosing method from WindowAdapter/WindowListener to
     * persist the contents of the data/model.
     */
    private class ClosingListener extends WindowAdapter {

        /**
         * @see WindowAdapter#windowClosing(WindowEvent)
         */
        public void windowClosing(WindowEvent e) {
            data.persist();
            System.exit(0);
        }
    }

    private static void createAndShowAdminUI() {
        new AdminUI();
    }

}

