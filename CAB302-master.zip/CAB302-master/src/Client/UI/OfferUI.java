package src.Client.UI;

import src.Common.ElectronicPlatformException;
import src.Common.Model.Offer;
import src.Client.Data.OfferData;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.*;
import javax.swing.GroupLayout.Alignment;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * This class contains the main UI for a Offer management.
 *
 * @author CAB302
 * @version 1.0
 */
public class OfferUI extends JFrame {

    private static final long serialVersionUID = -5050538890770582361L;

    private JList nameList;

    private JTextField offerName;
    private JComboBox assetName;
    private JTextField quantity;
    private JComboBox unitName;
    private JComboBox offerType;
    private JTextField price;





    private JButton newButton;

    private JButton saveButton;

    private JButton deleteButton;

    private JButton exitButton;

    /**
     * Create a previousOfferName string
     */
    String previousOfferName;

    /**
     * Create a previousAssetName string
     */
    String previousAssetName;

    /**
     * Create a previousQuantity string
     */
    String previousQuantity;

    /**
     * Create a previousUnitName string
     */
    String previousUnitName;

    /**
     * Create a previousOfferType string
     */
    String previousOfferType;


    /**
     * Create a previousPrice string
     */
    String previousPrice;

    /**
     * create an OfferData object
     */

    OfferData data;
    /**
     * Constructor sets up user interface, adds listeners and displays.
     *
     * @param data The underlying data/model class the UI needs.
     */
    public OfferUI(OfferData data) {
        this.data = data;
        initUI();
        checkListSize();

        // add listeners to interactive components
        addButtonListeners(new OfferUI.ButtonListener());
        addNameListListener(new OfferUI.NameListListener());
        addClosingListener(new OfferUI.ClosingListener());

        // decorate the frame and make it visible
        setTitle("Electronic Asset Trading Platform");
        setMinimumSize(new Dimension(600, 500));
        pack();
        setVisible(true);

    }

    /**
     * Places the detail panel and the button panel in a box layout with vertical
     * alignment and puts a 20 pixel gap between the components and the top and
     * bottom edges of the frame.
     */
    private void initUI() {
        Container contentPane = this.getContentPane();
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));

        contentPane.add(Box.createVerticalStrut(20));
        contentPane.add(makeDetailsPanel());
        contentPane.add(Box.createVerticalStrut(20));
        contentPane.add(makeButtonsPanel());
        contentPane.add(Box.createVerticalStrut(20));
    }

    /**
     * Makes a JPanel consisiting of (1) the list of names and (2) the address
     * fields in a box layout with horizontal alignment and puts a 20 pixel gap
     * between the components and the left and right edges of the panel.
     *
     * @return the detail panel.
     */
    private JPanel makeDetailsPanel() {
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.X_AXIS));
        detailsPanel.add(Box.createHorizontalStrut(20));
        detailsPanel.add(makeNameListPane());
        detailsPanel.add(Box.createHorizontalStrut(20));
        detailsPanel.add(makeUnitFieldsPanel());
        detailsPanel.add(Box.createHorizontalStrut(20));
        return detailsPanel;
    }

    /**
     * Makes a JScrollPane that holds a JList for the list of names in the
     * address book.
     *
     * @return the scrolling name list panel
     */
    private JScrollPane makeNameListPane() {
        nameList = new JList(data.getModel());
        nameList.setFixedCellWidth(200);

        JScrollPane scroller = new JScrollPane(nameList);
        scroller.setViewportView(nameList);
        scroller
                .setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroller
                .setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroller.setMinimumSize(new Dimension(200, 150));
        scroller.setPreferredSize(new Dimension(250, 150));
        scroller.setMaximumSize(new Dimension(250, 200));

        return scroller;
    }

    /**
     * Makes a JPanel containing labels and textfields for each of the pieces of
     * data that are to be recorded for each address. The labels and fields are
     * layed out using a GroupLayout, with the labels vertically grouped, the
     * fields vertically grouped and each label/group pair horizontally grouped.
     *
     * @return a panel containing the address fields
     */
    private JPanel makeUnitFieldsPanel() {
        JPanel offerPanel = new JPanel();
        GroupLayout layout = new GroupLayout(offerPanel);
        offerPanel.setLayout(layout);

        // Turn on automatically adding gaps between components
        layout.setAutoCreateGaps(true);

        // Turn on automatically creating gaps between components that touch
        // the edge of the container and the container.
        layout.setAutoCreateContainerGaps(true);

        JLabel offerNameLabel = new JLabel("Offer Name");
        JLabel assetNameLabel = new JLabel("Asset Name");
        JLabel quantityLabel = new JLabel("Quantity");
        JLabel unitLabel = new JLabel("Unit Name");
        JLabel offerTypeLabel = new JLabel("Offer Type");
        JLabel priceLabel = new JLabel("Price");

        offerName = new JTextField(20);
        assetName = new JComboBox(data.getAssetList());
        assetName.setSelectedIndex(-1);
        quantity = new JTextField(20);
        unitName = new JComboBox(data.getUnitList());
        unitName.setSelectedIndex(-1);
        offerType = new JComboBox(data.getOfferTypeList());
        offerType.setSelectedIndex(-1);
        price = new JTextField(20);
        setFieldsEditable(false);

        // Create a sequential group for the horizontal axis.
        GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();

        // The sequential group in turn contains two parallel groups.
        // One parallel group contains the labels, the other the text fields.
        hGroup.addGroup(layout.createParallelGroup().addComponent(offerNameLabel).addComponent(assetNameLabel)
                .addComponent(quantityLabel).addComponent(unitLabel).addComponent(offerTypeLabel).addComponent(priceLabel));
        hGroup.addGroup(layout.createParallelGroup().addComponent(offerName).addComponent(assetName).addComponent(quantity)
                .addComponent(unitName).addComponent(offerType).addComponent(price));
        layout.setHorizontalGroup(hGroup);

        // Create a sequential group for the vertical axis.
        GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();

        vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE)
                .addComponent(offerNameLabel).addComponent(offerName));
        vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE)
                .addComponent(assetNameLabel).addComponent(assetName));
        vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE)
                .addComponent(quantityLabel).addComponent(quantity));
        vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE)
                .addComponent(unitLabel).addComponent(unitName));
        vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE)
                .addComponent(offerTypeLabel).addComponent(offerType));
        vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE)
                .addComponent(priceLabel).addComponent(price));

        layout.setVerticalGroup(vGroup);

        return offerPanel;
    }

    /**
     * Adds the New, Save and Delete buttons to a panel
     */
    private JPanel makeButtonsPanel() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        newButton = new JButton("New");
        saveButton = new JButton("Save");
        saveButton.setEnabled(false);
        deleteButton = new JButton("Delete");
        exitButton = new JButton("Back");
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(newButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(saveButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(deleteButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(exitButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        return buttonPanel;
    }

    /**
     * Adds a listener to the new, save and delete buttons
     */
    private void addButtonListeners(ActionListener listener) {
        newButton.addActionListener(listener);
        saveButton.addActionListener(listener);
        deleteButton.addActionListener(listener);
        exitButton.addActionListener(listener);
    }

    /**
     * Adds a listener to the name list
     */
    private void addNameListListener(ListSelectionListener listener) {
        nameList.addListSelectionListener(listener);
    }

    /**
     * Adds a listener to the JFrame
     */
    private void addClosingListener(WindowListener listener) {
        addWindowListener(listener);
    }

    /**
     * Sets the text in the address text fields to the empty string.
     */
    private void clearFields() {
        offerName.setText("");
        assetName.setSelectedIndex(-1);
        quantity.setText("");
        unitName.setSelectedIndex(-1);
        offerType.setSelectedIndex(-1);
        price.setText("");
    }

    /**
     * Sets whether or not the address fields are editable.
     */
    private void setFieldsEditable(boolean editable) {
        offerName.setEditable(editable);
        assetName.setEditable(editable);
        quantity.setEditable(editable);
        unitName.setEditable(editable);
        offerType.setEditable(editable);
        price.setEditable(editable);
    }


    private void display(Offer o) {
        if (o != null) {
            setFieldsEditable(true);
            saveButton.setEnabled(true);

            offerName.setText(o.getOfferName());
            assetName.setSelectedItem(o.getAssetName());
            quantity.setText(String.valueOf(o.getQuantity()));
            unitName.setSelectedItem(o.getUnitName());
            offerType.setSelectedItem(o.getOfferType());
            price.setText(String.valueOf(o.getPrice()));
        }
    }

    /**
     * Checks size of data/model and enables/disables the delete button
     *
     */
    private void checkListSize() {
        deleteButton.setEnabled(data.getSize() != 0);
    }

    /**
     * Handles events for the three buttons on the UI.
     */
    private class ButtonListener implements ActionListener {

        /**
         * @see ActionListener#actionPerformed(ActionEvent)
         */
        public void actionPerformed(ActionEvent e) {
            int size = data.getSize();

            JButton source = (JButton) e.getSource();
            if (source == newButton) {
                newPressed();
            } else if (source == saveButton) {
                try {
                    savePressed();
                } catch (ElectronicPlatformException electronicPlatformException) {
                    electronicPlatformException.printStackTrace();
                }
            } else if (source == deleteButton) {
                deletePressed();
            }
            else if (source == exitButton) {
                //Schedule a job for the event-dispatching thread:
                //creating and showing this application's GUI.
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        dispose();
                        createAndShowAdminUI();
                    }
                });
            }
        }

        /**
         * When the new button is pressed, clear the field display, make them
         * editable and enable the save button.
         */
        private void newPressed() {
            clearFields();
            setFieldsEditable(true);
            saveButton.setEnabled(true);
        }

        /**
         * When the save button is pressed, check that the name field contains
         * something. If it does, create a new Person object and attempt to add it
         * to the data model. Change the fields back to not editable and make the
         * save button inactive.
         *
         * Check the list size to see if the delete button should be enabled.
         */
        private void savePressed() throws ElectronicPlatformException {

            if (offerName.getText() != null && !offerName.getText().equals("") && !offerName.getText().equals(previousOfferName)) {
                Offer o = new Offer(offerName.getText(), (String)assetName.getSelectedItem(), Integer.valueOf(quantity.getText()),
                        (String)unitName.getSelectedItem(),(String)offerType.getSelectedItem(),Integer.valueOf(price.getText()));
                data.add(o);
            }

            else if (offerName.getText() != null && !offerName.getText().equals("") &&
                    (!assetName.getSelectedItem().equals(previousAssetName)||!quantity.getText().equals(previousQuantity)||
                            !unitName.getSelectedItem().equals(previousUnitName)||!offerType.getSelectedItem().equals(previousOfferType)||
                            !price.getText().equals(previousPrice))) {
                Offer o = new Offer(offerName.getText(), (String)assetName.getSelectedItem(), Integer.valueOf(quantity.getText()),
                        (String)unitName.getSelectedItem(),(String)offerType.getSelectedItem(),Integer.valueOf(price.getText()));
                data.update(o);
            }


            setFieldsEditable(false);
            saveButton.setEnabled(false);
            checkListSize();
        }

        /**
         * When the delete button is pressed remove the selected name from the
         * data model.
         *
         * Clear the fields that were displayed and check to see if the delete
         * button should be displayed.
         *
         * The index here handles cases where the first element of the list is
         * deleted.
         */
        private void deletePressed() {
            int index = nameList.getSelectedIndex();
            data.remove(nameList.getSelectedValue());
            clearFields();
            index--;
            if (index == -1) {
                if (data.getSize() != 0) {
                    index = 0;
                }
            }
            nameList.setSelectedIndex(index);
            checkListSize();
        }
    }

    /**
     * Implements a ListSelectionListener for making the UI respond when a
     * different name is selected from the list.
     */
    private class NameListListener implements ListSelectionListener {

        /**
         * @see ListSelectionListener#valueChanged(ListSelectionEvent)
         */
        public void valueChanged(ListSelectionEvent e) {
            if (nameList.getSelectedValue() != null
                    && !nameList.getSelectedValue().equals("")) {
                data.get(nameList.getSelectedValue()).ifPresent(a-> display((Offer)a));
                previousOfferName = offerName.getText();
                previousAssetName = (String)assetName.getSelectedItem();
                previousQuantity = quantity.getText();
                previousUnitName = (String)unitName.getSelectedItem();
                previousOfferType = (String)offerType.getSelectedItem();
                previousPrice = price.getText();
            }
        }
    }

    /**
     * Implements the windowClosing method from WindowAdapter/WindowListener to
     * persist the contents of the data/model.
     */
    private class ClosingListener extends WindowAdapter {

        /**
         * @see WindowAdapter#windowClosing(WindowEvent)
         */
        public void windowClosing(WindowEvent e) {
            data.persist();
            System.exit(0);
        }
    }

    private static void createAndShowAdminUI() {
        new AdminUI();
    }
}
