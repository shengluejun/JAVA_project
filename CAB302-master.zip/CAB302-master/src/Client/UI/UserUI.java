package src.Client.UI;

import src.Client.Data.UserData;
import src.Common.Model.User;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.Optional;

/**
 * This class contains the main UI for a user management.
 * This class allows user to add/delete/update/view user records.
 * @author CAB302
 * @version 1.0
 */
public class UserUI extends JFrame {


    private static final long serialVersionUID = -5050538890770582361L;

    private JList nameList;

    private JTextField userName;

    private JComboBox unitName;

    private JComboBox userType;

    private JButton saveButton;

    private JButton deleteButton;

    private JButton exitButton;

    String previousUserName;

    String previousUnitName;

    String previousUserType;

    private UserData data;

    /**
     * Constructor sets up user interface, adds listeners and displays.
     *
     * @param data The underlying data/model class the UI needs.
     */
    public UserUI(UserData data) {
        this.data = data;
        initUI();
        checkListSize();

        // add listeners to interactive components
        addButtonListeners(new UserUI.ButtonListener());
        addUserTypeListener(new UserUI.ItemChangeListener());
        addNameListListener(new UserUI.NameListListener());
        addClosingListener(new UserUI.ClosingListener());

        // decorate the frame and make it visible
        setTitle("Electronic Asset Trading Platform");
        setMinimumSize(new Dimension(600, 500));
        pack();
        setVisible(true);

    }

    /**
     * Places the detail panel and the button panel in a box layout with vertical
     * alignment and puts a 20 pixel gap between the components and the top and
     * bottom edges of the frame.
     */
    private void initUI() {
        Container contentPane = this.getContentPane();
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));

        contentPane.add(Box.createVerticalStrut(20));
        contentPane.add(makeDetailsPanel());
        contentPane.add(Box.createVerticalStrut(20));
        contentPane.add(makeButtonsPanel());
        contentPane.add(Box.createVerticalStrut(20));
    }

    /**
     * Makes a JPanel consisiting of (1) the list of names and (2) the address
     * fields in a box layout with horizontal alignment and puts a 20 pixel gap
     * between the components and the left and right edges of the panel.
     *
     * @return the detail panel.
     */
    private JPanel makeDetailsPanel() {
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.X_AXIS));
        detailsPanel.add(Box.createHorizontalStrut(20));
        detailsPanel.add(makeNameListPane());
        detailsPanel.add(Box.createHorizontalStrut(20));
        detailsPanel.add(makeUnitFieldsPanel());
        detailsPanel.add(Box.createHorizontalStrut(20));
        return detailsPanel;
    }

    /**
     * Makes a JScrollPane that holds a JList for the list of names in the
     * address book.
     *
     * @return the scrolling name list panel
     */
    private JScrollPane makeNameListPane() {
        nameList = new JList(data.getModel());
        nameList.setFixedCellWidth(200);

        JScrollPane scroller = new JScrollPane(nameList);
        scroller.setViewportView(nameList);
        scroller
                .setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroller
                .setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroller.setMinimumSize(new Dimension(200, 150));
        scroller.setPreferredSize(new Dimension(250, 150));
        scroller.setMaximumSize(new Dimension(250, 200));

        return scroller;
    }

    /**
     * Makes a JPanel containing labels and textfields for each of the pieces of
     * data that are to be recorded for each address. The labels and fields are
     * layed out using a GroupLayout, with the labels vertically grouped, the
     * fields vertically grouped and each label/group pair horizontally grouped.
     *
     * @return a panel containing the address fields
     */
    private JPanel makeUnitFieldsPanel() {
        JPanel userPanel = new JPanel();
        GroupLayout layout = new GroupLayout(userPanel);
        userPanel.setLayout(layout);

        // Turn on automatically adding gaps between components
        layout.setAutoCreateGaps(true);

        // Turn on automatically creating gaps between components that touch
        // the edge of the container and the container.
        layout.setAutoCreateContainerGaps(true);

        JLabel userNameLabel = new JLabel("User Name");
        JLabel unitLabel = new JLabel("Unit Name");
        JLabel userTypeLabel = new JLabel("User Type");


        userName = new JTextField(20);
        unitName = new JComboBox(data.getUnitList());
        unitName.setSelectedIndex(-1);
        userType = new JComboBox(data.getUserTypeList());
        userType.setSelectedIndex(-1);
        setFieldsEditable(false);

        // Create a sequential group for the horizontal axis.
        GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();

        // The sequential group in turn contains two parallel groups.
        // One parallel group contains the labels, the other the text fields.
        hGroup.addGroup(layout.createParallelGroup().addComponent(userNameLabel)
                .addComponent(unitLabel).addComponent(userTypeLabel));
        hGroup.addGroup(layout.createParallelGroup().addComponent(userName)
                .addComponent(unitName).addComponent(userType));
        layout.setHorizontalGroup(hGroup);

        // Create a sequential group for the vertical axis.
        GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();

        vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(userNameLabel).addComponent(userName));
        vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(unitLabel).addComponent(unitName));
        vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(userTypeLabel).addComponent(userType));

        layout.setVerticalGroup(vGroup);

        return userPanel;
    }

    /**
     * Adds the New, Save and Delete buttons to a panel
     */
    private JPanel makeButtonsPanel() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        saveButton = new JButton("Save");
        saveButton.setEnabled(false);
        deleteButton = new JButton("Delete");
        exitButton = new JButton("Back");

        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(saveButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(deleteButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        buttonPanel.add(exitButton);
        buttonPanel.add(Box.createHorizontalStrut(50));
        return buttonPanel;
    }

    /**
     * Adds a listener to the new, save and delete buttons
     */
    private void addButtonListeners(ActionListener listener) {
        saveButton.addActionListener(listener);
        deleteButton.addActionListener(listener);
        exitButton.addActionListener(listener);
    }
    private void addUserTypeListener(ItemListener listener){
        userType.addItemListener(listener);
    }
    /**
     * Adds a listener to the name list
     */
    private void addNameListListener(ListSelectionListener listener) {
        nameList.addListSelectionListener(listener);
    }

    /**
     * Adds a listener to the JFrame
     */
    private void addClosingListener(WindowListener listener) {
        addWindowListener(listener);
    }

    /**
     * Sets the text in the address text fields to the empty string.
     */
    private void clearFields() {
        userName.setText("");
        unitName.setSelectedIndex(-1);
        userType.setSelectedIndex(-1);
    }

    /**
     * Sets whether or not the address fields are editable.
     */
    private void setFieldsEditable(boolean editable) {
        userName.setEditable(!editable);
        unitName.setEditable(editable);
        userType.setEditable(editable);
    }


    private void display(User u) {
        if (u != null) {
            setFieldsEditable(true);
            saveButton.setEnabled(true);

            userName.setText(u.getUserName());
            unitName.setSelectedItem(u.getUnitName());
            userType.setSelectedItem(u.getUserType());
        }
    }

    /**
     * Checks size of data/model and enables/disables the delete button
     */
    private void checkListSize() {
        deleteButton.setEnabled(data.getSize() != 0);
    }

    /**
     * Handles events for the three buttons on the UI.
     */
    private class ButtonListener implements ActionListener {

        /**
         * @see ActionListener#actionPerformed(ActionEvent)
         */
        public void actionPerformed(ActionEvent e) {
            int size = data.getSize();

            JButton source = (JButton) e.getSource();
             if (source == saveButton) {
                savePressed();
            } else if (source == deleteButton) {
                deletePressed();
            } else if (source == exitButton) {
                //Schedule a job for the event-dispatching thread:
                //creating and showing this application's GUI.
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        dispose();
                        createAndShowAdminUI();
                    }
                });
            }
        }



        /**
         * When the save button is pressed, check that the name field contains
         * something. If it does, create a new Person object and attempt to add it
         * to the data model. Change the fields back to not editable and make the
         * save button inactive.
         * <p>
         * Check the list size to see if the delete button should be enabled.
         */
        private void savePressed() {
            try {
            Optional<Object> o = data.get(userName.getText());
            if (o.isPresent()) {
                User u = (User) o.get();
                if (userType.getSelectedItem().toString().equals("Admin")) {
                    u.setUserType(userType.getSelectedItem().toString());
                    u.setUnitName("");
                } else if(userType.getSelectedItem().toString().equals("Staff") && unitName.getSelectedItem().toString()!=null
                && unitName.getSelectedItem().toString()!=""){
                    u.setUserType(userType.getSelectedItem().toString());
                    u.setUnitName(unitName.getSelectedItem().toString());
                } else{
                JOptionPane.showMessageDialog(null, "Your inputting information is incomplete !");
                return;
            }
                data.update(u);
            }

            setFieldsEditable(false);
            saveButton.setEnabled(false);
            checkListSize();
        }  catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Your inputting information is incomplete !");
        }
        }


        /**
         * When the delete button is pressed remove the selected name from the
         * data model.
         * <p>
         * Clear the fields that were displayed and check to see if the delete
         * button should be displayed.
         * <p>
         * The index here handles cases where the first element of the list is
         * deleted.
         */
        private void deletePressed() {
            int index = nameList.getSelectedIndex();
            data.remove(nameList.getSelectedValue());
            clearFields();
            index--;
            if (index == -1) {
                if (data.getSize() != 0) {
                    index = 0;
                }
            }
            nameList.setSelectedIndex(index);
            checkListSize();
        }
    }

    /**
     * Implements a ListSelectionListener for making the UI respond when a
     * different name is selected from the list.
     */
    private class NameListListener implements ListSelectionListener {

        /**
         * @see ListSelectionListener#valueChanged(ListSelectionEvent)
         */
        public void valueChanged(ListSelectionEvent e) {
            if (nameList.getSelectedValue() != null
                    && !nameList.getSelectedValue().equals("")) {
                data.get(nameList.getSelectedValue()).ifPresent(u -> display((User) u));
                previousUserName = userName.getText();
                previousUnitName = (String) unitName.getSelectedItem();
                previousUserType = (String) userType.getSelectedItem();

            }
        }
    }

    /**
     * Implements a ListSelectionListener for making the UI respond when a
     * different name is selected from the list.
     */
    private class ItemChangeListener implements ItemListener{
        @Override
        public void itemStateChanged(ItemEvent event) {
            if (event.getStateChange() == ItemEvent.SELECTED) {
                Object item = event.getItem();
                if(event.getSource() == userType) {
                    if(userType.getSelectedItem().equals("Admin")){
                        unitName.setSelectedIndex(-1);
                        unitName.setEnabled(false);
                    }else{
                        unitName.setEnabled(true);

                    }
                }
            }
        }
    }
    /**
     * Implements the windowClosing method from WindowAdapter/WindowListener to
     * persist the contents of the data/model.
     */
    private class ClosingListener extends WindowAdapter {

        /**
         * @see WindowAdapter#windowClosing(WindowEvent)
         */
        public void windowClosing(WindowEvent e) {
            data.persist();
            System.exit(0);
        }
    }

    private static void createAndShowAdminUI() {
        new AdminUI();
    }
}
