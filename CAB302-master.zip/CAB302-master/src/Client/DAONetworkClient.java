package src.Client;

import src.Common.DAO.DAOBase;
import src.Common.Model.*;
import src.Common.DAO.IDAOBase;
import src.Common.DAO.DAOBase;
import src.Common.ServerConnection;

import javax.swing.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;


/**
 * This class contains the main program for network access to server end program to do the actual actions.
 *
 * @author CAB302
 * @version 1.0
 */
public class DAONetworkClient implements IDAOBase<Object> {
    private static final String HOSTNAME = ServerConnection.getInstance().getHostName();
    private static final int PORT = ServerConnection.getInstance().getPort();

    private Socket socket;
    private ObjectOutputStream outputStream;
    private ObjectInputStream inputStream;


    private DAOBase.ClientClass client;

    /**
     * Initial client class ,Convert the obtained object into the required client type.
     * @param o The object need to be converted.
     */
    private void initClientClass(Object o){
        if(o instanceof Asset)
            client = DAOBase.ClientClass.ASSET;
        else if (o instanceof Unit)
            client = DAOBase.ClientClass.UNIT;
        else if(o instanceof User)
            client = DAOBase.ClientClass.USER;
        else if (o instanceof Offer)
            client = DAOBase.ClientClass.OFFER;
        else if (o instanceof Property)
            client = DAOBase.ClientClass.PROPERTY;
        else if (o instanceof TradeHistory)
            client = DAOBase.ClientClass.TRADEHISTORY;
        else{}
    }

    /**
     * Create client socket and input stream and output stream.
     * @param o The object need to be initialized.
     */
    public DAONetworkClient(Object o) {
        try {
            // Persist a single connection through the whole lifetime of the application.
            // We will re-use this same connection/socket, rather than repeatedly opening
            // and closing connections.
            socket = new Socket(HOSTNAME, PORT);
            outputStream = new ObjectOutputStream(socket.getOutputStream());
            inputStream = new ObjectInputStream(socket.getInputStream());
            initClientClass(o);
        } catch (IOException e) {
            // If the server connection fails, we're going to throw exceptions
            // whenever the application actually tries to query anything.
            // But it wasn't written to handle this, so make sure your
            // server is running beforehand!
            System.out.println("Failed to connect to server");
            JOptionPane.showMessageDialog(null, "Failed to connect to server !");
            System.exit(0);
        }
    }

    /**
     * Add an item through client socket by output stream.
     * @param o The object need to be delivered.
     */
    @Override
    public boolean addItem(Object o) {
        if (o == null)
            throw new IllegalArgumentException("Item cannot be null");

        try {
            // tell the server to expect a person's details
            outputStream.writeObject(client);
            outputStream.writeObject(DAOBase.Command.ADD_ITEM);

            // send the actual data
            outputStream.writeObject(o);
            outputStream.flush();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Delete an item through client socket by output stream.
     * @param name Use the name to locate the item to be deleted.
     */
    @Override
    public boolean deleteItem(String name) {
        try {
            outputStream.writeObject(client);
            outputStream.writeObject(DAOBase.Command.DELETE_ITEM);
            outputStream.writeObject(name);
            outputStream.flush();
            return true;
        } catch (IOException | ClassCastException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Update an item through client socket by output stream.
     * @param o Use the name to locate the item to be deleted.
     */
    @Override
    public boolean updateItem(Object o) {

        try {
            outputStream.writeObject(client);
            outputStream.writeObject(DAOBase.Command.UPDATE_ITEM);
            outputStream.writeObject(o);
            outputStream.flush();
            return true;
        } catch (IOException | ClassCastException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * get an item through client socket by output stream.
     * @param name Use the name to locate the item to be got.
     */
    @Override
    public Optional<Object> getItem(String name) {
        try {
            // tell the server to expect a person's name, and send us back their details
            outputStream.writeObject(client);
            outputStream.writeObject(DAOBase.Command.GET_ITEM);
            outputStream.writeObject(name);

            // flush because if we don't, the request might not get sent yet, and we're waiting for a response
            outputStream.flush();

            // read the person's details back from the server
            return Optional.of(inputStream.readObject());
        } catch (IOException | ClassNotFoundException | ClassCastException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * get item list through client socket by output stream.
     * - No parameters
     */
    @Override
    public List<Object> getItemList() {
        try {
            // tell the server to expect a person's name, and send us back their details
            outputStream.writeObject(client);
            outputStream.writeObject(DAOBase.Command.GET_ITEMLIST);
            outputStream.flush();

            // read the person's details back from the server
            return (List<Object>) inputStream.readObject();
        } catch (IOException | ClassNotFoundException | ClassCastException e) {
            e.printStackTrace();
            return (List<Object>) new HashSet<Object>();
        }
    }

    public int getSize() {
        /**
         * Protocol documentation might look like:
         * GET_SIZE:
         *  - No parameters
         *
         * src.Server.Server responds with:
         *   - (int) number of entries
         */
        try {
            outputStream.writeObject(client);
            outputStream.writeObject(DAOBase.Command.GET_SIZE);
            outputStream.flush();

            // read the person's details back from the server
            return inputStream.readInt();
        } catch (IOException | ClassCastException e) {
            e.printStackTrace();
            return 0;
        }
    }



    /**
     * Close the window, and exit
     * - No parameters
     */
    public void close() {
        try {
            //connection.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * get name list through client socket by output stream.
     * - No parameters
     */
    @Override
    public Set<String> getNameList() {
        try {
            outputStream.writeObject(client);
            outputStream.writeObject(DAOBase.Command.GET_NAMELIST);
            outputStream.flush();
            return (Set<String>) inputStream.readObject();
        } catch (IOException | ClassNotFoundException | ClassCastException e) {
            e.printStackTrace();
            return new HashSet<>();
        }
    }
}
