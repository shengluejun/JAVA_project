package src.Client;

import src.Common.Model.User;
import src.Client.Data.UserData;
import src.Client.UI.UserLoginUI;

import javax.swing.*;



/**
 * This class contains the main program for a user register, login and change password.
 * @author CAB302
 * @version 1.0
 */
public class UserLoginMain {

    /**
     * Create the GUI.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() {
        new UserLoginUI(new UserData( new DAONetworkClient(new User())));
    }

    /**
     * @param args create new class as param
     */
    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
}