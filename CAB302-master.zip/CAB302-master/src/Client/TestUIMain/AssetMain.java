package src.Client.TestUIMain;

import src.Common.Model.Asset;
import src.Client.DAONetworkClient;
import src.Client.Data.AssetData;
import src.Client.UI.AssetUI;

import javax.swing.*;

/**
 * This class contains the main program for a Asset management.
 *
 * @author CAB302
 * @version 1.0
 */
public class AssetMain {

    /**
     * Create the GUI.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() {
        new AssetUI(
                new AssetData(
                        new DAONetworkClient( new Asset())
                )
        );
    }

    /**
     * Run this GUI
     * @param args Run GUI
     */
    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
}
