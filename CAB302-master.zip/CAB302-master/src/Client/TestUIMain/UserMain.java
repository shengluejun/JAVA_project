package src.Client.TestUIMain;

import src.Client.DAONetworkClient;
import src.Client.Data.UserData;
import src.Common.Model.User;
import src.Client.UI.UserUI;

import javax.swing.*;
/**
 * This class contains the main program for a user management.
 * This class allows user to add/delete/update/view user records.
 * @author CAB302
 * @version 1.0
 */
public class UserMain {
    /**
     * Create the GUI.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() {
        new UserUI(
                new UserData(
                        new DAONetworkClient(new User())
                )
        );
    }

    /**
     * Create GUI
     * @param args Create createAndShow GUI
     */
    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
}
