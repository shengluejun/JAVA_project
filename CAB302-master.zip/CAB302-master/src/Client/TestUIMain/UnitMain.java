package src.Client.TestUIMain;

import src.Common.Model.Unit;
import src.Client.DAONetworkClient;
import src.Client.Data.UnitData;
import src.Client.UI.UnitUI;

import javax.swing.*;
/**
 * This class contains the main program for a unit management.
 *
 * @author CAB302
 * @version 1.0
 */
public class UnitMain {

    /**
     * Create the GUI.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() {
        new UnitUI(
                new UnitData(
                        new DAONetworkClient(new Unit())
                )
        );
    }

    /**
     * Run this GUI
     * @param args Run GUI
     */
    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
}

