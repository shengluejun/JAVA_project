package src.Client.TestUIMain;

import src.Common.Model.Offer;
import src.Client.DAONetworkClient;
import src.Client.Data.OfferData;
import src.Client.UI.OfferUI;

import javax.swing.*;

/**
 * This class contains the main program for a Offer management.
 *
 * @author CAB302
 * @version 1.0
 */
public class OfferMain {

    /**
     * Create the GUI.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() {
        new OfferUI(
                new OfferData(
                        new DAONetworkClient(new Offer())
                )
        );
    }

    /**
     * Run this GUI
     * @param args Run GUI
     */
    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }

}
