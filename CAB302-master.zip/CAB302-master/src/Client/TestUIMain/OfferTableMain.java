package src.Client.TestUIMain;

import src.Common.Model.Offer;
import src.Client.DAONetworkClient;
import src.Client.Data.OfferData;
import src.Client.UI.OfferTableUI;

import javax.swing.*;

/**
 * This class contains the main program for a offer management.
 * It includes view current sell offers, buy offers, add/update/delete/view my sell offers, my buy offers.
 * It also allows user to access to the current property list of the user's unit.
 * And the user also can view the recent trade history by clicking "trade history" button right on top right corner of the frame.
 * The server will do the scheduled job to match sell offers and buy offers. When matches, will pop up a dialogue to user to
 * remind user that his/her offer was processed. Click "Refresh" button will get the latest unprocessed offers on this frame.
 * Click "trade history" can view all the trade history list.
 * The user can sort trade history by clicking transaction time header to get the latest trade list.
 * User is also able to filter out the trade history list by put some text on filter text field.
 * On Offer Table UI, user can also filter current buy offer list/sell offer list/my buy offer list/my sell offer list
 * by put unit name, asset name and filter text.
 *
 * @author CAB302
 * @version 1.0
 */
public class OfferTableMain {
    /**
     * Create the GUI.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() {
        new OfferTableUI(
                new OfferData(
                        new DAONetworkClient(new Offer())
                )
        );
    }

    /**
     * Run this GUI
     * @param args Run GUI
     */
    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
}
