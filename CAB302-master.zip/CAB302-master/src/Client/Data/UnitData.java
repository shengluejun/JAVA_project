package src.Client.Data;

import src.Common.Model.Unit;
import src.Client.DAONetworkClient;

import javax.swing.*;
import java.util.Optional;

/**
 * A solution to the "unit data" part of CAB302 Assignment which provides data for unit management UI.
 *
 * @author CAB302
 * @version 1.0
 */
public class UnitData {
    DefaultListModel listModel;

    DAONetworkClient unitData;
    /**
     * Construct a unit data with a network client that accesses to sever end.
     *
     * @param daoNetworkClient - provide access to server end to action database.
     */
    public UnitData(DAONetworkClient daoNetworkClient) {
        listModel = new DefaultListModel();
        unitData = daoNetworkClient;

        // add the retrieved data to the list model
        for (String name : unitData.getNameList()) {
            listModel.addElement(name);
        }
    }

    /**
     * Add a unit data to list model.
     *
     * @param u - the object of Unit.
     */
    public void add(Unit u) {
        // check to see if the person is already in the book
        // if not add to the address book and the list model
        if (!listModel.contains(u.getUnitName())) {
            listModel.addElement(u.getUnitName());
            unitData.addItem(u);
        }
    }
    /**
     * Remove the object.
     *
     * @param key - the object.
     */
    public void remove(Object key) {
        // remove from both list and map
        listModel.removeElement(key);
        unitData.deleteItem((String) key);
    }
    /**
     * Update the unit.
     *
     * @param u - the object of Unit.
     */
    public void update(Unit u) {
            unitData.updateItem(u);
    }

    /**
     * Close the unit Data.
     */
    public void persist() {
        unitData.close();
    }

    /**
     * Get the object.
     * @param key the object
     * @return the object of Optional
     */
    public Optional<Object> get(Object key) {
        return (Optional<Object>) unitData.getItem(key.toString());
    }
    /**
     * Get the model.
     * @return the model list
     */
    public ListModel getModel() {
        return listModel;
    }
    /**
     * Get the size.
     * @return the size of unitdata
     */
    public int getSize() {
        return unitData.getSize();
    }
}
