package src.Client.Data;

import src.Common.Model.Asset;
import src.Common.Model.CurrentUser;
import src.Common.Model.Property;
import src.Common.Model.Unit;
import src.Client.DAONetworkClient;


import javax.swing.*;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * A solution to the "property data" part of CAB302 Assignment which provides data for property management UI.
 *
 * @author CAB302
 * @version 1.0
 */
public class PropertyData {

    DefaultListModel listModel;

    DAONetworkClient propertyData;
    private String unitName;
    /**
     * Construct a property data with a network client that accesses to sever end.
     *
     * @param daoNetworkClient - provide access to server end to action database.
     */
    public PropertyData(DAONetworkClient daoNetworkClient) {
        this.unitName = CurrentUser.getInstance().getCurrentUserUnit();
        propertyData = daoNetworkClient;
        listModel = new DefaultListModel();
    }
    /**
     * Add new property.
     *
     * @param a - the object of Property.
     */
    public void add(Property a) {
        if (!isContained(a)) {
            propertyData.addItem(a);
            Optional<Object> p = (Optional<Object>)propertyData.getItem(a.getAssetName()+","+a.getUnitName());
            if(p.isPresent()){
                Property property = (Property) p.get();
                listModel.addElement(property);
            }
        }else{
            JOptionPane.showMessageDialog(null, "This asset "+ a.getAssetName() +" already existed in this unit. Please select it from list to update quantity.");
        }

    }
    /**
     * update new property.
     *
     * @param a - the object of Property.
     */
    public void update(Property a) {
        if (isContained(a)) {
            //int i = listModel.elements().
            propertyData.updateItem(a);
            //listModel.setElementAt(a, i);
       }
    }
    /**
     * Remove new property.
     *
     * @param key - the object of Property.
     */
    public void remove(Object key) {
        // remove from both list and map
        listModel.removeElement(key);
        propertyData.deleteItem(String.valueOf(((Property)key).getId()));
    }
    /**
     * Close propertyData.
     */
    public void persist() {
        propertyData.close();
    }
    /**
     * Get the item.
     * @param key used to get item
     * @return the object of Optional
     */
    public Optional<Object> get(Object key) {
        return (Optional<Object>)propertyData.getItem(key.toString());
    }

    /**
     * Set the model.
     * @param unitName used to get item
     */
    public void setupModel(String unitName) {
        this.unitName = unitName;
        if(this.unitName!= null && this.unitName != "")
            listModel = filterModel(unitName);
    }
    /**
     * Get the model.
     * @return  model
     */
    public ListModel getModel() {
        return listModel;
    }
    /**
     * Get the model.
     * @return  the number of size
     */
    public int getSize() {
        return  ((List<Property>)(Object)propertyData.getItemList()).stream().filter(p -> p.getUnitName().equals(this.unitName)).collect(Collectors.toList()).size();
    }
    /**
     * Determine whether contained.
     * @param  a the object
     * @return  the value of boolean
     */
    public boolean isContained(Property a){
        boolean contained = false;
        for(int i = 0; i< listModel.size(); i++)
        {
            if(((Property)listModel.get(i)).getAssetName().equals(a.getAssetName()))
                contained = true;
        }
        return contained;
    }
    /**
     * Get unit list.
     * @return  the Combo Box Model
     */
    public DefaultComboBoxModel getUnitList(){
        UnitData u = new UnitData(new DAONetworkClient(new Unit()));
        DefaultListModel unitListModel = (DefaultListModel)u.getModel();
        String[] lstArray = new String[unitListModel.getSize()];
        unitListModel.copyInto(lstArray);
        return new DefaultComboBoxModel(lstArray);
    }
    /**
     * Get asset list.
     * @return  the Combo Box Model
     */
    public DefaultComboBoxModel getAssetList(){
        AssetData a = new AssetData(new DAONetworkClient(new Asset()));
        DefaultListModel assetListModel = (DefaultListModel)a.getModel();
        String[] lstArray = new String[assetListModel.getSize()];
        assetListModel.copyInto(lstArray);
        return new DefaultComboBoxModel(lstArray);
    }
    /**
     * Get asset list.
     * @param unitName the unit name
     * @return  the List Model
     */
    public DefaultListModel filterModel(String unitName) {
        listModel.clear();
        List<Property> listProperty = (List<Property>) (Object)propertyData.getItemList();
        if(!listProperty.isEmpty()){
            for (Property p : listProperty) {
                if(p.getUnitName() != null && p.getUnitName().equals(unitName))
                    listModel.addElement(p);
            }
        }
        return listModel;
    }
}
