package src.Client.Data;

import src.Client.DAONetworkClient;
import src.Common.Model.*;
import src.Common.DAO.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;


/**
 * A solution to the "offer data" part of CAB302 Assignment which provides data for offer management UI.
 *
 * @author CAB302
 * @version 1.0
 */
public class OfferData {
    DefaultListModel listModel;
    private DefaultTableModel currentBuyTableModel;
    private DefaultTableModel currentSellTableModel;
    private DefaultTableModel myBuyTableModel;
    private DefaultTableModel mySellTableModel;
    private DefaultTableModel tradeHistoryTableModel;
    private List<Object> offerList;
    private String currentUnitName;


    DAONetworkClient offerData;
    UnitData u;
    PropertyData p;

    /**
     * Construct a offer data with a network client that accesses to sever end.
     *
     * @param daoNetworkClient - provide access to server end to action database.
     */
    public OfferData(DAONetworkClient daoNetworkClient) {
        u = new UnitData(new DAONetworkClient(new Unit()));
        p = new PropertyData(new DAONetworkClient(new Property()));
        listModel = new DefaultListModel();
        offerData = daoNetworkClient;

        currentUnitName = CurrentUser.getInstance().getCurrentUserUnit();

//        just for test
//        CurrentUser.getInstance().setCurrentUserName("alice");
//        CurrentUser.getInstance().setCurrentUserUnit("unit 3");

        SetCurrentBuyTableModel();
        SetCurrentSellTableModel();
        SetMyBuyTableModel();
        SetMySellTableModel();

      // add the retrieved data to the list model
        for (String name : offerData.getNameList()) {
            listModel.addElement(name);
        }
    }
    /**
     * Add a new offer to database
     * @param  o used to add offer
     */
    public void add(Offer o) {
        // check to see if the person is already in the book
        // if not add to the address book and the list model
        if (!listModel.contains(o.getOfferName())) {
            listModel.addElement(o.getOfferName());
            offerData.addItem(o);
        }
    }
    /**
     * Remove a object from database
     * @param key used to remove offer
     */
    public void remove(Object key) {
        listModel.removeElement(key);
        offerData.deleteItem(key.toString());
    }
    /**
     * Update offer from database
     * @param o used to update offer
     */
    public void update(Offer o) {
            offerData.updateItem(o);
        }
    /**
     * Used to close offerData
     */
    public void persist() {
        offerData.close();
    }
    /**
     * Used to get an object
     * @param key the object
     * @return the object of Optional
     */
    public Optional<Object> get(Object key) {
        return (Optional<Object>) offerData.getItem(key.toString());
    }
    /**
     * Used to get model
     * @return the list of model
     */
    public ListModel getModel() {
        return listModel;
    }
    /**
     * Used to get size
     * @return the value of number
     */
    public int getSize() {
        return offerData.getSize();
    }


    /**for asset JCombobox
     * @return ComboBoxModel
     * */
    public DefaultComboBoxModel getAssetList(){
        DefaultComboBoxModel comboBoxModel = new DefaultComboBoxModel();
        p.setupModel(currentUnitName);
        ListModel listModel = p.getModel();
        final Enumeration<?> elements = ((DefaultListModel)listModel).elements();
        while (elements.hasMoreElements()) {
            Property property = (Property)elements.nextElement();
            if(property.getUnitName() != null && property.getUnitName().equals(currentUnitName))
                comboBoxModel.addElement(property.getAssetName());
        }
        return comboBoxModel;
    }
    /**for unit JCombobox
     *@return ComboBoxModel
     * */
    public DefaultComboBoxModel getUnitList(){
        DefaultListModel unitListModel = (DefaultListModel)u.getModel();
        String[] lstArray = new String[unitListModel.getSize()];
        unitListModel.copyInto(lstArray);
        return new DefaultComboBoxModel(lstArray);
    }
    /**for offer type JCombobox
     * @return ComboBoxModel
     * */
    public DefaultComboBoxModel getOfferTypeList(){
        String[] lstArray = new String[]{"Buy", "Sell"};
        return new DefaultComboBoxModel(lstArray);
    }
    /**for getting offer list
     * @return the list of offer
     * */
    public List<Offer> getOfferList(){
        return (List<Offer>)(Object)offerData.getItemList();
    }
    /**for getting model
     * @return Table Model
     * */
    public DefaultTableModel getCurrentBuyTableModel(){
        return currentBuyTableModel;
    }
    /**for getting model
     * @return current Model
     * */
    public DefaultTableModel getCurrentSellTableModel(){
        return currentSellTableModel;
    }
    /**for getting model
     * @return current Model
     * */
    public DefaultTableModel getMyBuyTableModel(){
        return myBuyTableModel;
    }
    /**for getting model
     * @return current Model
     * */
    public DefaultTableModel getMySellTableModel(){
        return mySellTableModel;
    }
    /**for setting model
     * @param tradeHistoryData trade History Data
     * */
    public void SetTradeHistoryTableModel(DAOTradeHistory tradeHistoryData){
        List<TradeHistory> tradeHistoryList = tradeHistoryData.getItemList();
        final String[] columnNames = {"Asset", "Quantity", "Price", "Buy Offer", "Buy Unit", "Sell Offer",  "Sell Unit"};
        for(String col : columnNames){
            tradeHistoryTableModel.addColumn(col);
        }
        // add the retrieved data to the table model
        List<Object> newRow = new ArrayList<>();
        for (TradeHistory tradeHistory : tradeHistoryList) {
            newRow.clear();
            newRow.add(tradeHistory.getAssetName());
            newRow.add(tradeHistory.getQuantity());
            newRow.add(tradeHistory.getTransactionPrice());
            newRow.add(tradeHistory.getBuyOfferName());
            newRow.add(tradeHistory.getBuyUnitName());
            newRow.add(tradeHistory.getSellOfferName());
            newRow.add(tradeHistory.getSellUnitName());
            tradeHistoryTableModel.addRow(newRow.toArray());
        }
    }
    /**for setting model
     * */
    public void SetCurrentBuyTableModel(){
        offerList = offerData.getItemList();
        Predicate<Offer> byOfferType = offer-> "Buy".equals(offer.getOfferType());
        List<Offer> currentBuyOfferList = ((List<Offer>)(Object)offerList).stream().filter(byOfferType).collect(Collectors.toList());
        currentBuyTableModel = new DefaultTableModel();
        final String[] columnNames = {"Id", "Buy Offer", "Asset", "Price", "Quantity",  "Buy Unit"};
        for(String col : columnNames){
            currentBuyTableModel.addColumn(col);
        }
        // add the retrieved data to the table model
        List<Object> newRow = new ArrayList<>();
        for (Offer currentBuyOffer : currentBuyOfferList) {
            newRow.clear();
            newRow.add(currentBuyOffer.getId());
            newRow.add(currentBuyOffer.getOfferName());
            newRow.add(currentBuyOffer.getAssetName());
            newRow.add(currentBuyOffer.getPrice());
            newRow.add(currentBuyOffer.getQuantity());
            newRow.add(currentBuyOffer.getUnitName());
            currentBuyTableModel.addRow(newRow.toArray());
        }
    }
    /**for setting model
     * */
    public void SetCurrentSellTableModel(){
        offerList = offerData.getItemList();
        Predicate<Offer> byOfferType = offer-> "Sell".equals(offer.getOfferType());
        List<Offer> currentSellOfferList = ((List<Offer>)(Object)offerList).stream().filter(byOfferType).collect(Collectors.toList());
        currentSellTableModel = new DefaultTableModel();
        final String[] columnNames = {"Id", "Sell Offer", "Asset", "Price", "Quantity",  "Sell Unit"};
        for(String col : columnNames){
            currentSellTableModel.addColumn(col);
        }
        // add the retrieved data to the table model
        List<Object> newRow = new ArrayList<>();
        for (Offer currentSellOffer : currentSellOfferList) {
            newRow.clear();
            newRow.add(currentSellOffer.getId());
            newRow.add(currentSellOffer.getOfferName());
            newRow.add(currentSellOffer.getAssetName());
            newRow.add(currentSellOffer.getPrice());
            newRow.add(currentSellOffer.getQuantity());
            newRow.add(currentSellOffer.getUnitName());
            currentSellTableModel.addRow(newRow.toArray());
        }
    }
    /**for setting model
     * */
    public void SetMyBuyTableModel(){
        offerList = offerData.getItemList();
        Predicate<Offer> byOfferTypeAndUnit = offer-> "Buy".equals(offer.getOfferType()) && offer.getUnitName().equals(CurrentUser.getInstance().getCurrentUserUnit());
        List<Offer> myBuyOfferList = ((List<Offer>)(Object)offerList).stream().filter(byOfferTypeAndUnit).collect(Collectors.toList());
        myBuyTableModel = new DefaultTableModel();
        final String[] columnNames = {"Id", "Buy Offer", "Asset", "Price", "Quantity",  "Buy Unit", "Offer Type"};
        for(String col : columnNames){
            myBuyTableModel.addColumn(col);
        }
        // add the retrieved data to the table model
        List<Object> newRow = new ArrayList<>();
        for (Offer myBuyOffer : myBuyOfferList) {
            newRow.clear();
            newRow.add(myBuyOffer.getId());
            newRow.add(myBuyOffer.getOfferName());
            newRow.add(myBuyOffer.getAssetName());
            newRow.add(myBuyOffer.getPrice());
            newRow.add(myBuyOffer.getQuantity());
            newRow.add(myBuyOffer.getUnitName());
            newRow.add(myBuyOffer.getOfferType());
            myBuyTableModel.addRow(newRow.toArray());
        }
    }
    /**for setting model
     * */
    public void SetMySellTableModel(){
        offerList = offerData.getItemList();
        Predicate<Offer> byOfferTypeAndUnit = offer-> "Sell".equals(offer.getOfferType()) && offer.getUnitName().equals(CurrentUser.getInstance().getCurrentUserUnit());
        List<Offer> mySellOfferList = ((List<Offer>)(Object)offerList).stream().filter(byOfferTypeAndUnit).collect(Collectors.toList());
        mySellTableModel = new DefaultTableModel();
        final String[] columnNames = {"Id", "Sell Offer", "Asset", "Price", "Quantity",  "Sell Unit", "Offer Type"};
        for(String col : columnNames){
            mySellTableModel.addColumn(col);
        }
        // add the retrieved data to the table model
        List<Object> newRow = new ArrayList<>();
        for (Offer mySellOffer : mySellOfferList) {
            newRow.clear();
            newRow.add(mySellOffer.getId());
            newRow.add(mySellOffer.getOfferName());
            newRow.add(mySellOffer.getAssetName());
            newRow.add(mySellOffer.getPrice());
            newRow.add(mySellOffer.getQuantity());
            newRow.add(mySellOffer.getUnitName());
            newRow.add(mySellOffer.getOfferType());
            mySellTableModel.addRow(newRow.toArray());
        }
    }
    /**for getting credits
     * @return string of credits
     * */
    public String GetAvailableCredits(){
        Optional<Object> o = u.get(currentUnitName);
        if(o.isPresent()){
            return String.valueOf(((Unit)o.get()).getCredits());
        }
        return "";
    }


    /**for getting quantity
     * @param assetName the name of asset
     * @return the number of quantity
     * */
    public int GetAssetQuantity(String assetName){
        //get the total quantity of the asset in current unit
        Optional<Object> o = p.get(assetName + "," + currentUnitName);
        int total = 0;
        if(o.isPresent()){
            total = ((Property)o.get()).getQuantity();
        }

        //get the quantity in the curernt offer list
        offerList = offerData.getItemList();
        Predicate<Offer> byOfferTypeAssetName = offer-> "Sell".equals(offer.getOfferType()) && offer.getAssetName().equals(assetName) && offer.getUnitName().equals(currentUnitName);
        List<Offer> assetOffers = ((List<Offer>)(Object)offerList).stream().filter(byOfferTypeAssetName).collect(Collectors.toList());
        int q = 0;
        for(Offer offer: assetOffers){
            q +=offer.getQuantity();
        }

        return (total - q);
    }


    /**for getting list of object
     * @param model the variable of model
     * @return the list of object
     * */
    public static List<Object> asList(final DefaultListModel model) {
        return new ArrayList<Object>() {
            @Override public Object get(int index) {
                return  model.getElementAt(index);
            }
        };
    }
    /**for getting list of object
     * @return the list of object
     * */
    public List<Offer> getBuyItemList(){
        Predicate<Offer> byOfferType = offer-> "Buy".equals(offer.getOfferType());
        return ((List<Offer>)(Object)offerList).stream().filter(byOfferType).collect(Collectors.toList());
    }
    /**for getting list of object
     * @return the list of object
     * */
    public List<Offer> getSellItemList() {
        Predicate<Offer> byOfferType = offer-> "Buy".equals(offer.getOfferType());
        return ((List<Offer>)(Object)offerList).stream().filter(byOfferType).collect(Collectors.toList());
    }

}
