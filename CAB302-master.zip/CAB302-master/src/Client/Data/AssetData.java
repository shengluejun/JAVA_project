package src.Client.Data;

import src.Common.Model.Asset;
import src.Client.DAONetworkClient;

import javax.swing.*;
import java.util.Optional;

/**
 * A solution to the "asset data" part of CAB302 Assignment which provides data for asset management UI.
 *
 * @author CAB302
 * @version 1.0
 */
public class AssetData {

    DefaultListModel listModel;

    DAONetworkClient assetData;
    /**
     * Construct a asset data with a network client that accesses to sever end.
     *
     * @param daoNetworkClient - provide access to server end to action database.
     */
    public AssetData(DAONetworkClient daoNetworkClient) {
        listModel = new DefaultListModel();
        assetData = daoNetworkClient;

         //add the retrieved data to the list model
        for (String name : assetData.getNameList()) {
            listModel.addElement(name);
        }
    }
    /**
     * Add a object to listModel.
     * @param a - an object of asset.
     */
    public void add(Asset a) {
        // check to see if the person is already in the book
        // if not add to the address book and the list model
        if (!listModel.contains(a.getAssetName())) {
            listModel.addElement(a.getAssetName());
            assetData.addItem(a);
        }
    }
    /**
     * Remove object from listModel.
     * @param key - an object
     */
    public void remove(Object key) {
        // remove from both list and map
        listModel.removeElement(key);
        assetData.deleteItem((String)key);
    }
    /**
     * Update object from listModel.
     * @param a - an object
     */
    public void update(Asset a) {
            assetData.updateItem(a);
        }

    /**
     * Close assetDate.
     */
    public void persist() {
        assetData.close();
    }
    /**
     * Get object from database through object.
     * @param key used for find item
     * @return a object of Optional
     */
    public Optional<Object> get(Object key) {
        return (Optional<Object>)assetData.getItem(key.toString());
    }
    /**
     * Get list model.
     * @return list model
     */
    public ListModel getModel() {
        return listModel;
    }
    /**
     * Get the size.
     * @return the value of number
     */
    public int getSize() {
        return assetData.getSize();
    }
}
