package src.Client.Data;

import src.Common.Model.Unit;
import src.Common.Model.User;
import src.Client.DAONetworkClient;

import javax.swing.*;
import java.util.Optional;

/**
 * A solution to the "user data" part of CAB302 Assignment which provides data for user management UI.
 *
 * @author CAB302
 * @version 1.0
 */
public class UserData {
    DefaultListModel listModel;

    DAONetworkClient userData;
    private static String currentUnit;
    private static String currentUser;
    /**
     * Construct a user data with a network client that accesses to sever end.
     *
     * @param daoNetworkClient - provide access to server end to action database.
     */
    public UserData(DAONetworkClient daoNetworkClient) {
        listModel = new DefaultListModel();
        userData = daoNetworkClient;

        // add the retrieved data to the list model
        for (String name : userData.getNameList()) {
            listModel.addElement(name);
        }
    }
    /**
     * Add a new user to database.
     *
     * @param u - new user.
     */
    public void add(User u) {
        // check to see if the person is already in the book
        // if not add to the address book and the list model
        if (!listModel.contains(u.getUserName())) {
            listModel.addElement(u.getUserName());
            userData.addItem(u);
        }
    }
    /**
     * Update a new user to database.
     *
     * @param u - new user.
     */
    public void update(User u) {
        userData.updateItem(u);
    }

    /**
     * Remove a user from database.
     *
     * @param key - new user.
     */
    public void remove(Object key) {
        // remove from both list and map
        listModel.removeElement(key);
        userData.deleteItem((String)key);
    }
    /**
     * Close user date.
     *
     */
    public void persist() {
        userData.close();
    }

    /**
     * Get the object.
     * @param key object
     * @return the object of Optional
     *
     */
    public Optional<Object> get(Object key) {
        return (Optional<Object>)userData.getItem(key.toString());
    }
    /**
     * Get the model.
     * @return the model list
     */
    public ListModel getModel() {
        return listModel;
    }
    /**
     * Get the size of user data.
     * @return the number of size
     */
    public int getSize() {
        return userData.getSize();
    }
    /**
     * Get the unit list.
     * @return Combo Box Model
     */
    public DefaultComboBoxModel getUnitList(){
        UnitData u = new UnitData(new DAONetworkClient(new Unit()));
        DefaultListModel unitListModel = (DefaultListModel)u.getModel();
        String[] lstArray = new String[unitListModel.getSize()];
        unitListModel.copyInto(lstArray);
        return new DefaultComboBoxModel(lstArray);
    }
    /**
     * Get the User Type List.
     * @return Combo Box Model
     */
    public DefaultComboBoxModel getUserTypeList() {
        String[] userTypeList = {"Admin", "Staff"};
        return new DefaultComboBoxModel(userTypeList);
    }
}


