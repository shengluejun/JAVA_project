package src.Client.Data;


import src.Common.Model.TradeHistory;
import src.Client.DAONetworkClient;
import javax.swing.table.DefaultTableModel;
import java.util.*;

/**
 * A solution to the "trade history data" part of CAB302 Assignment which provides data for trade history table UI.
 *
 * @author CAB302
 * @version 1.0
 */
public class TradeHistoryData {
    DefaultTableModel tableModel;

    DAONetworkClient tradeHistoryData;
    /**
     * Construct a trade history data with a network client that accesses to sever end.
     *
     * @param daoNetworkClient - provide access to server end to action database.
     */
    public  TradeHistoryData (DAONetworkClient daoNetworkClient)
    {
        tableModel = new DefaultTableModel();
        tradeHistoryData = daoNetworkClient;
        setupTableModel();

    }
    /**
     * Used for setting up Table Model.
     *
     */
    public void setupTableModel(){
        List<Object> tradeHistoryList = tradeHistoryData.getItemList();
        final String[] columnNames = {"Asset", "Quantity", "Price", "Buy Offer", "Buy Unit", "Sell Offer",  "Sell Unit", "Transaction Time"};
        for(String col : columnNames){
            tableModel.addColumn(col);
        }
        // add the retrieved data to the table model
        List<Object> newRow = new ArrayList<>();
        for (Object tradeHistoryObject : tradeHistoryList) {
            TradeHistory tradeHistory = (TradeHistory)tradeHistoryObject;
            newRow.clear();
            newRow.add(tradeHistory.getAssetName());
            newRow.add(tradeHistory.getQuantity());
            newRow.add(tradeHistory.getTransactionPrice());
            newRow.add(tradeHistory.getBuyOfferName());
            newRow.add(tradeHistory.getBuyUnitName());
            newRow.add(tradeHistory.getSellOfferName());
            newRow.add(tradeHistory.getSellUnitName());
            newRow.add(tradeHistory.getTransactionTime());
            tableModel.addRow(newRow.toArray());
        }
    }
    /**
     * Add a new history
     * @param a the object of TradeHistory
     */
    public void add(TradeHistory a) {
        tradeHistoryData.addItem(a);
    }

    /**
     * Close trade History Data
     */
    public void persist() {
        tradeHistoryData.close();
    }
    /**
     * Get the object
     * @param key the object to find
     * @return the object of Optional
     */
    public Optional<Object> get(Object key) {
        return (Optional<Object>) tradeHistoryData.getItem(key.toString());
    }
    /**
     * Get the Table Model
     * @return Table Model
     */
    public DefaultTableModel getModel() {
        return tableModel;
    }
    /**
     * Get the size of trade History Data
     * @return the number of size
     */
    public int getSize() {
        return tradeHistoryData.getSize();
    }
}
